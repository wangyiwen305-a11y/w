import React, { useState, useEffect, useRef, useCallback } from "react";
import { Play, RotateCw, ArrowLeft, ArrowRight, ArrowDown } from "lucide-react";

interface TetrisGameProps {
  onLoggedClick: () => void;
}

// 10 columns x 20 rows
const COLS = 10;
const ROWS = 20;

// Colors for different tetrominos
const COLORS = [
  "bg-transparent", // Empty
  "bg-cyan-500 shadow-[inset_0_-3px_0_rgba(0,0,0,0.3)] border border-cyan-300", // I
  "bg-blue-600 shadow-[inset_0_-3px_0_rgba(0,0,0,0.3)] border border-blue-400", // J
  "bg-orange-500 shadow-[inset_0_-3px_0_rgba(0,0,0,0.3)] border border-orange-300", // L
  "bg-yellow-400 shadow-[inset_0_-3px_0_rgba(0,0,0,0.3)] border border-yellow-200", // O
  "bg-green-500 shadow-[inset_0_-3px_0_rgba(0,0,0,0.3)] border border-green-300", // S
  "bg-purple-600 shadow-[inset_0_-3px_0_rgba(0,0,0,0.3)] border border-purple-400", // T
  "bg-red-600 shadow-[inset_0_-3px_0_rgba(0,0,0,0.3)] border border-red-400", // Z
];

// Shapes
const SHAPES = [
  [],
  [[1, 1, 1, 1]], // I-shape
  [[2, 0, 0], [2, 2, 2]], // J-shape
  [[0, 0, 3], [3, 3, 3]], // L-shape
  [[4, 4], [4, 4]], // O-shape
  [[0, 5, 5], [5, 5, 0]], // S-shape
  [[0, 6, 0], [6, 6, 6]], // T-shape
  [[7, 7, 0], [0, 7, 7]], // Z-shape
];

export default function TetrisGame({ onLoggedClick }: TetrisGameProps) {
  const [grid, setGrid] = useState<number[][]>(() => 
    Array.from({ length: ROWS }, () => Array(COLS).fill(0))
  );
  
  // Game states
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [linesCleared, setLinesCleared] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    try {
      return Number(localStorage.getItem("procrastinate_tetris_hi") || "800");
    } catch {
      return 800;
    }
  });

  // Current piece info
  const [piece, setPiece] = useState<{
    shape: number[][];
    x: number;
    y: number;
    colorIndex: number;
  } | null>(null);

  const gameInterval = useRef<NodeJS.Timeout | null>(null);

  // Generate random piece
  const spawnPiece = useCallback(() => {
    const typeIndex = Math.floor(Math.random() * 7) + 1;
    const shape = SHAPES[typeIndex];
    const width = shape[0].length;
    const startX = Math.floor((COLS - width) / 2);
    const startY = 0;

    return {
      shape,
      x: startX,
      y: startY,
      colorIndex: typeIndex
    };
  }, []);

  // Validation
  const isValidMove = useCallback((shape: number[][], posX: number, posY: number, currentGrid: number[][]) => {
    for (let r = 0; r < shape.length; r++) {
      for (let c = 0; c < shape[r].length; c++) {
        if (shape[r][c] !== 0) {
          const nextX = posX + c;
          const nextY = posY + r;

          // Out of bounds
          if (nextX < 0 || nextX >= COLS || nextY >= ROWS) {
            return false;
          }

          // Collide with fixed blocks
          if (nextY >= 0 && currentGrid[nextY][nextX] !== 0) {
            return false;
          }
        }
      }
    }
    return true;
  }, []);

  // Merge block into grid
  const mergeToGrid = useCallback((currPiece: typeof piece, currentGrid: number[][]) => {
    if (!currPiece) return currentGrid;
    const newGrid = currentGrid.map(row => [...row]);
    
    for (let r = 0; r < currPiece.shape.length; r++) {
      for (let c = 0; c < currPiece.shape[r].length; c++) {
        if (currPiece.shape[r][c] !== 0) {
          const targetY = currPiece.y + r;
          const targetX = currPiece.x + c;
          if (targetY >= 0 && targetY < ROWS && targetX >= 0 && targetX < COLS) {
            newGrid[targetY][targetX] = currPiece.colorIndex;
          }
        }
      }
    }
    return newGrid;
  }, []);

  // Check and clear finished lines
  const checkLines = useCallback((currentGrid: number[][]) => {
    let cleared = 0;
    const newGrid = currentGrid.filter(row => {
      const isFull = row.every(cell => cell !== 0);
      if (isFull) cleared++;
      return !isFull;
    });

    while (newGrid.length < ROWS) {
      newGrid.unshift(Array(COLS).fill(0));
    }

    if (cleared > 0) {
      setScore(prev => {
        const added = [0, 100, 300, 600, 1000][cleared] || 1200;
        const nextScore = prev + added;
        if (nextScore > highScore) {
          setHighScore(nextScore);
          try {
            localStorage.setItem("procrastinate_tetris_hi", String(nextScore));
          } catch {}
        }
        return nextScore;
      });
      setLinesCleared(prev => prev + cleared);
    }

    return newGrid;
  }, [highScore]);

  // Drop down one step
  const dropPiece = useCallback(() => {
    if (isGameOver || !isPlaying || !piece) return;

    setGrid(prevGrid => {
      if (isValidMove(piece.shape, piece.x, piece.y + 1, prevGrid)) {
        setPiece(prev => prev ? { ...prev, y: prev.y + 1 } : null);
        return prevGrid;
      } else {
        // Landed!
        const merged = mergeToGrid(piece, prevGrid);
        const resolvedGrid = checkLines(merged);
        
        // Next Piece
        const nextPiece = spawnPiece();
        if (!isValidMove(nextPiece.shape, nextPiece.x, nextPiece.y, resolvedGrid)) {
          setIsGameOver(true);
          setIsPlaying(false);
          return resolvedGrid;
        }

        setPiece(nextPiece);
        return resolvedGrid;
      }
    });
  }, [piece, isPlaying, isGameOver, isValidMove, mergeToGrid, checkLines, spawnPiece]);

  // Game tick interval
  useEffect(() => {
    if (isPlaying && !isGameOver) {
      const speed = Math.max(150, 750 - Math.min(6, Math.floor(score / 800)) * 90);
      gameInterval.current = setInterval(() => {
        dropPiece();
      }, speed);
    } else {
      if (gameInterval.current) clearInterval(gameInterval.current);
    }

    return () => {
      if (gameInterval.current) clearInterval(gameInterval.current);
    };
  }, [isPlaying, isGameOver, dropPiece, score]);

  // Handle keyboard inputs
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || isGameOver || !piece) return;

      if (e.key === "ArrowLeft") {
        onLoggedClick();
        setPiece(prev => {
          if (prev && isValidMove(prev.shape, prev.x - 1, prev.y, grid)) {
            return { ...prev, x: prev.x - 1 };
          }
          return prev;
        });
      } else if (e.key === "ArrowRight") {
        onLoggedClick();
        setPiece(prev => {
          if (prev && isValidMove(prev.shape, prev.x + 1, prev.y, grid)) {
            return { ...prev, x: prev.x + 1 };
          }
          return prev;
        });
      } else if (e.key === "ArrowDown") {
        onLoggedClick();
        setPiece(prev => {
          if (prev && isValidMove(prev.shape, prev.x, prev.y + 1, grid)) {
            return { ...prev, y: prev.y + 1 };
          }
          return prev;
        });
      } else if (e.key === "ArrowUp") {
        onLoggedClick();
        // Rotate shape matrix 90 degrees
        const currentShape = piece.shape;
        const M = currentShape.length;
        const N = currentShape[0].length;
        const rotated = Array.from({ length: N }, () => Array(M).fill(0));
        for (let r = 0; r < M; r++) {
          for (let c = 0; c < N; c++) {
            rotated[c][M - 1 - r] = currentShape[r][c];
          }
        }

        setPiece(prev => {
          if (prev) {
            // Adjust X if out of bounds after rotation
            let testX = prev.x;
            if (testX + rotated[0].length > COLS) {
              testX = COLS - rotated[0].length;
            }
            if (testX < 0) testX = 0;

            if (isValidMove(rotated, testX, prev.y, grid)) {
              return { ...prev, shape: rotated, x: testX };
            }
          }
          return prev;
        });
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isPlaying, isGameOver, piece, grid, isValidMove, onLoggedClick]);

  // Manual actions
  const moveLeft = () => {
    onLoggedClick();
    if (!isPlaying || isGameOver || !piece) return;
    setPiece(prev => prev && isValidMove(prev.shape, prev.x - 1, prev.y, grid) ? { ...prev, x: prev.x - 1 } : prev);
  };

  const moveRight = () => {
    onLoggedClick();
    if (!isPlaying || isGameOver || !piece) return;
    setPiece(prev => prev && isValidMove(prev.shape, prev.x + 1, prev.y, grid) ? { ...prev, x: prev.x + 1 } : prev);
  };

  const rotatePiece = () => {
    onLoggedClick();
    if (!isPlaying || isGameOver || !piece) return;
    const currentShape = piece.shape;
    const M = currentShape.length;
    const N = currentShape[0].length;
    const rotated = Array.from({ length: N }, () => Array(M).fill(0));
    for (let r = 0; r < M; r++) {
      for (let c = 0; c < N; c++) {
        rotated[c][M - 1 - r] = currentShape[r][c];
      }
    }
    setPiece(prev => {
      if (prev) {
        let testX = prev.x;
        if (testX + rotated[0].length > COLS) {
          testX = COLS - rotated[0].length;
        }
        if (testX < 0) testX = 0;
        if (isValidMove(rotated, testX, prev.y, grid)) {
          return { ...prev, shape: rotated, x: testX };
        }
      }
      return prev;
    });
  };

  const moveDown = () => {
    onLoggedClick();
    dropPiece();
  };

  const restartGame = () => {
    onLoggedClick();
    setGrid(Array.from({ length: ROWS }, () => Array(COLS).fill(0)));
    setScore(0);
    setLinesCleared(0);
    setIsGameOver(false);
    const initialPiece = spawnPiece();
    setPiece(initialPiece);
    setIsPlaying(true);
  };

  // Render combined view of fixed blocks & dropping piece
  const displayGrid = grid.map(row => [...row]);
  if (piece && isPlaying && !isGameOver) {
    for (let r = 0; r < piece.shape.length; r++) {
      for (let c = 0; c < piece.shape[r].length; c++) {
        if (piece.shape[r][c] !== 0) {
          const targetY = piece.y + r;
          const targetX = piece.x + c;
          if (targetY >= 0 && targetY < ROWS && targetX >= 0 && targetX < COLS) {
            displayGrid[targetY][targetX] = piece.colorIndex;
          }
        }
      }
    }
  }

  return (
    <div className="flex flex-col h-full bg-[#1b1c26] text-white p-3 font-mono text-xs select-none justify-between">
      {/* Banner */}
      <div className="bg-[#ff4757] text-[#fff] p-1 font-mono text-[9px] uppercase text-center border-b-2 border-black mb-1.5 animate-pulse">
        🎮 摸鱼新境界: 俄罗斯方块消除工作效率 🎮
      </div>

      <div className="flex-grow flex gap-3 h-0 overflow-hidden leading-none">
        {/* Game Arena Grid */}
        <div className="flex-1 max-w-[150px] aspect-[1/2] bg-[#0c0d12] border-2 border-[#555] rounded p-1 flex flex-col justify-between self-center">
          <div className="grid grid-cols-10 grid-rows-20 gap-[1px] w-full h-full bg-black">
            {displayGrid.map((row, rIdx) => 
              row.map((cellValue, cIdx) => (
                <div 
                  key={`${rIdx}-${cIdx}`} 
                  className={`w-full aspect-square rounded-[1px] ${COLORS[cellValue]} ${
                    cellValue === 0 ? "bg-neutral-900/40" : ""
                  }`}
                />
              ))
            )}
          </div>
        </div>

        {/* Dashboard Side area */}
        <div className="w-[170px] flex flex-col justify-between py-1 text-[10px]">
          {/* Status block */}
          <div className="bg-neutral-800 p-2 border border-neutral-700 rounded space-y-1.5">
            <div>
              <span className="text-gray-400 uppercase tracking-widest text-[8px] block">🏆 最高分</span>
              <span className="text-sm font-extrabold text-amber-400">{highScore}</span>
            </div>
            <div>
              <span className="text-gray-400 uppercase tracking-widest text-[8px] block">✨ 当前分数</span>
              <span className="text-sm font-bold text-cyan-400">{score}</span>
            </div>
            <div>
              <span className="text-gray-400 uppercase tracking-widest text-[8px] block">🧱 消除层数</span>
              <span className="text-xs text-white">{linesCleared} 层</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="my-1.5">
            {!isPlaying ? (
              <button
                onClick={restartGame}
                className="w-full bg-[#20bf6b] hover:bg-[#2bcb71] active:translate-y-0.5 text-black font-extrabold uppercase py-2 border-b-4 border-emerald-800 rounded flex items-center justify-center gap-1 cursor-pointer"
              >
                <Play size={12} className="fill-black" />
                <span>{isGameOver ? "重新摸鱼" : "开始堆方块"}</span>
              </button>
            ) : (
              <button
                onClick={() => { onLoggedClick(); setIsPlaying(false); }}
                className="w-full bg-amber-500 hover:bg-amber-400 active:translate-y-0.5 text-black font-bold uppercase py-1 border-b-2 border-amber-800 rounded text-center cursor-pointer"
              >
                暂停歇会
              </button>
            )}
          </div>

          {/* Touch direction controllers */}
          <div className="grid grid-cols-3 gap-1 bg-neutral-950/50 p-2 rounded border border-neutral-800">
            <div></div>
            <button 
              onClick={rotatePiece} 
              disabled={!isPlaying}
              className="bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 disabled:opacity-40 p-2 rounded flex items-center justify-center text-cyan-400 cursor-pointer"
              title="旋转"
            >
              <RotateCw size={12} />
            </button>
            <div></div>

            <button 
              onClick={moveLeft} 
              disabled={!isPlaying}
              className="bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 disabled:opacity-40 p-2 rounded flex items-center justify-center text-white cursor-pointer"
              title="向左"
            >
              <ArrowLeft size={12} />
            </button>
            <button 
              onClick={moveDown} 
              disabled={!isPlaying}
              className="bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 disabled:opacity-40 p-2 rounded flex items-center justify-center text-white cursor-pointer"
              title="加速下落"
            >
              <ArrowDown size={12} />
            </button>
            <button 
              onClick={moveRight} 
              disabled={!isPlaying}
              className="bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 disabled:opacity-40 p-2 rounded flex items-center justify-center text-white cursor-pointer"
              title="向右"
            >
              <ArrowRight size={12} />
            </button>
          </div>
        </div>
      </div>

      {/* Funny micro tips */}
      <div className="mt-1.5 text-[8px] bg-neutral-900 border border-neutral-800 p-1 rounded text-gray-400 text-center select-text leading-snug">
        {isGameOver ? (
          <span className="text-red-400 font-bold block">
            🎮 游戏结束！您的生产力指数降到了冰点。
          </span>
        ) : (
          <span>
            💡 键盘 &larr; &rarr; 移动，&uarr; 旋转，&darr; 加速下坠。极速逃避工作压力！
          </span>
        )}
      </div>
    </div>
  );
}
