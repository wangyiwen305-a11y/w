import React, { useState, useEffect, useRef } from "react";
import { UserState, BossMessage } from "../types";
import { Send, User, ChevronDown, Bell, Smile, Paperclip } from "lucide-react";

interface BossChatProps {
  user: UserState;
  procrastinationLevel: number;
  onLoggedClick: () => void;
  onUrgeLogged: () => void;
}

export default function BossChat({ user, procrastinationLevel, onLoggedClick, onUrgeLogged }: BossChatProps) {
  const [messages, setMessages] = useState<BossMessage[]>([]);
  const [typing, setTyping] = useState(false);
  const [fakeProgress, setFakeProgress] = useState<number | null>(null);
  const [progressStatus, setProgressStatus] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const getUrgencyLevel = (level: number) => {
    if (level <= 1) return 1;
    if (level === 2) return 2;
    if (level === 3) return 3;
    return 4;
  };

  const triggerBossMessage = async (lvl: number) => {
    setTyping(true);
    onUrgeLogged();
    try {
      const response = await fetch("/api/boss-message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userName: user.name,
          jobType: user.jobType,
          level: getUrgencyLevel(lvl),
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const newMessage: BossMessage = {
          id: Math.random().toString(),
          sender: "boss",
          text: data.text,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        };
        setMessages((prev) => [...prev, newMessage]);
      }
    } catch (err) {
      console.error("Failed to fetch boss prompt:", err);
    } finally {
      setTyping(false);
    }
  };

  const handleReply = (replyText: string) => {
    onLoggedClick();
    
    // Add player message
    const playerMsg: BossMessage = {
      id: Math.random().toString(),
      sender: "player",
      text: replyText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, playerMsg]);

    // Handle funny response logic
    if (replyText.includes("马上提交") || replyText.includes("拉通闭环")) {
      // Trigger a funny stuck progress bar
      setFakeProgress(0);
      setProgressStatus("正在解压工作包 (0%)...");
      
      let p = 0;
      const interval = setInterval(() => {
        p += Math.floor(Math.random() * 15) + 5;
        if (p >= 98) {
          p = 98;
          setProgressStatus("上传失败：网络代理超时，请重新授权模块密码。");
          clearInterval(interval);
        } else {
          setProgressStatus(`正在传输核心依赖包 (${p}%)...`);
        }
        setFakeProgress(p);
      }, 500);

      // Trigger Boss rebuttal after 3 seconds
      setTimeout(() => {
        triggerBossMessage(procrastinationLevel + 1);
      }, 3500);
    } else {
      // Direct boss reaction
      setTimeout(() => {
        triggerBossMessage(procrastinationLevel);
      }, 1500);
    }
  };

  // Scroll messages to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  // Initial trigger
  useEffect(() => {
    setMessages([
      {
        id: "init",
        sender: "boss",
        text: `【主管王经理】把您拉入了 “今日任务攻坚拉温群” 。主管王经理发起了今日工作汇报。`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
      {
        id: "init2",
        sender: "boss",
        text: `小${user.name}，那个关于【${
          user.jobType === "code" ? "核心代码及接口模块" :
          user.jobType === "report" ? "Q2汇报PPT大纲" :
          user.jobType === "design" ? "移动组件库Figma界面" :
          user.jobType === "literature" ? "毕业学术综述初稿" : "全员会议纪要Align"
        }】目前进度如何了？看云盘还没有创建文件夹呢。`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }
    ]);
  }, []);

  // Sync boss messages on level up
  useEffect(() => {
    if (procrastinationLevel > 0) {
      triggerBossMessage(procrastinationLevel);
    }
  }, [procrastinationLevel]);

  return (
    <div id="boss-chat-root" className="w-full h-full bg-[#f3f4f6] flex flex-col font-sans select-none">
      {/* Slack Header */}
      <div id="boss-header" className="bg-[#1f2937] text-white px-4 py-2 flex items-center justify-between shadow-sm select-none shrink-0 border-b border-gray-700">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div>
          <div>
            <h4 className="font-bold text-xs">王经理 (Manager Wang)</h4>
            <p className="text-[10px] text-gray-400">企业微信在线中 - 专注对齐底层逻辑</p>
          </div>
        </div>
        <Bell size={14} className="text-gray-400" />
      </div>

      {/* Messages Canvas */}
      <div id="boss-messages-scroll" className="flex-grow p-4 overflow-y-auto space-y-3 bg-[#e5e7eb] text-sm select-text">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col max-w-[85%] ${msg.sender === "player" ? "ml-auto items-end" : "mr-auto items-start"}`}
          >
            <div className="flex items-center gap-1.5 mb-0.5 text-[10px] text-gray-500 font-medium select-none">
              <span className="font-semibold text-gray-600">
                {msg.sender === "player" ? "我 (我还在看手机)" : "王主管"}
              </span>
              <span>{msg.timestamp}</span>
            </div>
            
            <div
              className={`px-3 py-2 rounded-lg shadow-sm font-medium ${
                msg.sender === "player"
                  ? "bg-[#10b981] text-white rounded-tr-none"
                  : "bg-white text-gray-800 rounded-tl-none border border-gray-200"
              }`}
            >
              <p className="leading-relaxed whitespace-pre-line tracking-wide text-xs">{msg.text}</p>
            </div>
          </div>
        ))}

        {typing && (
          <div className="flex items-center gap-1.5 mr-auto">
            <span className="text-[10px] text-gray-500 font-medium select-none">主管王经理 正在输入...</span>
            <div className="flex gap-0.5">
              <div className="w-1 h-1 bg-gray-500 rounded-full animate-bounce"></div>
              <div className="w-1 h-1 bg-gray-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
              <div className="w-1 h-1 bg-gray-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
            </div>
          </div>
        )}

        {/* Fake Stuck Progress Bar */}
        {fakeProgress !== null && (
          <div className="bg-white rounded-lg p-3 border border-gray-200 shadow-sm max-w-[85%] ml-auto select-none">
            <p className="text-[11px] text-gray-500 font-bold mb-1 uppercase tracking-wider">
              {progressStatus}
            </p>
            <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden border border-gray-200">
              <div
                className={`h-full transition-all duration-300 ${fakeProgress === 98 ? "bg-red-500" : "bg-blue-500 animate-pulse"}`}
                style={{ width: `${fakeProgress}%` }}
              ></div>
            </div>
            {fakeProgress === 98 && (
              <p className="text-[10px] text-red-600 mt-1.5 leading-normal">
                提示：您的电脑因摸鱼负荷过重，需要输入解密恢复口令（位于千度搜索第 2 页）解锁该进程！
              </p>
            )}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Preset Replies Panel */}
      <div id="boss-inputs-panel" className="bg-white p-3 border-t border-gray-200 shrink-0 select-none">
        <p className="text-[10px] text-gray-400 mb-2 font-bold uppercase tracking-wider flex items-center justify-between">
          <span>请选择您的“拉通、拉齐、赋能”借口：</span>
          <span className="text-emerald-600">双击可秒发</span>
        </p>

        <div className="grid grid-cols-1 gap-1.5">
          <button
            id="reply-progress"
            onClick={() => handleReply("主管，文档我已经写完80%了，正在做拼装和颗粒度拉通，马上提交！")}
            className="text-left px-3 py-1.5 border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50/50 rounded text-xs px-2 text-gray-700 transition"
          >
            📊 进度打包汇报：“文档已写完80％，正在做颗粒度拉通，马上提交！”
          </button>
          <button
            id="reply-network"
            onClick={() => handleReply("主管，我这边云文档同步报错，可能是由于网络代理波动导致，我重新上传一下。")}
            className="text-left px-3 py-1.5 border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50/50 rounded text-xs px-2 text-gray-700 transition"
          >
            📡 网络崩盘借口：“云文档同步报错，由于网关波动，正在解决。”
          </button>
          <button
            id="reply-thinking"
            onClick={() => handleReply("王经理，这个企划的底层业务逻辑逻辑盘得不够细，我今天正在做闭环设计。")}
            className="text-left px-3 py-1.5 border border-gray-200 hover:border-emerald-500 hover:bg-emerald-50/50 rounded text-xs px-2 text-gray-700 transition"
          >
            🧐 升华宏观借口：“项目逻辑还在细化，正在做闭环模型设计。”
          </button>
        </div>

        <div className="flex items-center justify-between text-gray-400 mt-3 pt-2 border-t border-gray-100 text-[10px]">
          <div className="flex items-center gap-1">
            <Smile size={14} />
            <Paperclip size={14} />
            <span>支持富文本格式</span>
          </div>
          <span>拖延指数持续累加</span>
        </div>
      </div>
    </div>
  );
}
