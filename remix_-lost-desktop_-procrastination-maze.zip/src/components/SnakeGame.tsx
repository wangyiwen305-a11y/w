import React, { useState, useEffect, useRef, useCallback } from "react";
import { Play, RotateCw, ArrowLeft, ArrowRight, ArrowDown, ArrowUp } from "lucide-react";

interface SnakeGameProps {
  onLoggedClick: () => void;
}

const GRID_SIZE = 15;

export default function SnakeGame({ onLoggedClick }: SnakeGameProps) {
  const [snake, setSnake] = useState<{ x: number; y: number }[]>([
    { x: 7, y: 7 },
    { x: 7, y: 8 },
    { x: 7, y: 9 },
  ]);
  const [food, setFood] = useState<{ x: number; y: number }>({ x: 3, y: 3 });
  const [direction, setDirection] = useState<{ x: number; y: number }>({ x: 0, y: -1 });
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    try {
      return Number(localStorage.getItem("procrastinate_snake_hi") || "150");
    } catch {
      return 150;
    }
  });

  const gameInterval = useRef<NodeJS.Timeout | null>(null);
  const directionRef = useRef(direction);
  directionRef.current = direction;

  // Generate food at random vacant spots
  const spawnFood = useCallback((currentSnake: { x: number; y: number }[]) => {
    while (true) {
      const foodPos = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
      const hit = currentSnake.some(seg => seg.x === foodPos.x && seg.y === foodPos.y);
      if (!hit) {
        return foodPos;
      }
    }
  }, []);

  const resetGame = () => {
    onLoggedClick();
    const initialSnake = [
      { x: 7, y: 7 },
      { x: 7, y: 8 },
      { x: 7, y: 9 },
    ];
    setSnake(initialSnake);
    setDirection({ x: 0, y: -1 });
    setFood(spawnFood(initialSnake));
    setScore(0);
    setIsGameOver(false);
    setIsPlaying(true);
  };

  const gameStep = useCallback(() => {
    setSnake(prevSnake => {
      const head = prevSnake[0];
      const dir = directionRef.current;
      const newHead = {
        x: head.x + dir.x,
        y: head.y + dir.y,
      };

      // Check wall collision
      if (
        newHead.x < 0 ||
        newHead.x >= GRID_SIZE ||
        newHead.y < 0 ||
        newHead.y >= GRID_SIZE
      ) {
        setIsGameOver(true);
        setIsPlaying(false);
        return prevSnake;
      }

      // Check self-collision
      const selfCollide = prevSnake.some((seg, idx) => idx > 0 && seg.x === newHead.x && seg.y === newHead.y);
      if (selfCollide) {
        setIsGameOver(true);
        setIsPlaying(false);
        return prevSnake;
      }

      const updatedSnake = [newHead, ...prevSnake];

      // Eat food
      if (newHead.x === food.x && newHead.y === food.y) {
        setScore(prev => {
          const next = prev + 10;
          if (next > highScore) {
            setHighScore(next);
            try {
              localStorage.setItem("procrastinate_snake_hi", String(next));
            } catch {}
          }
          return next;
        });
        setFood(spawnFood(updatedSnake));
      } else {
        updatedSnake.pop();
      }

      return updatedSnake;
    });
  }, [food, highScore, spawnFood]);

  // Game execution loop
  useEffect(() => {
    if (isPlaying && !isGameOver) {
      gameInterval.current = setInterval(() => {
        gameStep();
      }, 180); // Classic comfortable speed
    } else {
      if (gameInterval.current) clearInterval(gameInterval.current);
    }
    return () => {
      if (gameInterval.current) clearInterval(gameInterval.current);
    };
  }, [isPlaying, isGameOver, gameStep]);

  // Handle keyboard arrow keys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || isGameOver) return;
      const currentDir = directionRef.current;

      switch (e.key) {
        case "ArrowUp":
          e.preventDefault();
          onLoggedClick();
          if (currentDir.y !== 1) setDirection({ x: 0, y: -1 });
          break;
        case "ArrowDown":
          e.preventDefault();
          onLoggedClick();
          if (currentDir.y !== -1) setDirection({ x: 0, y: 1 });
          break;
        case "ArrowLeft":
          e.preventDefault();
          onLoggedClick();
          if (currentDir.x !== 1) setDirection({ x: -1, y: 0 });
          break;
        case "ArrowRight":
          e.preventDefault();
          onLoggedClick();
          if (currentDir.x !== -1) setDirection({ x: 1, y: 0 });
          break;
        default:
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isPlaying, isGameOver, onLoggedClick]);

  const changeDir = (dx: number, dy: number) => {
    onLoggedClick();
    if (!isPlaying || isGameOver) return;
    const currentDir = directionRef.current;
    if (dx !== 0 && currentDir.x === -dx) return;
    if (dy !== 0 && currentDir.y === -dy) return;
    setDirection({ x: dx, y: dy });
  };

  return (
    <div className="flex flex-col h-full bg-[#1e272e] text-white p-3 font-mono text-xs select-none justify-between">
      {/* Game bar */}
      <div className="bg-[#2bcb71] text-black p-1 text-center text-[9px] font-bold uppercase tracking-wider mb-2 rounded shadow-sm">
        🐍 办公闲暇: 贪吃蛇大作战 (避让老板版) 🐍
      </div>

      <div className="flex-grow flex gap-3 h-0 overflow-hidden">
        {/* Game grid */}
        <div className="flex-1 max-w-[160px] aspect-square bg-[#05080c] border-2 border-emerald-950 rounded p-1 flex flex-col justify-center self-center overflow-hidden">
          <div className="grid grid-cols-15 grid-rows-15 gap-[1px] w-full h-full bg-[#05080c]">
            {Array.from({ length: GRID_SIZE }).map((_, r) =>
              Array.from({ length: GRID_SIZE }).map((_, c) => {
                const isHead = snake[0].x === c && snake[0].y === r;
                const isBody = snake.slice(1).some(seg => seg.x === c && seg.y === r);
                const isFood = food.x === c && food.y === r;

                return (
                  <div
                    key={`${r}-${c}`}
                    className={`w-full aspect-square rounded-[1px] transition-colors duration-75 ${
                      isHead
                        ? "bg-emerald-400 border border-emerald-300 shadow-[0_0_4px_#10b981]"
                        : isBody
                        ? "bg-emerald-600/80"
                        : isFood
                        ? "bg-[#ff5e57] animate-pulse shadow-[0_0_5px_#ff5e57]"
                        : "bg-black/40"
                    }`}
                  />
                );
              })
            )}
          </div>
        </div>

        {/* Console controller */}
        <div className="w-[160px] flex flex-col justify-between py-1 text-[10px]">
          <div className="bg-neutral-800/80 p-2 border border-neutral-700/60 rounded space-y-1.5 font-mono">
            <div>
              <span className="text-[#2bcb71] text-[8px] tracking-wider block font-bold">★ HI-SCORE</span>
              <span className="text-sm font-black text-amber-300">{highScore}</span>
            </div>
            <div>
              <span className="text-gray-400 text-[8px] tracking-wider block">SCORE</span>
              <span className="text-sm font-bold text-white">{score}</span>
            </div>
            <div>
              <span className="text-gray-400 text-[8px] tracking-wider block">SNAKE LENGTH</span>
              <span className="text-xs font-bold text-emerald-400">{snake.length} 节</span>
            </div>
          </div>

          <div className="my-1.5">
            {!isPlaying ? (
              <button
                onClick={resetGame}
                className="w-full bg-[#2bcb71] hover:bg-[#26af62] active:translate-y-0.5 text-black font-extrabold py-2 rounded shadow-md border-b-2 border-emerald-900 flex items-center justify-center gap-1 cursor-pointer"
              >
                <Play size={11} className="fill-black" />
                <span>{isGameOver ? "不服再战" : "偷吃两口"}</span>
              </button>
            ) : (
              <button
                onClick={() => { onLoggedClick(); setIsPlaying(false); }}
                className="w-full bg-yellow-500 hover:bg-yellow-400 active:translate-y-0.5 text-black font-bold py-1.5 rounded border-b-2 border-yellow-700 text-center cursor-pointer"
              >
                保存实力 (暂停)
              </button>
            )}
          </div>

          {/* Controller keys */}
          <div className="flex flex-col items-center gap-1 bg-neutral-900/60 p-2 rounded border border-neutral-800">
            {/* UP */}
            <button
              onClick={() => changeDir(0, -1)}
              disabled={!isPlaying || direction.y === 1}
              className="bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 disabled:opacity-40 w-8 h-8 rounded flex items-center justify-center text-emerald-400 border border-neutral-700 shadow-sm transition"
            >
              <ArrowUp size={12} />
            </button>
            {/* LEFT / RIGHT */}
            <div className="flex gap-4">
              <button
                onClick={() => changeDir(-1, 0)}
                disabled={!isPlaying || direction.x === 1}
                className="bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 disabled:opacity-40 w-8 h-8 rounded flex items-center justify-center text-emerald-400 border border-neutral-700 shadow-sm transition"
              >
                <ArrowLeft size={12} />
              </button>
              <button
                onClick={() => changeDir(1, 0)}
                disabled={!isPlaying || direction.x === -1}
                className="bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 disabled:opacity-40 w-8 h-8 rounded flex items-center justify-center text-emerald-400 border border-neutral-700 shadow-sm transition"
              >
                <ArrowRight size={12} />
              </button>
            </div>
            {/* DOWN */}
            <button
              onClick={() => changeDir(0, 1)}
              disabled={!isPlaying || direction.y === -1}
              className="bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 disabled:opacity-40 w-8 h-8 rounded flex items-center justify-center text-emerald-400 border border-neutral-700 shadow-sm transition"
            >
              <ArrowDown size={12} />
            </button>
          </div>
        </div>
      </div>

      <div className="mt-1 text-[8px] bg-neutral-900/80 border border-neutral-800 p-1 rounded text-center text-gray-400 select-text leading-tight shrink-0">
        {isGameOver ? (
          <span className="text-[#ff5e57] font-semibold">
            💀 哐当！脑袋撞破了，摸鱼大计受挫。
          </span>
        ) : (
          <span>
            💡 电脑键盘 &uarr; &darr; &larr; &rarr; 精准操作，吃完红色打工魂金币。
          </span>
        )}
      </div>
    </div>
  );
}
