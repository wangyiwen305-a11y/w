import React, { useState, useEffect } from "react";
import { UserState, QianduSearchResult, QianduResponse } from "../types";
import { Search, Globe, ChevronLeft, ChevronRight, RotateCw, HelpCircle, Sparkles } from "lucide-react";

interface QianduBrowserProps {
  user: UserState;
  onLoggedClick: () => void;
  onClueDiscovered: (clue: string) => void;
}

export default function QianduBrowser({ user, onLoggedClick, onClueDiscovered }: QianduBrowserProps) {
  const [query, setQuery] = useState("");
  const [currentQuery, setCurrentQuery] = useState("");
  const [page, setPage] = useState(1);
  const [results, setResults] = useState<QianduSearchResult[]>([]);
  const [related, setRelated] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSearchResults = async (searchQuery: string, searchPage: number) => {
    if (!searchQuery.trim()) return;
    setLoading(true);
    setError(null);
    onLoggedClick(); // Log click interaction for stat tracking

    try {
      const response = await fetch("/api/qiandu", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: searchQuery,
          jobType: user.jobType,
          distraction: user.distraction,
          userName: user.name,
          page: searchPage
        })
      });

      if (!response.ok) {
        throw new Error("千度服务器打了个哈欠");
      }

      const data: QianduResponse = await response.json();
      setResults(data.results || []);
      setRelated(data.relatedSearches || []);
      
      if (data.pageTwoClue) {
        onClueDiscovered(data.pageTwoClue);
      }
    } catch (err: any) {
      console.error(err);
      setError("网络好像也有点起不来床。");
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setCurrentQuery(query);
    setPage(1);
    fetchSearchResults(query, 1);
  };

  const handleRelatedClick = (kw: string) => {
    setQuery(kw);
    setCurrentQuery(kw);
    setPage(1);
    fetchSearchResults(kw, 1);
  };

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
    fetchSearchResults(currentQuery, newPage);
  };

  // Perform a default initial funny search
  useEffect(() => {
    const defaultQueries: Record<string, string> = {
      report: "如何用一分钟写出惊艳老板的PPT模板",
      code: "为什么写代码时突然极度渴望去打扫卫生",
      design: "Figma 快捷键与吸猫频率的相关性研究",
      literature: "如何优雅地在毕业综述前言里灌水而不被导师发现",
      meeting: "周会align如何显得高大上实际上划水"
    };
    const initialQuery = defaultQueries[user.jobType] || "为什么我这么困";
    setQuery(initialQuery);
    setCurrentQuery(initialQuery);
    fetchSearchResults(initialQuery, 1);
  }, [user.jobType]);

  return (
    <div id="qiandu-browser-root" className="w-full h-full bg-white flex flex-col font-sans select-text">
      {/* Search browser upper control bar (retro browser search frame style) */}
      <div id="browser-nav-bar" className="bg-[#efebde] p-2 border-b border-gray-300 flex items-center justify-between text-xs gap-2 select-none">
        <div className="flex items-center gap-1 shrink-0">
          <button onClick={() => page > 1 && handlePageChange(page - 1)} disabled={page === 1} className="p-1 rounded hover:bg-gray-200 text-gray-600 disabled:opacity-30">
            <ChevronLeft size={16} />
          </button>
          <button onClick={() => handlePageChange(page + 1)} className="p-1 rounded hover:bg-gray-200 text-gray-600">
            <ChevronRight size={16} />
          </button>
          <button onClick={() => fetchSearchResults(currentQuery, page)} className="p-1 rounded hover:bg-gray-200 text-gray-600">
            <RotateCw size={14} />
          </button>
        </div>

        {/* Browser address field */}
        <div className="flex-grow flex items-center bg-white border border-gray-400 px-2 py-1 rounded max-w-lg shadow-inner">
          <Globe size={14} className="text-emerald-600 mr-2 shrink-0" />
          <span className="text-gray-400 select-none font-mono text-[11px] mr-1">https://</span>
          <input
            type="text"
            readOnly
            className="w-full bg-transparent outline-none focus:outline-none text-gray-700 font-mono text-[11px]"
            value={`www.qiandu.com/search?q=${encodeURIComponent(currentQuery)}&p=${page}`}
          />
        </div>

        <div className="flex items-center gap-1.5 text-[#3b82f6] shrink-0 font-bold select-none text-[11px] bg-blue-50 px-2 py-1 rounded border border-blue-200">
          <Sparkles size={12} className="text-yellow-500 animate-pulse" />
          <span>千度 AI 过滤版</span>
        </div>
      </div>

      {/* Main browser content block */}
      <div id="browser-viewport" className="flex-grow overflow-y-auto p-4 md:p-6 bg-[#fcfaf2]">
        {/* Qiandu Branding Area */}
        <div id="qiandu-search-header" className="flex flex-col items-center justify-center mb-6 select-none">
          <div className="flex items-baseline gap-1">
            <span className="text-3xl font-extrabold text-[#1f4094] tracking-tight">千</span>
            <span className="text-3xl font-extrabold text-orange-500 tracking-tight">度</span>
            <span className="text-xs bg-[#1f4094] text-white font-mono px-1 rounded ml-1 scale-90">Qiandu</span>
          </div>
          <p className="text-gray-400 text-[10px] mt-1 italic">你在搜什么？还是你只是在逃避什么？</p>
        </div>

        {/* Central Search Form */}
        <form onSubmit={handleSearchSubmit} className="flex gap-2 max-w-xl mx-auto mb-6">
          <div className="flex-grow relative border-2 border-[#1f4094] rounded overflow-hidden shadow-sm hover:shadow bg-white flex items-center">
            <input
              id="qiandu-search-input"
              type="text"
              className="w-full px-3 py-2 text-sm outline-none focus:outline-none font-medium text-gray-800"
              placeholder="输入任何想要了解/偷懒的词条..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button type="button" onClick={() => setQuery("")} className="px-2 text-gray-400 text-xs hover:text-gray-600 leading-none">清除</button>
          </div>
          <button
            id="qiandu-search-btn"
            type="submit"
            className="bg-[#1f4094] text-white font-bold px-5 py-2 hover:bg-blue-800 transition rounded flex items-center gap-1 cursor-pointer select-none"
          >
            <Search size={14} />
            <span className="text-sm">千度一下</span>
          </button>
        </form>

        {/* Loading Spinner / Sarcastic Waiting Screen */}
        {loading ? (
          <div id="qiandu-loading" className="flex flex-col items-center justify-center py-12 text-center text-gray-500 max-w-md mx-auto">
            <div className="w-10 h-10 rounded-full border-2 border-orange-500 border-t-transparent animate-spin mb-4"></div>
            <p className="text-sm font-bold text-gray-700">正在利用AI分析您的逃避动机...</p>
            <p className="text-xs text-opacity-70 mt-1 italic">
              “每次你按下搜索纽，就有一个真正的项目文档感到极度空虚。”
            </p>
          </div>
        ) : error ? (
          <div id="qiandu-err" className="text-center py-8 text-red-500 font-bold max-w-md mx-auto">
            <p className="text-sm">{error}</p>
            <p className="text-xs text-gray-400 mt-2">不过没关系，这阻挡不了我们追求自由生活的步伐。</p>
          </div>
        ) : (
          /* Search Results Display Area */
          <div id="qiandu-results-container" className="max-w-2xl mx-auto">
            {/* Sarcastic Summary alert */}
            <div className="bg-orange-50 border-l-4 border-orange-400 px-3 py-2 rounded text-[11px] text-orange-800 mb-4 select-none leading-relaxed flex items-center gap-2">
              <HelpCircle size={14} className="text-orange-500 shrink-0" />
              <span>
                <strong>系统侦测：</strong>您今天的本职工作是<strong>【{
                  user.jobType === "code" ? "核心代码编写" :
                  user.jobType === "report" ? "PPT汇报制作" :
                  user.jobType === "design" ? "Figma界面排版" :
                  user.jobType === "literature" ? "学术引文查阅" : "拉通会议纪要"
                }】</strong>。
                此搜索已被标记为“消极防空”，正在记录您的注意力漏洞。
              </span>
            </div>

            {/* Simulated Search Results List */}
            <div className="flex flex-col gap-5">
              {results.length > 0 ? (
                results.map((resItem, idx) => (
                  <div key={idx} className="bg-white p-4 rounded-lg shadow-sm hover:shadow transition border border-gray-150 relative overflow-hidden group">
                    {resItem.isAd && (
                      <span className="absolute top-0 right-0 bg-yellow-400 text-yellow-950 font-bold px-1.5 py-0.5 text-[9px] uppercase tracking-wider rounded-bl">
                        广告 AD
                      </span>
                    )}
                    <h3 className="font-bold text-sm text-blue-600 hover:text-blue-800 hover:underline cursor-pointer leading-snug">
                      {resItem.title}
                    </h3>
                    <p className="text-xs text-emerald-700 mt-0.5 font-mono truncate">{resItem.url}</p>
                    <p className="text-xs text-gray-600 mt-1.5 leading-relaxed tracking-wide select-text">
                      {resItem.snippet}
                    </p>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-gray-400 text-xs">
                  没有找到相关的借口条目。难道你要认罪去写PPT吗？
                </div>
              )}
            </div>

            {/* Related Queries (相关搜索) */}
            {related.length > 0 && (
              <div className="mt-8 border-t border-gray-200 pt-4">
                <h4 className="font-bold text-xs text-gray-500 mb-2 select-none">其他人都在看：</h4>
                <div className="flex flex-wrap gap-2">
                  {related.map((kw, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleRelatedClick(kw)}
                      className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-full font-medium text-xs transition border border-gray-200"
                    >
                      {kw}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Search Pagination Controller */}
            <div className="flex items-center justify-center gap-4 mt-8 pt-4 border-t border-gray-200 text-xs select-none">
              <button
                type="button"
                onClick={() => handlePageChange(1)}
                className={`px-3 py-1 border rounded transition ${
                  page === 1 ? "bg-[#1f4094] text-white font-bold" : "bg-white text-gray-600 hover:bg-gray-100"
                }`}
              >
                1
              </button>
              <button
                type="button"
                onClick={() => handlePageChange(2)}
                className={`px-3 py-1 border rounded transition relative ${
                  page === 2 ? "bg-[#1f4094] text-white font-bold" : "bg-white text-gray-600 hover:bg-gray-100"
                }`}
              >
                2
                {page !== 2 && (
                  <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                  </span>
                )}
              </button>
              <span className="text-gray-400 italic text-[11px]">
                提示：第一人称桌面线索永远藏在没人翻找的“第 2 页”
              </span>
            </div>

          </div>
        )}
      </div>
    </div>
  );
}
