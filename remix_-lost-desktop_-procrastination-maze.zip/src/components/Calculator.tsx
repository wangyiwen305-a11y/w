import React, { useState } from "react";
import { Delete, CornerDownLeft } from "lucide-react";

interface CalculatorProps {
  onLoggedClick: () => void;
}

export default function Calculator({ onLoggedClick }: CalculatorProps) {
  const [display, setDisplay] = useState("0");
  const [equation, setEquation] = useState("");
  const [isReset, setIsReset] = useState(true);

  const handleNumClick = (num: string) => {
    onLoggedClick();
    if (isReset || display === "0") {
      setDisplay(num);
      setIsReset(false);
    } else {
      setDisplay(display + num);
    }
  };

  const handleOpClick = (op: string) => {
    onLoggedClick();
    setEquation(display + " " + op + " ");
    setIsReset(true);
  };

  const handleClear = () => {
    onLoggedClick();
    setDisplay("0");
    setEquation("");
    setIsReset(true);
  };

  const handleBackspace = () => {
    onLoggedClick();
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay("0");
      setIsReset(true);
    }
  };

  const handleCalculate = () => {
    onLoggedClick();
    if (!equation) return;
    try {
      const fullEq = equation + display;
      // Sanitizing and calculating safely
      // Replace symbols for evaluation
      const sanitized = fullEq
        .replace(/×/g, "*")
        .replace(/÷/g, "/")
        .replace(/[^0-9. +\-*/()]/g, "");
      
      // Safe standard evaluation
      const result = new Function(`return (${sanitized})`)();
      const finalResult = Number(result).toLocaleString(undefined, { maximumFractionDigits: 4 });
      setDisplay(String(finalResult));
      setEquation("");
      setIsReset(true);
    } catch (e) {
      setDisplay("Error");
      setEquation("");
      setIsReset(true);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#efebde] text-black font-mono text-xs select-none border border-neutral-400 p-2 justify-between">
      {/* Menu bar */}
      <div className="flex gap-2 text-[10px] border-b border-neutral-300 pb-1 mb-1.5 text-neutral-600 font-sans">
        <span className="hover:bg-blue-100 px-1 cursor-pointer">编辑(E)</span>
        <span className="hover:bg-blue-100 px-1 cursor-pointer">查看(V)</span>
        <span className="hover:bg-blue-100 px-1 cursor-pointer">帮助(H)</span>
      </div>

      {/* Screen displays */}
      <div className="bg-white border-2 border-inset border-neutral-400 p-2 flex flex-col items-end gap-1 font-mono text-right shrink-0 h-14 justify-center shadow-inner rounded">
        <div className="text-[9px] text-neutral-400 h-3 truncate">
          {equation || ""}
        </div>
        <div className="text-xl font-bold tracking-tight text-neutral-800 truncate w-full">
          {display}
        </div>
      </div>

      {/* Backspace and Clear row */}
      <div className="grid grid-cols-4 gap-1 mt-1.5 shrink-0 font-sans">
        <button
          onClick={handleBackspace}
          className="col-span-2 bg-[#efebde] hover:bg-neutral-300 active:bg-neutral-400 text-red-700 font-bold border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 p-1 flex items-center justify-center gap-1 active:translate-y-0.5 text-[10px]"
        >
          <Delete size={12} />
          <span>退格</span>
        </button>
        <button
          onClick={handleClear}
          className="col-span-2 bg-[#efebde] hover:bg-neutral-300 active:bg-neutral-400 text-red-700 font-bold border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 p-1 active:translate-y-0.5 text-[10px]"
        >
          清除 (C)
        </button>
      </div>

      {/* Main keypad */}
      <div className="grid grid-cols-4 gap-1.5 mt-2 flex-grow">
        {/* Row 1 */}
        <button
          onClick={() => handleNumClick("7")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          7
        </button>
        <button
          onClick={() => handleNumClick("8")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          8
        </button>
        <button
          onClick={() => handleNumClick("9")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          9
        </button>
        <button
          onClick={() => handleOpClick("÷")}
          className="bg-[#efebde] hover:bg-neutral-300 active:bg-neutral-400 font-extrabold text-red-700 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          ÷
        </button>

        {/* Row 2 */}
        <button
          onClick={() => handleNumClick("4")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          4
        </button>
        <button
          onClick={() => handleNumClick("5")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          5
        </button>
        <button
          onClick={() => handleNumClick("6")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          6
        </button>
        <button
          onClick={() => handleOpClick("×")}
          className="bg-[#efebde] hover:bg-neutral-300 active:bg-neutral-400 font-extrabold text-red-700 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          ×
        </button>

        {/* Row 3 */}
        <button
          onClick={() => handleNumClick("1")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          1
        </button>
        <button
          onClick={() => handleNumClick("2")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          2
        </button>
        <button
          onClick={() => handleNumClick("3")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          3
        </button>
        <button
          onClick={() => handleOpClick("-")}
          className="bg-[#efebde] hover:bg-neutral-300 active:bg-neutral-400 font-extrabold text-red-700 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          -
        </button>

        {/* Row 4 */}
        <button
          onClick={() => handleNumClick("0")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          0
        </button>
        <button
          onClick={() => handleNumClick(".")}
          className="bg-[#f2efe4] hover:bg-neutral-200 active:bg-neutral-300 font-bold text-blue-900 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          .
        </button>
        <button
          onClick={handleCalculate}
          className="bg-[#35c338] hover:bg-[#3ecb41] active:bg-green-700 font-extrabold text-white border-2 border-green-500 border-b-green-800 border-r-green-800 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm flex items-center justify-center gap-0.5"
        >
          <CornerDownLeft size={11} className="stroke-[3]" />
          <span>=</span>
        </button>
        <button
          onClick={() => handleOpClick("+")}
          className="bg-[#efebde] hover:bg-neutral-300 active:bg-neutral-400 font-extrabold text-red-700 border-2 border-neutral-400 border-b-neutral-600 border-r-neutral-600 rounded text-center py-2 text-[13px] active:translate-y-0.5 cursor-pointer shadow-sm"
        >
          +
        </button>
      </div>
    </div>
  );
}
