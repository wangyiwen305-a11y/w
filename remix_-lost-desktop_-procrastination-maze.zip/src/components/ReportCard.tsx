import React, { useState, useEffect } from "react";
import { UserState, GameStats } from "../types";
import { Award, ShieldCheck, Power, AlertTriangle, Coffee, Sparkles, AlertCircle } from "lucide-react";

interface ReportCardProps {
  user: UserState;
  stats: GameStats;
  timeSpentSec: number;
}

export default function ReportCard({ user, stats, timeSpentSec }: ReportCardProps) {
  const [advice, setAdvice] = useState("");
  const [loading, setLoading] = useState(true);
  const [shutDownSequence, setShutDownSequence] = useState(false);

  const fetchAdvice = async () => {
    try {
      const response = await fetch("/api/report-advice", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userName: user.name,
          jobType: user.jobType,
          distraction: user.distraction,
          clicks: stats.totalClicks,
          timeSpentSec: timeSpentSec,
        })
      });

      if (response.ok) {
        const data = await response.json();
        setAdvice(data.advice);
      } else {
        throw new Error();
      }
    } catch {
      setAdvice(
        `亲爱的 ${user.name}，你在虚拟桌面上消耗了 ${timeSpentSec} 秒，点击了 ${stats.totalClicks} 次。我们很清楚，拖延并不是因为你懒惰，而是出于脑部对任务规模的应激。越是害怕开头，诱惑就显得越美妙。现在，深呼吸，关掉这个网页，去打开你真实电脑里的那个文件吧。它真的没有藏起来，只是你一直没信心点开。加油，你可以的！`
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdvice();
  }, []);

  const handleShutdown = () => {
    setShutDownSequence(true);
  };

  if (shutDownSequence) {
    return (
      <div id="shutdown-screen" className="w-full h-screen bg-black flex flex-col items-center justify-center text-[#ff9f1c] font-mono select-none px-4 text-center">
        <div className="w-16 h-16 rounded-full border-4 border-amber-500/10 border-t-amber-500 animate-spin mb-6"></div>
        <p className="text-xl font-bold tracking-widest text-amber-500">正在安全注销： {user.name}...</p>
        <p className="text-xs text-opacity-70 mt-3 max-w-sm leading-relaxed text-amber-200">
          意志系统保存完毕。诱惑弹窗正在逐一销毁。
          请放下水杯，关闭目前这个游戏标签页，现在去双击你真实桌面上那个等待已久的文件吧。
        </p>
        <p className="text-[10px] text-gray-500 mt-6 select-none font-mono">
          WINDOWS CEASE-FIRE SIGNAL EMITTED. SYSTEM TERMINATED.
        </p>
      </div>
    );
  }

  const jobLabels: Record<string, string> = {
    code: "核心代码编写 (Java/JS模块)",
    report: "季度汇报PPT大纲",
    design: "APP交互高保原设计稿",
    literature: "毕业论文文献综述",
    meeting: "全员拉通会议纪要"
  };

  const distLabels: Record<string, string> = {
    video: "摸鱼短视频滑滑",
    social: "贴吧论坛热点吃瓜",
    shopping: "薅羊毛一元极速秒杀",
    cats: "沉迷沙雕小萌猫图"
  };

  return (
    <div id="report-card-canvas" className="w-full h-screen bg-[#111827] flex items-center justify-center overflow-y-auto px-4 py-8 font-sans select-none my-auto">
      <div id="report-card-card" className="w-full max-w-2xl bg-white text-gray-800 rounded-2xl shadow-2xl border-2 border-amber-400 overflow-hidden flex flex-col justify-between my-auto">
        
        {/* Upper Brand Badge Banner */}
        <div className="bg-gradient-to-r from-amber-500 to-orange-600 text-white p-6 shadow-md flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <Award size={28} className="text-yellow-200" />
            </div>
            <div>
              <h1 className="text-lg font-black tracking-wide">您的拖延意志解密分析单</h1>
              <p className="text-xs text-opacity-80">LOST DESKTOP: EVALUATED STATEMENT</p>
            </div>
          </div>
          <span className="text-xs bg-black/30 font-mono px-2 py-0.5 rounded tracking-widest">
            {new Date().toLocaleDateString()}
          </span>
        </div>

        {/* Detailed stats grids */}
        <div className="p-6 md:p-8 space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-center">
            
            <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl shadow-sm">
              <span className="block text-[10px] text-gray-400 font-bold uppercase tracking-wider">避重时长</span>
              <span className="font-mono text-xl font-black text-amber-600">
                {Math.floor(timeSpentSec / 60)}分{timeSpentSec % 60}秒
              </span>
            </div>

            <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl shadow-sm">
              <span className="block text-[10px] text-gray-400 font-bold uppercase tracking-wider">躲避任务</span>
              <span className="font-bold text-xs text-gray-700 truncate block mt-1">
                {jobLabels[user.jobType] || user.jobType}
              </span>
            </div>

            <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl shadow-sm">
              <span className="block text-[10px] text-gray-400 font-bold uppercase tracking-wider">最爱糖衣</span>
              <span className="font-bold text-xs text-red-600 truncate block mt-1">
                {distLabels[user.distraction] || user.distraction}
              </span>
            </div>

            <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl shadow-sm">
              <span className="block text-[10px] text-gray-400 font-bold uppercase tracking-wider">鼠标点击</span>
              <span className="font-mono text-xl font-black text-gray-700">
                {stats.totalClicks}次
              </span>
            </div>

          </div>

          {/* Sarcastic psychologist AI generated comment box */}
          <div className="bg-amber-50 border-2 border-dashed border-amber-300 rounded-xl p-5 relative overflow-hidden">
            <div className="flex items-center gap-2 mb-2 font-black text-xs text-amber-800">
              <Sparkles size={16} className="text-amber-500" />
              <span>AI心理咨询顾问的密语评述：</span>
            </div>

            {loading ? (
              <div className="flex items-center text-gray-500 gap-2 text-xs py-2 italic font-medium">
                <Coffee size={14} className="animate-spin text-amber-500" />
                <span>正在根据您的滑鼠微颤幅度和消极逃避动作，精心编纂个性化诊疗单...</span>
              </div>
            ) : (
              <p className="text-xs text-amber-950 leading-relaxed font-semibold italic tracking-wide select-text">
                “{advice}”
              </p>
            )}

            <span className="absolute -bottom-10 -right-10 opacity-5 font-serif italic text-9xl text-amber-300 pointer-events-none select-none">
              AI
            </span>
          </div>

          <div className="bg-rose-50 border-l-4 border-rose-500 p-4 rounded text-xs text-rose-800 leading-normal flex items-start gap-3">
            <AlertCircle size={18} className="text-rose-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-extrabold text-sm mb-1 text-rose-950">
                你现在关掉它，去打开你真正的文件吧。
              </p>
              <p className="font-medium text-opacity-90">
                真正的那个文档，它并没有藏在这。它正静静地躺在你真实的主桌面文件夹里，它既不会吐火咬你，也没有在脑海里想象的那个不可逾越。你只需要花一分钟双击打开并打下第一个字母，迷宫就会瞬间融化。
              </p>
            </div>
          </div>
        </div>

        {/* Lower summary action row */}
        <div className="bg-slate-50 px-6 py-5 border-t border-slate-100 flex flex-col md:flex-row gap-4 items-center justify-between text-xs select-none shadow-inner shrink-0">
          <div className="flex items-center gap-2 text-gray-500">
            <ShieldCheck size={18} className="text-emerald-500" />
            <span className="font-medium">今日份摸鱼脱锚计划 已圆满登记</span>
          </div>
          <button
            id="report-shutdown-btn"
            onClick={handleShutdown}
            className="flex items-center justify-center gap-1.5 px-6 py-3 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 text-white font-extrabold rounded-lg shadow-md hover:shadow-lg transition cursor-pointer select-none leading-none animate-pulse"
          >
            <Power size={14} />
            <span className="text-xs uppercase tracking-widest">确认注销：关闭桌面去工作吧 🌿</span>
          </button>
        </div>

      </div>
    </div>
  );
}
