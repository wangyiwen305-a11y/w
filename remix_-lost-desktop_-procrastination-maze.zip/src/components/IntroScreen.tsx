import React, { useState, useEffect } from "react";
import { Search, Monitor, Cpu, Database, Wifi } from "lucide-react";

interface IntroScreenProps {
  onComplete: () => void;
}

type BootStage = "bios" | "os-loading" | "main-title";

export default function IntroScreen({ onComplete }: IntroScreenProps) {
  const [bootStage, setBootStage] = useState<BootStage>("bios");
  const [biosLogs, setBiosLogs] = useState<string[]>([]);
  const [osProgress, setOsProgress] = useState(0);

  const fullText = "迷失桌面：拖延症迷宫";
  const [typedText, setTypedText] = useState("");
  const [showCursor, setShowCursor] = useState(true);
  const [typingDone, setTypingDone] = useState(false);

  // 1. BIOS Log printing timeline
  useEffect(() => {
    if (bootStage !== "bios") return;

    const allLogs = [
      "AMIBIOS(C) 2004 American Megatrends, Inc.",
      "AISTUDIO-OS ACPI BIOS Revision 4.01",
      "CPU: Intel(R) Core(TM) i9-13900K @ 3.00GHz",
      "Speed: 3000MHz  Count: 24 Cores / 32 Threads",
      "Memory Test: 65,536,000KB OK (DDR5-5600 Dual Channel)",
      "Detecting Storage Devices...",
      "  Primary Master: SSD NVMe Samsung 990 PRO 2TB [OK]",
      "  Secondary Slave: HDD SATA Seagate BarraCuda 4TB [OK]",
      "Detecting USB Devices... Keyboard, Mouse, Webcam [OK]",
      "Allocating Host System Shared Hardware Resources...",
      "Initializing AI-Logic Virtual Coprocessor Layer...",
      "Loading Security Sandboxed Attention Control Ring 0...",
      "SYSTEM RUN LEVEL: 5 (MULTI-USER GRAPHICAL WORKSTATION)",
      "Booting from Primary Drive C: \\WINDOWS\\system32\\winload.exe...",
    ];

    let currentLogIdx = 0;
    const interval = setInterval(() => {
      if (currentLogIdx < allLogs.length) {
        setBiosLogs((prev) => [...prev, allLogs[currentLogIdx]]);
        currentLogIdx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setBootStage("os-loading");
        }, 600);
      }
    }, 120);

    return () => clearInterval(interval);
  }, [bootStage]);

  // 2. OS Loading Progress timeline
  useEffect(() => {
    if (bootStage !== "os-loading") return;

    const interval = setInterval(() => {
      setOsProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setBootStage("main-title");
          }, 500);
          return 100;
        }
        // Random incremental hops
        const increment = Math.floor(Math.random() * 15) + 5;
        return Math.min(prev + increment, 100);
      });
    }, 150);

    return () => clearInterval(interval);
  }, [bootStage]);

  // 3. Main Title Typewriter effect
  useEffect(() => {
    if (bootStage !== "main-title") return;

    let index = 0;
    const interval = setInterval(() => {
      if (index < fullText.length) {
        setTypedText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
        setTypingDone(true);
      }
    }, 150);

    return () => clearInterval(interval);
  }, [bootStage]);

  // Blinking caret effect
  useEffect(() => {
    const cursorInterval = setInterval(() => {
      setShowCursor((prev) => !prev);
    }, 450);
    return () => clearInterval(cursorInterval);
  }, []);

  return (
    <div className="relative w-full h-screen bg-black text-white font-mono select-none overflow-hidden flex items-center justify-center crt-scanlines">
      
      {/* 1. BIOS STAGE */}
      {bootStage === "bios" && (
        <div className="w-full h-full p-8 max-w-4xl text-[11px] leading-snug text-neutral-300 font-mono flex flex-col justify-between">
          <div className="space-y-1">
            <div className="flex justify-between items-start border-b border-neutral-800 pb-2 mb-4">
              <div>
                <p className="font-extrabold text-white text-xs">AISTUDIO SYSTEM BIOS v4.02</p>
                <p className="text-neutral-500">Released: 06/27/2026. Codebase: DeepMind-X3</p>
              </div>
              <div className="flex items-center gap-1.5 text-red-500 font-bold bg-red-500/10 px-2 py-0.5 border border-red-500/20 rounded">
                <span className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
                <span>SECURE BOOT ACTIVE</span>
              </div>
            </div>

            {/* Scrolling bios logs */}
            <div className="space-y-1 select-text">
              {biosLogs.map((log, idx) => (
                <div key={idx} className="flex gap-2">
                  <span className="text-neutral-500">[{idx.toString().padStart(2, "0")}]</span>
                  <span>{log}</span>
                </div>
              ))}
              {/* Active blinking bios cursor */}
              <div className="flex gap-2 items-center text-[#38bdf8]">
                <span>[SYSTEM] Checking for bootable device...</span>
                <span className="w-2 h-4 bg-[#38bdf8] animate-pulse" />
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center text-neutral-500 text-[10px] border-t border-neutral-800 pt-3">
            <p>Press <kbd className="bg-neutral-800 text-neutral-300 px-1 rounded border border-neutral-700">DEL</kbd> or <kbd className="bg-neutral-800 text-neutral-300 px-1 rounded border border-neutral-700">F2</kbd> to enter Setup Mode</p>
            <p>DRAM Clock: 5600MT/s | NVMe Gen4 Enabled</p>
          </div>
        </div>
      )}

      {/* 2. OS BOOT LOADER STAGE */}
      {bootStage === "os-loading" && (
        <div className="flex flex-col items-center justify-center gap-6">
          {/* Classic vintage OS logo */}
          <div className="text-center">
            <div className="flex justify-center items-center gap-2 text-white mb-2">
              <span className="text-4xl">💻</span>
              <span className="text-2xl font-black font-sans tracking-tight">OS-AISTUDIO</span>
            </div>
            <p className="text-neutral-400 text-xs tracking-widest uppercase">Professional Workstation Edition</p>
          </div>

          {/* Classic Windows XP-style blue rectangle rolling progress bar */}
          <div className="w-64 h-[12px] bg-[#111] rounded-full border border-neutral-800 p-0.5 overflow-hidden relative">
            <div 
              className="h-full bg-gradient-to-r from-blue-600 via-sky-400 to-blue-600 rounded-full transition-all duration-150"
              style={{ width: `${osProgress}%` }}
            />
          </div>

          <div className="text-center">
            <p className="text-xs text-neutral-500 animate-pulse font-mono uppercase tracking-wide">
              正在解压主引导扇区并初始化内存... {osProgress}%
            </p>
          </div>
        </div>
      )}

      {/* 3. MAIN TITLE INTRO SCREEN (UPGRADED WITH HIGH FIDELITY CRT FRAME) */}
      {bootStage === "main-title" && (
        <div 
          className="relative w-full h-screen bg-gradient-to-b from-[#15349e] via-[#2f60cc] to-[#4c73d6] flex items-center justify-center select-none overflow-hidden"
        >
          {/* Authentic screen glare and scanline highlights */}
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-transparent via-white/5 to-transparent z-30 mix-blend-overlay" />
          <div className="absolute top-0 left-0 w-full h-1 bg-[#0f2d80] z-30" />
          
          {/* Animated decorative wallpaper bands for XP authenticity */}
          <div className="absolute top-1/4 -left-20 w-[600px] h-[300px] bg-gradient-to-br from-blue-400/10 to-transparent rounded-full filter blur-[120px] pointer-events-none rotate-12" />
          <div className="absolute bottom-1/4 -right-20 w-[700px] h-[400px] bg-gradient-to-tl from-sky-300/15 to-transparent rounded-full filter blur-[150px] pointer-events-none -rotate-12" />

          {/* Core Interactive Terminal Window */}
          <div className="w-full max-w-[620px] px-6 z-20 flex flex-col items-center gap-6">
            
            {/* Visual Icon branding */}
            <div className="text-center mb-1 flex flex-col items-center">
              <div className="w-16 h-16 bg-white/10 backdrop-blur rounded-2xl flex items-center justify-center shadow-lg border border-white/20 mb-3 animate-pulse">
                <Monitor className="text-white w-9 h-9" />
              </div>
              <h1 className="text-white text-5xl font-black tracking-widest uppercase font-mono drop-shadow-[0_3px_5px_rgba(0,0,0,0.5)]">
                Win Seek
              </h1>
              <p className="text-sky-200 text-[10px] font-mono tracking-widest mt-1.5 uppercase drop-shadow font-bold flex items-center gap-1.5 bg-sky-950/40 px-3 py-1 rounded-full border border-sky-800/30">
                <Cpu size={12} className="text-sky-400 animate-spin" />
                <span>ATTENTION DEFENSE WORKSTATION v1.2</span>
              </p>
            </div>

            {/* Realistic Search Bar mimicking high-end UI search interfaces */}
            <div 
              className="w-full h-[66px] flex rounded-[28px] p-1 bg-[#474a54] relative group"
              style={{
                boxShadow: "0 6px 0px 0px #1c1d22, 0 16px 32px rgba(0, 0, 0, 0.4)"
              }}
            >
              {/* Input field wrapper */}
              <div className="flex-1 bg-white h-full flex items-center pl-6 pr-3 rounded-l-[24px]">
                <div className="flex items-center gap-1 min-w-0 pr-1 w-full">
                  <span className="text-[#1a1a1a] text-lg font-sans font-extrabold tracking-tight select-none truncate">
                    {typedText}
                  </span>
                  
                  {/* Vertical blinking caret */}
                  <span 
                    className={`w-[2.5px] h-[24px] bg-[#1a1a1a] transition-opacity duration-100 ${
                      showCursor ? "opacity-100" : "opacity-0"
                    }`}
                  />
                </div>
              </div>

              {/* Action Search button with clean OS style */}
              <button
                onClick={() => {
                  if (typingDone) {
                    onComplete();
                  }
                }}
                disabled={!typingDone}
                className={`w-[78px] h-full rounded-r-[24px] flex items-center justify-center transition-all ${
                  typingDone 
                    ? "bg-[#606470] text-white hover:bg-[#6c717f] active:bg-[#4d5059] cursor-pointer" 
                    : "bg-[#606470] text-neutral-400 cursor-not-allowed"
                }`}
                title={typingDone ? "解锁运行环境" : "正在加载初始化命令序列..."}
              >
                <Search size={28} className="stroke-[3.5] text-white group-hover:scale-105 transition" />
              </button>
            </div>

            {/* Human Slogan description */}
            <div className="text-center h-10 flex items-center justify-center bg-black/20 backdrop-blur-sm px-6 py-2 rounded-full border border-white/5 shadow-inner">
              <p 
                className={`text-white text-xs font-semibold tracking-wider transition-all duration-700 transform ${
                  typingDone ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-2"
                }`}
              >
                ⚙️ 注意力沙盒已锁定，双击任意搜索结果翻页至 <span className="text-yellow-300 font-bold underline px-0.5 font-mono">第二页</span> 获取解密密钥！
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
