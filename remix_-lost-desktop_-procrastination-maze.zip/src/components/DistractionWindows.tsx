import React, { useState } from "react";
import { UserState } from "../types";
import { AppWindowType } from "../types";
import { Heart, MessageCircle, Share2, Award, Flame, ShoppingCart, RefreshCcw, ThumbsUp, AlertCircle } from "lucide-react";

interface DistractionProps {
  user: UserState;
  appType: AppWindowType;
  onLoggedClick: () => void;
}

export default function DistractionWindows({ user, appType, onLoggedClick }: DistractionProps) {
  React.useEffect(() => {
    onLoggedClick(); // Log click automatically when app changes or mounts safely
  }, [appType]);

  switch (appType) {
    case "tiktok":
      return <TikTokFeed user={user} onLoggedClick={onLoggedClick} />;
    case "tieba":
      return <TiebaFeed user={user} onLoggedClick={onLoggedClick} />;
    case "shopping":
      return <ShoppingDeals user={user} onLoggedClick={onLoggedClick} />;
    default:
      return <FallbackDistraction onLoggedClick={onLoggedClick} />;
  }
}

// 1. TikTok Slider simulation
function TikTokFeed({ user, onLoggedClick }: { user: UserState; onLoggedClick: () => void }) {
  const [index, setIndex] = useState(0);
  const [likes, setLikes] = useState([2412, 5991, 1083, 3032]);
  const [hasLiked, setHasLiked] = useState([false, false, false, false]);

  const tiktoks = [
    {
      title: "@搞笑博主大春",
      desc: "当代恶魔契约：我再看最后一个视频就去写PPT，绝对真的！😭（此时深夜两点）",
      emoji: "🎬 (づ｡◕‿‿◕｡)づ 📱",
      music: "♬ 大春摸鱼之歌 - 原声",
      comment: "【热评第一】：博主在我床底下装摄像头了吗？怎么完全一样啊！"
    },
    {
      title: "@萌宠天国小橘",
      desc: "小胖猫小橘拒绝加班，它选择把电脑线咬断！这就是真正的勇士！🐈",
      emoji: "🐱 (≈ㅇᆽㅇ≈)♡ 💤",
      music: "♬ 小猫咪摇摆舞 - 萌宠专区",
      comment: "【热评第一】：小橘，请替我咬断我的网线！给你开三个罐罐！"
    },
    {
      title: "@说心理学的老王",
      desc: "深度解剖：你不是不愿写代码，你其实只是觉得这行代码配不上你天才的意志。(自我洗脑完毕)",
      emoji: "🧠 ◝(⁰▿⁰)◜ ☕",
      music: "♬ 深度睡眠白噪音 - 双侧声相",
      comment: "【热评第一】：听完心理学说，我更心安理得地来刷视频了。"
    },
    {
      title: "@省钱小能手",
      desc: "程序员防猝死必备零食评测：薯片、可乐与极速脱发的因果链分析。点赞下周防脱！",
      emoji: "🍟 🥤 (・`ω´・)",
      music: "♬ 重金属养生乐 - 摇滚",
      comment: "【热评第一】：一边喝可乐，一边摸鱼，感觉灵魂在升华。"
    }
  ];

  const handleNext = () => {
    onLoggedClick();
    setIndex((prev) => (prev + 1) % tiktoks.length);
  };

  const handleLike = () => {
    onLoggedClick();
    const newLikes = [...likes];
    const newHasLiked = [...hasLiked];
    if (!newHasLiked[index]) {
      newLikes[index] += 1;
      newHasLiked[index] = true;
    } else {
      newLikes[index] -= 1;
      newHasLiked[index] = false;
    }
    setLikes(newLikes);
    setHasLiked(newHasLiked);
  };

  const cur = tiktoks[index];

  return (
    <div className="w-full h-full bg-black text-white flex select-none font-sans overflow-hidden">
      {/* Video Sim Viewport */}
      <div className="flex-grow flex flex-col items-center justify-center p-4 relative bg-[#111]">
        
        {/* Abs icon represent of clip video */}
        <div className="w-48 h-48 bg-gradient-to-tr from-purple-900 to-[#121212] border border-zinc-700 rounded-full flex flex-col items-center justify-center relative animate-pulse shadow-2xl mb-4">
          <div className="text-5xl mb-2">{cur.emoji}</div>
          <span className="text-[10px] text-zinc-500 font-mono">LOOPING VIDEO CHUNK...</span>
        </div>

        {/* Video captions */}
        <div className="w-full max-w-xs space-y-2 text-xs">
          <div className="font-bold text-sm text-yellow-300">{cur.title}</div>
          <p className="text-gray-300 leading-relaxed font-medium">{cur.desc}</p>
          <div className="text-[10px] text-gray-400 font-mono truncate">{cur.music}</div>
          
          <div className="bg-zinc-900/80 p-2 rounded border border-zinc-800 text-[10px] text-zinc-400">
            {cur.comment}
          </div>
        </div>

        {/* Floating next bar */}
        <button
          onClick={handleNext}
          className="mt-4 px-6 py-2 bg-gradient-to-r from-[#ff0050] to-[#00f2fe] text-black font-extrabold text-xs uppercase tracking-widest rounded-full shadow hover:scale-105 transition cursor-pointer"
        >
          下一条视频 &gt;
        </button>
      </div>

      {/* Side Action Column */}
      <div className="w-14 shrink-0 bg-[#161616] border-l border-neutral-900 flex flex-col items-center justify-center gap-6 text-[10px] text-gray-400 py-3 select-none">
        
        <button onClick={handleLike} className="flex flex-col items-center gap-1 group hover:text-white">
          <Heart size={20} className={`${hasLiked[index] ? "text-red-500 fill-red-500" : "text-gray-400 group-hover:text-red-400"}`} />
          <span>{likes[index]}</span>
        </button>

        <button onClick={onLoggedClick} className="flex flex-col items-center gap-1 hover:text-white">
          <MessageCircle size={20} />
          <span>{likes[index] / 10}</span>
        </button>

        <button onClick={onLoggedClick} className="flex flex-col items-center gap-1 hover:text-white">
          <Share2 size={18} />
          <span>分享</span>
        </button>

        <div className="h-px bg-neutral-800 w-1/2 my-1"></div>

        <span className="text-[8px] tracking-tighter text-neutral-500 uppercase rotate-90 my-2 font-mono">TikTok</span>
      </div>
    </div>
  );
}

// 2. Forums or Tieba feed
function TiebaFeed({ user, onLoggedClick }: { user: UserState; onLoggedClick: () => void }) {
  const [thumbs, setThumbs] = useState([321, 54, 12, 110]);
  const [clickedUp, setClickedUp] = useState([false, false, false, false]);

  const threads = [
    {
      author: "无边界闭环大师",
      text: "【火帖】大家别骗自己了，那个‘${user.jobType === 'code' ? '核心代码' : 'PPT草案'}’你们能写完我直播吃键盘。别做梦了，赶紧来贴吧听老哥爆料今日大厂降本增效瓜！"
    },
    {
      author: "打渔老黄",
      text: "回复楼上：本来准备写项目文档的安全模块的，结果在千度的相关搜索里点了两下，迷路点进这个贴吧，已经看了三个小时了，楼主你要对我的无业负责！"
    },
    {
      author: "爱吃薯条的主管",
      text: "【置顶】紧急呼叫！小${user.name}在哪？王主管发起的‘同步会议’就等他一个人解释底色调色盘了。听说他在摸鱼贴吧，谁看见他了麻烦踢他一脚！！！"
    },
    {
      author: "意志力残渣",
      text: "其实关键解密口令就藏在千度搜索（www.qiandu.com）中，但你得把它翻到没有人会进入的『第 2 页』才行。那里隐藏着救赎。我也只去过一次。"
    }
  ];

  const handleLikeThread = (idx: number) => {
    onLoggedClick();
    const newThumbs = [...thumbs];
    const newClicked = [...clickedUp];
    if (!newClicked[idx]) {
      newThumbs[idx] += 1;
      newClicked[idx] = true;
    } else {
      newThumbs[idx] -= 1;
      newClicked[idx] = false;
    }
    setThumbs(newThumbs);
    setClickedUp(newClicked);
  };

  return (
    <div className="w-full h-full bg-[#f6f6f6] text-gray-800 p-4 font-sans flex flex-col flex-grow select-text overflow-y-auto">
      <div className="border-b-2 border-orange-500 pb-2 mb-4 flex items-center justify-between select-none shrink-0">
        <div>
          <h4 className="font-extrabold text-orange-600 text-sm flex items-center gap-1">
            <Flame size={16} />
            <span>摸鱼聚集区 贴吧 (Claw-Forum)</span>
          </h4>
          <p className="text-[10px] text-gray-400">关注：284万 | 帖子：4.8亿</p>
        </div>
        <button onClick={onLoggedClick} className="p-1 rounded hover:bg-gray-200">
          <RefreshCcw size={12} className="text-gray-500" />
        </button>
      </div>

      <div className="flex-grow space-y-4">
        {threads.map((item, idx) => {
          // Render variables in text
          const renderedText = item.text.replace("${user.jobType === 'code' ? '核心代码' : 'PPT草案'}", 
            user.jobType === "code" ? "核心代码" : "PPT草案"
          ).replace("${user.name}", user.name);

          return (
            <div key={idx} className="bg-white p-3 rounded border border-gray-200 shadow-sm leading-relaxed">
              <div className="flex items-center gap-1.5 mb-1 select-none">
                <div className="w-6 h-6 rounded-full bg-orange-100 flex items-center justify-center text-xs font-bold text-orange-600 border border-orange-200">
                  {item.author[0]}
                </div>
                <div>
                  <span className="font-bold text-xs text-gray-700">{item.author}</span>
                  <span className="text-[9px] text-gray-400 ml-2">第 {idx + 1} 楼</span>
                </div>
              </div>
              <p className="text-xs text-gray-600 tracking-wide font-medium">{renderedText}</p>
              
              <div className="flex items-center justify-end gap-3 mt-2 text-[10px] text-gray-400 select-none">
                <button
                  onClick={() => handleLikeThread(idx)}
                  className={`flex items-center gap-1 hover:text-orange-500 ${clickedUp[idx] ? "text-orange-600 font-bold" : ""}`}
                >
                  <ThumbsUp size={12} />
                  <span>{thumbs[idx]}</span>
                </button>
                <span className="hover:underline hover:text-gray-600 cursor-pointer">回复</span>
                <span className="hover:underline hover:text-gray-600 cursor-pointer">举报</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// 3. E-commerce simulated deal flash page
function ShoppingDeals({ user, onLoggedClick }: { user: UserState; onLoggedClick: () => void }) {
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleBuy = () => {
    onLoggedClick();
    setSuccessMsg("抢购失败：您的注意力过于分散，导致浏览器响应被安全沙盒阻断！正在重定向到工作重灾区。");
    setTimeout(() => {
      setSuccessMsg(null);
    }, 4500);
  };

  return (
    <div className="w-full h-full bg-amber-50 text-red-900 p-4 font-sans flex flex-col justify-between overflow-y-auto">
      <div className="bg-red-600 text-white rounded p-3 select-none flex items-center justify-between shrink-0 mb-3">
        <div>
          <h4 className="font-black text-sm tracking-wider flex items-center gap-1">
            <ShoppingCart size={16} />
            <span>薅羊毛·限时秒杀特惠</span>
          </h4>
          <p className="text-[9px] text-amber-200 uppercase font-mono">Flash sales 1 Yuan free shipping</p>
        </div>
        <div className="bg-amber-400 text-red-900 border border-white font-bold p-1 rounded text-center text-xs scale-90">
          <div>倒计时</div>
          <div className="font-mono text-[10px] leading-none text-red-700 animate-ping">0.2s</div>
        </div>
      </div>

      <div className="flex-grow flex flex-col justify-center items-center py-2 bg-white rounded border border-amber-200 shadow-inner px-4 text-center">
        <div className="text-4xl mb-2 select-none">⌨️ 🍿 🖱️</div>
        <h5 className="font-bold text-xs text-red-950">摸鱼大礼包：人体工学防猝死超轻静音键盘</h5>
        <p className="text-[10px] text-gray-400 mt-1">
          配套包含：特脆麻辣薯片*3袋 + 老板走过防漏隔光镜膜。限小王或小帕专享。
        </p>
        <div className="flex items-center gap-2 mt-3 select-none">
          <span className="text-gray-400 text-xs line-through">原价: ¥999.00</span>
          <span className="text-red-600 font-extrabold text-lg animate-pulse">秒杀价: ¥1.00</span>
        </div>

        {successMsg && (
          <div className="bg-red-50 border border-red-200 mt-3 p-2 rounded text-[10px] text-red-700 font-medium leading-relaxed flex items-start gap-1">
            <AlertCircle size={12} className="text-red-500 shrink-0 mt-0.5" />
            <p>{successMsg}</p>
          </div>
        )}
      </div>

      <button
        id="shopping-buy-btn"
        onClick={handleBuy}
        className="w-full mt-3 bg-red-600 text-white hover:bg-red-700 py-2.5 font-extrabold text-xs uppercase tracking-widest rounded transition cursor-pointer select-none"
      >
        立即开抢 (剩 2 件)
      </button>
    </div>
  );
}

// Fallback cats view
function FallbackDistraction({ onLoggedClick }: { onLoggedClick: () => void }) {
  return (
    <div className="w-full h-full bg-indigo-50 text-indigo-950 p-4 font-sans flex flex-col items-center justify-center text-center">
      <div className="text-5xl mb-3 animate-bounce select-none">🐈 🐾</div>
      <h4 className="font-extrabold text-[#1f4094] text-sm">猫咪吸吸乐模块</h4>
      <p className="text-xs text-indigo-700 mt-2 max-w-xs leading-relaxed">
        “你点开了这张猫片。猫咪盯着你，像是在疑惑你的PPT为什么还没有新建一页。”
      </p>
      <button
        onClick={onLoggedClick}
        className="mt-4 px-4 py-1.5 border border-indigo-400 hover:bg-indigo-100 text-[#1f4094] font-bold text-xs rounded transition"
      >
        吸下一只猫 🐾
      </button>
    </div>
  );
}
