import React, { useState, useEffect, useRef } from "react";
import { UserState, AppWindowType, WindowInstance, GameStats, DesktopItem } from "../types";
import QianduBrowser from "./QianduBrowser";
import BossChat from "./BossChat";
import DistractionWindows from "./DistractionWindows";
import WebcamParody from "./WebcamParody";
import TetrisGame from "./TetrisGame";
import SnakeGame from "./SnakeGame";
import StocksApp from "./StocksApp";
import Calculator from "./Calculator";
import { 
  Monitor, Folder, Trash2, ShieldAlert, Sparkles, AlertCircle, FileText, Check, 
  Settings, Power, X, Minus, Square, ExternalLink, MessageSquare, ChevronRight, Play,
  RefreshCw, Volume2, VolumeX, Eye, Flame, Bomb, Music, Tv, TrendingUp, Grid, Camera,
  ShoppingCart, Globe, Layout, Sliders, Smartphone, Laptop, Sparkle, Calculator as CalcIcon
} from "lucide-react";

interface DesktopLayoutProps {
  user: UserState;
  onFinishGame: (stats: GameStats) => void;
}

type ThemeMode = "xp" | "dark" | "rose";
type WallpaperPreset = "bliss" | "modern" | "macos" | "classic" | "cyberpunk";

export default function DesktopLayout({ user, onFinishGame }: DesktopLayoutProps) {
  // Statics tracking
  const [stats, setStats] = useState<GameStats>({
    startTime: Date.now(),
    totalClicks: 0,
    distractionsCount: 0,
    bossUrges: 0,
    searchesCount: 0,
    level: 0,
  });

  // Desktop Visual Preferences states
  const [wallpaper, setWallpaper] = useState<WallpaperPreset>("bliss");
  const [theme, setTheme] = useState<ThemeMode>("xp");
  const [crtFilter, setCrtFilter] = useState(true);
  const [taskbarPosition, setTaskbarPosition] = useState<"bottom" | "top">("bottom");
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Diary editing state
  const [diaryContent, setDiaryContent] = useState(`【拖延修仙记 - 防猝死绝密日志.txt】

---- 编纂人：那个发誓今早打完会议PPT的职场凡人 ----

● 09:30 - “我洗了杯子，冲了上好咖啡，深吸一口气准备写PPT大纲！不过先查看一下手机消息吧。”

● 10:15 - “看到拼多拼限时秒杀，隔壁工位程序员甚至给猫猫买了一个小领结。贴吧今天讨论年终奖，真是精彩绝伦。PPT还没新建。”

● 12:00 - “王经理发消息问进度了。我回他说‘PPT正在输出中，云版本由于沙盒机制出问题打不开了。’
  真机智，他应该不知道我在偷看第二只猫猫。顺手用拼多拼下了单。”

● 14:00 - “连着刷了20条抖音！猫片太好好看。我脑海里的偷懒意志在无声狂欢。”

● 14:35 - “我听王主管的内人透露，其实那个核心IDE编辑器/Q2 PPT被安全沙盒层层锁定，想要解密启动，需要去【千度】中搜索摸鱼相关的任意词条，
然后点击最下方翻到【第 2 页】。在这个极荒凉的极低点击页最底下藏着一个以‘XP’开头的六位原始密令密钥。输入它才能启动开始工作！
真麻烦，不过不如先来一把像素扫雷放松下心情。”

● 16:15 - “为什么天亮了又黑，心率在疯狂飙升，罪恶感在不停敲打大脑。我真的要做事了。看完了最后这只猫咪，我就一定启动编辑器开机干活！”`);

  const [notepadSaveMessage, setNotepadSaveMessage] = useState("");

  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; visible: boolean } | null>(null);

  // Highlight state for single-clicking icons
  const [selectedIcon, setSelectedIcon] = useState<string | null>(null);

  // Simulated Telemetry state for Settings CPU monitor
  const [cpuUsage, setCpuUsage] = useState(32);
  const [ramUsage, setRamUsage] = useState(14.8);
  const [attentionIndex, setAttentionIndex] = useState(100);

  // Play audio blips using Web Audio API
  const playAudioClick = (pitch = 440, type: OscillatorType = "sine") => {
    if (!soundEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(pitch, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.05, ctx.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.15);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch {}
  };

  // Windows State Manager
  const [windows, setWindows] = useState<Record<AppWindowType, WindowInstance>>({
    "qiandu": { id: "qiandu", label: "千度(Qiandu) AI 恶搞学术浏览器", icon: "Globe", x: 80, y: 40, w: 720, h: 480, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 10 },
    "boss": { id: "boss", label: "企业微信 (Corp-WeChat) - 攻坚拉温群", icon: "MessageSquare", x: 140, y: 60, w: 420, h: 450, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 11 },
    "tiktok": { id: "tiktok", label: "抖音滑滑 (TikTok-PC)", icon: "Play", x: 300, y: 120, w: 400, h: 460, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 5 },
    "tieba": { id: "tieba", label: "摸鱼爆料贴吧 (Tieba)", icon: "Flame", x: 180, y: 150, w: 450, h: 440, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 5 },
    "shopping": { id: "shopping", label: "薅羊毛秒杀超级专场", icon: "ShoppingCart", x: 220, y: 180, w: 420, h: 400, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 5 },
    "camera": { id: "camera", label: "Capture Pictures (意志监视中心)", icon: "Camera", x: 340, y: 80, w: 500, h: 420, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 12 },
    "work-app": { id: "work-app", label: `虚拟办公终点: ${user.jobType === "code" ? "IDE核心代码工程.ts" : "核心汇报PPT设计板"}`, icon: "FileText", x: 120, y: 100, w: 520, h: 410, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 13 },
    "my-computer": { id: "my-computer", label: "我的电脑 (My Computer)", icon: "Monitor", x: 50, y: 80, w: 400, h: 300, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 5 },
    "recycle-bin": { id: "recycle-bin", label: "回收站 (Recycle Bin)", icon: "Trash2", x: 100, y: 120, w: 400, h: 300, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 5 },
    "minesweeper": { id: "minesweeper", label: "游戏机: 经典扫雷 (Minesweeper)", icon: "Bomb", x: 240, y: 70, w: 340, h: 420, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 6 },
    "music": { id: "music", label: "点点 Lofi 像素音乐盒", icon: "Music", x: 280, y: 105, w: 380, h: 370, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 6 },
    "diary": { id: "diary", label: "摸鱼大麻子防猝死日记.txt", icon: "FileText", x: 320, y: 140, w: 440, h: 400, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 6 },
    "tetris": { id: "tetris", label: "摸鱼游戏: 俄罗斯经典方块 (Tetris)", icon: "Grid", x: 260, y: 90, w: 350, h: 440, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 6 },
    "snake": { id: "snake", label: "摸鱼游戏: 贪吃蛇大作战 (Snake)", icon: "Tv", x: 250, y: 100, w: 360, h: 450, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 6 },
    "stocks": { id: "stocks", label: "同花顺证券(摸鱼专属红利版) v12.1", icon: "TrendingUp", x: 200, y: 80, w: 600, h: 460, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 6 },
    "calculator": { id: "calculator", label: "系统计算器 (Calculator)", icon: "Calculator", x: 340, y: 150, w: 260, h: 330, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 6 },
    "settings": { id: "settings", label: "控制面板 (Control Panel)", icon: "Settings", x: 170, y: 90, w: 520, h: 435, isMinimized: false, isMaximized: false, isOpen: false, zIndex: 7 }
  });

  const [topZIndex, setTopZIndex] = useState(15);
  const [startMenuOpen, setStartMenuOpen] = useState(false);
  const [systemTime, setSystemTime] = useState("");
  const [clueCollected, setClueCollected] = useState("");
  const [showClueAlert, setShowClueAlert] = useState(false);

  // 1. Minesweeper States
  const [minesBoard, setMinesBoard] = useState<Array<{ id: number; r: number; c: number; isMine: boolean; isRevealed: boolean; isFlagged: boolean; count: number }>>([]);
  const [minesStatus, setMinesStatus] = useState<"playing" | "won" | "lost">("playing");

  const resetMinesweeper = () => {
    const board = [];
    const totalRows = 6;
    const totalCols = 6;
    const mineCount = 6;

    for (let r = 0; r < totalRows; r++) {
      for (let c = 0; c < totalCols; c++) {
        board.push({
          id: r * totalCols + c,
          r,
          c,
          isMine: false,
          isRevealed: false,
          isFlagged: false,
          count: 0,
        });
      }
    }

    let allocated = 0;
    while (allocated < mineCount) {
      const idx = Math.floor(Math.random() * board.length);
      if (!board[idx].isMine) {
        board[idx].isMine = true;
        allocated++;
      }
    }

    for (const tile of board) {
      if (tile.isMine) continue;
      let count = 0;
      for (const other of board) {
        if (other.isMine) {
          const dr = Math.abs(other.r - tile.r);
          const dc = Math.abs(other.c - tile.c);
          if (dr <= 1 && dc <= 1) {
            count++;
          }
        }
      }
      tile.count = count;
    }

    setMinesBoard(board);
    setMinesStatus("playing");
  };

  useEffect(() => {
    resetMinesweeper();
  }, []);

  // 2. Music Player States
  const [currentTrackIdx, setCurrentTrackIdx] = useState(0);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const playList = [
    { title: "周一开会怎么编 (Lofi Remix)", duration: "1:45", author: "加班狂魔" },
    { title: "PPT的呼唤 (Phonk Bass Heavy)", duration: "2:10", author: "深夜打工人" },
    { title: "谁把鼠标拔了 (8-bit Synthesizer)", duration: "3:02", author: "网线切割师" },
    { title: "再看一分钟就干活 (Ambient Loop)", duration: "5:21", author: "拖延协会首席专家" },
  ];

  // Decryption workspace logic
  const [decryptInput, setDecryptInput] = useState("");
  const [decryptError, setDecryptError] = useState("");
  const [decryptProgress, setDecryptProgress] = useState<number | null>(null);

  // Folder modal contents
  const [folderView, setFolderView] = useState<"root" | "secret" | "photos">("root");

  // Retro popups database for higher procrastination levels
  const [popupCount, setPopupCount] = useState(0);
  const [floatingPopups, setFloatingPopups] = useState<Array<{ id: number; title: string; text: string; x: number; y: number }>>([]);

  // Window dragging states
  const [draggedWindow, setDraggedWindow] = useState<AppWindowType | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggedWindow) return;
    const newX = e.clientX - dragOffset.x;
    const newY = e.clientY - dragOffset.y;
    
    // Bounds boundaries constraint
    const clampedX = Math.max(-50, Math.min(window.innerWidth - 150, newX));
    const clampedY = Math.max(0, Math.min(window.innerHeight - 80, newY));

    setWindows((prev) => ({
      ...prev,
      [draggedWindow]: {
        ...prev[draggedWindow],
        x: clampedX,
        y: clampedY,
      },
    }));
  };

  const handleMouseUp = () => {
    setDraggedWindow(null);
  };

  const logStatsClick = () => {
    playAudioClick(600, "sine");
    setStats((prev) => {
      const clicks = prev.totalClicks + 1;
      let currentLevel = 0;
      if (clicks > 50) currentLevel = 4;
      else if (clicks > 32) currentLevel = 3;
      else if (clicks > 18) currentLevel = 2;
      else if (clicks > 6) currentLevel = 1;

      return {
        ...prev,
        totalClicks: clicks,
        level: currentLevel,
      };
    });

    if (stats.level >= 3 && Math.random() < 0.25) {
      triggerSelfMultiplyingMeme();
    }
  };

  // Right-click Context Menu logic
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    playAudioClick(480, "triangle");
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      visible: true
    });
  };

  // Normal click anywhere to dismiss context menus and active selected items
  const handleDesktopClick = () => {
    setSelectedIcon(null);
    if (contextMenu) setContextMenu(null);
  };

  // Context Menu operations
  const triggerRefresh = () => {
    playAudioClick(880, "sine");
    setContextMenu(null);
    // Mimic desktop refresh by flashing icons briefly
    const grid = document.getElementById("desktop-grid");
    if (grid) {
      grid.classList.add("opacity-30");
      setTimeout(() => grid.classList.remove("opacity-30"), 120);
    }
  };

  const triggerSelfMultiplyingMeme = () => {
    const titles = ["限时广告：拒绝工作！", "猫咪的呼唤！", "警告：您的PPT已经极其寂寞！", "一秒钟教你学会闭环", "摸鱼警报！"];
    const quotes = [
      "真的不看一下隔壁组的降本增效瓜吗？超大！",
      "吸一口旁边的猫治愈所有的周日抑郁！",
      "王主管正在悄无声息地向你身后接近...",
      "只要你一直拖延，老板就永远找不到你的缺点！",
      "报告长达零字节，不如再买一个便宜键盘吧！"
    ];

    const randomId = Date.now() + Math.floor(Math.random() * 100000000);
    const newPopup = {
      id: randomId,
      title: titles[Math.floor(Math.random() * titles.length)],
      text: quotes[Math.floor(Math.random() * quotes.length)],
      x: Math.random() * (window.innerWidth - 300) + 50,
      y: Math.random() * (window.innerHeight - 250) + 50,
    };

    setFloatingPopups((prev) => [...prev, newPopup]);
    setPopupCount((prev) => prev + 1);
  };

  const closeMemePopup = (id: number) => {
    logStatsClick();
    if (Math.random() < 0.35) {
      setFloatingPopups((prev) => prev.filter((p) => p.id !== id));
      triggerSelfMultiplyingMeme();
      triggerSelfMultiplyingMeme();
    } else {
      setFloatingPopups((prev) => prev.filter((p) => p.id !== id));
    }
  };

  const toggleWindow = (id: AppWindowType) => {
    logStatsClick();
    setWindows((prev) => {
      const win = prev[id];
      const nextZ = topZIndex + 1;
      setTopZIndex(nextZ);
      
      const isOpenNext = !win.isOpen;
      
      if (isOpenNext && ["tiktok", "tieba", "shopping", "minesweeper", "music", "tetris", "snake", "stocks"].includes(id)) {
        setStats(s => ({ ...s, distractionsCount: s.distractionsCount + 1 }));
      }

      return {
        ...prev,
        [id]: {
          ...win,
          isOpen: isOpenNext,
          isMinimized: false,
          zIndex: nextZ,
        },
      };
    });
    setStartMenuOpen(false);
  };

  const focusWindow = (id: AppWindowType) => {
    setWindows((prev) => {
      const nextZ = topZIndex + 1;
      setTopZIndex(nextZ);
      return {
        ...prev,
        [id]: {
          ...prev[id],
          zIndex: nextZ,
          isMinimized: false,
        },
      };
    });
  };

  const minimizeWindow = (id: AppWindowType, e: React.MouseEvent) => {
    e.stopPropagation();
    playAudioClick(350, "triangle");
    setWindows((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        isMinimized: true,
      },
    }));
  };

  const closeWindow = (id: AppWindowType, e: React.MouseEvent) => {
    e.stopPropagation();
    playAudioClick(300, "sawtooth");
    setWindows((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        isOpen: false,
      },
    }));
  };

  // Periodic simulated utilization rates
  useEffect(() => {
    const timer = setInterval(() => {
      setCpuUsage(Math.floor(Math.random() * 45) + 15 + (stats.level * 10));
      setRamUsage(Number((14.2 + Math.random() * 2 + (stats.level * 0.8)).toFixed(1)));
      setAttentionIndex(Math.max(10, 100 - (stats.level * 22)));
    }, 2000);
    return () => clearInterval(timer);
  }, [stats.level]);

  // Synchronize Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setSystemTime(
        now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  // Delayed boss chat trigger: Opens boss window after playing with other apps for a while
  useEffect(() => {
    const timer = setTimeout(() => {
      triggerBossChatPop();
    }, 45000);

    return () => clearTimeout(timer);
  }, []);

  // Click delay: if user interacts 15 times or more
  useEffect(() => {
    if (stats.totalClicks >= 15) {
      triggerBossChatPop();
    }
  }, [stats.totalClicks]);

  const triggerBossChatPop = () => {
    setWindows((prev) => {
      if (prev.boss.isOpen) return prev;
      const nextZ = topZIndex + 4;
      setTopZIndex(nextZ);
      return {
        ...prev,
        boss: {
          ...prev.boss,
          isOpen: true,
          isMinimized: false,
          zIndex: nextZ,
        }
      };
    });
  };

  const handleClueDiscovered = (clue: string) => {
    setClueCollected(clue);
    setShowClueAlert(true);
    setStats((prev) => ({ ...prev, searchesCount: prev.searchesCount + 1 }));
  };

  const handleDecryptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    logStatsClick();

    if (decryptInput.toUpperCase() === "XP0607") {
      setDecryptProgress(0);
      setDecryptError("");
      let p = 0;
      const interval = setInterval(() => {
        p += 20;
        if (p > 100) {
          clearInterval(interval);
          onFinishGame({
            ...stats,
            startTime: stats.startTime,
          });
        } else {
          setDecryptProgress(p);
        }
      }, 300);
    } else {
      setDecryptError("口令校验失败。您需要去【千度】中翻到没有人查看的第 2 页查找解密凭证！");
    }
  };

  const saveNotepadFile = () => {
    playAudioClick(800, "sine");
    setNotepadSaveMessage("文件已成功保存！");
    setTimeout(() => {
      setNotepadSaveMessage("");
    }, 3000);
  };

  // Predefined desktop icons mapping
  const desktopItems: DesktopItem[] = [
    { id: "my-computer", label: "我的电脑", icon: "Monitor", type: "my-computer", isDistraction: false, isOpen: false },
    { id: "recycle-bin", label: "回收站", icon: "Trash2", type: "recycle-bin", isDistraction: false, isOpen: false },
    { id: "work-app", label: user.jobType === "code" ? "核心IDE编辑器" : "Q2汇报PPT大纲", icon: "FileText", type: "work-app", isDistraction: false, isOpen: false },
    { id: "qiandu", label: "千度AI搜索引擎", icon: "Globe", type: "qiandu", isDistraction: false, isOpen: false },
    { id: "boss", label: "企业微信Slack", icon: "MessageSquare", type: "boss", isDistraction: false, isOpen: false },
    { id: "tiktok", label: "抖音滑滑", icon: "Play", type: "tiktok", isDistraction: true, isOpen: false },
    { id: "tieba", label: "贴吧热点爆料", icon: "Flame", type: "tieba", isDistraction: true, isOpen: false },
    { id: "shopping", label: "特惠限时秒杀", icon: "ShoppingCart", type: "shopping", isDistraction: true, isOpen: false },
    { id: "camera", label: "面部安全监视器", icon: "Camera", type: "camera", isDistraction: false, isOpen: false },
    { id: "minesweeper", label: "像素经典扫雷", icon: "Bomb", type: "minesweeper", isDistraction: true, isOpen: false },
    { id: "music", label: "点点像素八音盒", icon: "Music", type: "music", isDistraction: true, isOpen: false },
    { id: "diary", label: "摸鱼猝死日记.txt", icon: "FileText", type: "diary", isDistraction: true, isOpen: false },
    { id: "tetris", label: "经典俄罗斯方块", icon: "Grid", type: "tetris", isDistraction: true, isOpen: false },
    { id: "snake", label: "像素模拟贪吃蛇", icon: "Tv", type: "snake", isDistraction: true, isOpen: false },
    { id: "stocks", label: "同花顺股票行情", icon: "TrendingUp", type: "stocks", isDistraction: true, isOpen: false },
    { id: "calculator", label: "科学计算器", icon: "Calculator", type: "calculator", isDistraction: false, isOpen: false },
    { id: "settings", label: "控制面板设置", icon: "Settings", type: "settings", isDistraction: false, isOpen: false },
  ];

  // Wallpaper asset mappings
  const wallpapers = {
    bliss: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Bliss_%28Windows_XP%29.png/1280px-Bliss_%28Windows_XP%29.png",
    modern: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1600&h=1000",
    macos: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&h=1000",
    cyberpunk: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1600&h=1000",
    classic: ""
  };

  // Active theme properties
  const themeHeaderStyles = {
    xp: "bg-gradient-to-r from-[#173fa7] to-[#3068de] text-white border-b border-[#2d5be3]",
    dark: "bg-gradient-to-r from-[#1a1b20] to-[#2e303c] text-[#e2e8f0] border-b border-[#111216]",
    rose: "bg-gradient-to-r from-[#fda4af] to-[#f472b6] text-white border-b border-[#f43f5e]"
  };

  const themeBorderStyles = {
    xp: "border-[#1c44be]",
    dark: "border-[#2c2d30]",
    rose: "border-[#fda4af]"
  };

  return (
    <div 
      id="desktop-env" 
      className={`relative w-full h-screen overflow-hidden select-none font-sans flex flex-col ${
        crtFilter ? "crt-scanlines" : ""
      }`} 
      onContextMenu={handleContextMenu}
      onClick={handleDesktopClick}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      
      {/* 1. Dynamic Wallpaper Backdrop */}
      <div 
        id="desktop-wallpaper" 
        className={`absolute inset-0 bg-cover bg-center transition-all duration-700 z-0 ${
          wallpaper === "classic" ? "bg-[#2f8385]" : "bg-[#5a7edc]"
        }`}
        style={{
          backgroundImage: wallpaper === "classic" ? "none" : `url('${wallpapers[wallpaper]}')`
        }}
      >
        {/* Level overlays for mental decay */}
        {stats.level >= 1 && (
          <div className="absolute top-1/4 right-[28%] bg-[#fef08a]/90 backdrop-blur-sm border border-yellow-400 p-2 text-[10px] text-yellow-900 rounded-lg select-none shadow-lg rotate-2 max-w-xs transition font-bold leading-normal">
            🎬 提示：猫片实在是太可爱了，我就看最后一分钟。
          </div>
        )}

        {stats.level >= 2 && (
          <div className="absolute bottom-1/3 left-1/4 text-center bg-white/95 backdrop-blur-sm border-2 border-dashed border-red-500 text-red-700 px-4 py-3 rounded-xl rotate-12 max-w-xs font-extrabold shadow-xl select-none animate-pulse text-[11px]">
            🐱 MEOW! <br/>
            “双击那些红色的分心APP，你的压力将被瞬间释放...”
          </div>
        )}

        {stats.level >= 3 && (
          <div className="absolute top-12 left-[40%] bg-red-600 text-white font-black text-[10px] p-2.5 rounded-lg flex items-center gap-2 border border-white animate-bounce shadow-2xl z-20">
            <ShieldAlert size={14} className="animate-spin text-yellow-300" />
            <span>【红色预警】：王经理的聊天头像正在剧烈抖动，请速速交差！</span>
          </div>
        )}

        {stats.level >= 4 && (
          <div className="absolute inset-0 bg-red-950/25 flex flex-col items-center justify-center font-mono pointer-events-none text-red-600/10 text-[100px] uppercase select-none tracking-widest font-black leading-snug">
            <div>WASTED</div>
            <div>PROCRASTINATED</div>
          </div>
        )}
      </div>

      {/* 2. Floating right-click Context Menu */}
      {contextMenu && contextMenu.visible && (
        <div 
          id="context-menu-floating"
          style={{ top: `${contextMenu.y}px`, left: `${contextMenu.x}px` }}
          className="absolute w-44 bg-[#efebde] border-2 border-white shadow-2xl z-50 p-1 text-[11px] text-black font-sans leading-tight"
          onClick={(e) => e.stopPropagation()}
        >
          <button onClick={triggerRefresh} className="w-full text-left py-1.5 px-3 hover:bg-[#3156cf] hover:text-white rounded flex items-center gap-2 cursor-pointer">
            <RefreshCw size={11} />
            <span>刷新桌面 (R)</span>
          </button>
          <div className="h-px bg-neutral-300 my-1 w-[90%] mx-auto" />
          
          <div className="relative group/sub">
            <div className="w-full text-left py-1.5 px-3 hover:bg-[#3156cf] hover:text-white rounded flex items-center justify-between cursor-pointer">
              <span>更换壁纸 (W)</span>
              <ChevronRight size={10} />
            </div>
            {/* Wallpaper Submenu */}
            <div className="absolute left-[172px] top-0 w-36 bg-[#efebde] border-2 border-white shadow-xl p-1 hidden group-hover/sub:block space-y-0.5">
              <button onClick={() => { setWallpaper("bliss"); setContextMenu(null); }} className="w-full text-left py-1 px-2 hover:bg-[#3156cf] hover:text-white rounded">Bliss 经典山丘</button>
              <button onClick={() => { setWallpaper("modern"); setContextMenu(null); }} className="w-full text-left py-1 px-2 hover:bg-[#3156cf] hover:text-white rounded">Win11 蓝花瓣</button>
              <button onClick={() => { setWallpaper("macos"); setContextMenu(null); }} className="w-full text-left py-1 px-2 hover:bg-[#3156cf] hover:text-white rounded">macOS 蔚蓝海滩</button>
              <button onClick={() => { setWallpaper("cyberpunk"); setContextMenu(null); }} className="w-full text-left py-1 px-2 hover:bg-[#3156cf] hover:text-white rounded">赛博数码桌面</button>
              <button onClick={() => { setWallpaper("classic"); setContextMenu(null); }} className="w-full text-left py-1 px-2 hover:bg-[#3156cf] hover:text-white rounded">Classic 经典绿</button>
            </div>
          </div>

          <button onClick={() => { setCrtFilter(!crtFilter); setContextMenu(null); }} className="w-full text-left py-1.5 px-3 hover:bg-[#3156cf] hover:text-white rounded flex items-center gap-2 cursor-pointer">
            <Eye size={11} />
            <span>{crtFilter ? "关闭 CRT 滤镜" : "开启 CRT 滤镜"}</span>
          </button>
          <div className="h-px bg-neutral-300 my-1 w-[90%] mx-auto" />
          
          <button onClick={() => { toggleWindow("calculator"); setContextMenu(null); }} className="w-full text-left py-1.5 px-3 hover:bg-[#3156cf] hover:text-white rounded flex items-center gap-2 cursor-pointer">
            <CalcIcon size={11} />
            <span>打开计算器 (C)</span>
          </button>
          <button onClick={() => { toggleWindow("settings"); setContextMenu(null); }} className="w-full text-left py-1.5 px-3 hover:bg-[#3156cf] hover:text-white rounded flex items-center gap-2 cursor-pointer">
            <Settings size={11} />
            <span>系统控制面板 (S)</span>
          </button>
        </div>
      )}

      {/* 3. Clue Alert Banner */}
      {showClueAlert && (
        <div id="clue-banner" className="absolute top-6 left-1/2 -translate-x-1/2 bg-yellow-400 border-2 border-amber-500 shadow-2xl p-4 rounded-xl max-w-md w-full z-50 animate-bounce text-yellow-950 select-text">
          <div className="flex items-start gap-2.5">
            <Sparkles size={20} className="text-yellow-800 shrink-0 mt-0.5 animate-spin" />
            <div>
              <p className="font-extrabold text-xs uppercase tracking-wide">找到解密文件序列号！</p>
              <p className="text-xs font-semibold leading-relaxed mt-1">
                {clueCollected || "在千度第二页发现重要口令! 口令在脑海中逐渐形成..."}
              </p>
              <button
                onClick={(e) => { e.stopPropagation(); setShowClueAlert(false); }}
                className="mt-3.5 bg-yellow-900 hover:bg-yellow-950 text-white font-bold text-[10px] px-4 py-1.5 rounded uppercase cursor-pointer block select-none"
              >
                我已记下，立即去解密文件夹
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. Desktop grid icons area */}
      <div 
        id="desktop-grid" 
        className="absolute top-4 left-4 p-1 w-[220px] max-h-[calc(100vh-80px)] flex gap-3 z-10 select-none overflow-hidden transition-all duration-150"
      >
        {/* Column 1: Core Apps */}
        <div className="flex flex-col gap-2.5 w-[100px] overflow-y-auto scrollbar-none pb-2 select-none">
          {["my-computer", "qiandu", "tieba", "tiktok", "shopping", "music", "tetris", "calculator"].map(id => {
            const item = desktopItems.find(i => i.id === id);
            if (!item) return null;
            return (
              <button
                key={item.id}
                id={`desktop-icon-${item.id}`}
                onDoubleClick={(e) => { e.stopPropagation(); toggleWindow(item.type); }}
                onClick={(e) => { e.stopPropagation(); setSelectedIcon(item.id); }}
                className={`w-[100px] h-[82px] shrink-0 flex flex-col items-center justify-center text-center p-1 border-2 transition-all duration-100 group relative font-mono text-white ${
                  selectedIcon === item.id 
                    ? "bg-blue-600/35 border-blue-400/60 rounded shadow-md" 
                    : "border-transparent hover:bg-black/15 hover:border-black/20"
                } ${item.isDistraction ? "animate-pulse" : ""}`}
              >
                <div className="text-3.5xl filter drop-shadow-[0_2.5px_2px_rgba(0,0,0,0.85)] group-hover:scale-105 transition duration-75">
                  {item.id === "my-computer" && <span className="text-4xl">🖥️</span>}
                  {item.id === "qiandu" && <span className="text-4xl">🔍</span>}
                  {item.id === "tieba" && <span className="text-4xl">🌶️</span>}
                  {item.id === "tiktok" && <span className="text-4xl">🎬</span>}
                  {item.id === "shopping" && <span className="text-4xl">🛍️</span>}
                  {item.id === "music" && <span className="text-4xl">🎵</span>}
                  {item.id === "tetris" && <span className="text-4xl">🧱</span>}
                  {item.id === "calculator" && <span className="text-4xl">📟</span>}
                </div>
                <span className="text-white text-[10px] font-bold drop-shadow-[0_1.5px_1.5px_rgba(0,0,0,0.9)] mt-1 block leading-normal w-full truncate px-0.5">
                  {item.label}
                </span>

                {item.isDistraction && (
                  <span className="absolute top-0.5 right-1 bg-red-600 border border-black text-white text-[8px] font-black px-1 scale-90">
                    HOT
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Column 2: Secondary & distraction Apps */}
        <div className="flex flex-col gap-2.5 w-[100px] overflow-y-auto scrollbar-none pb-2 select-none">
          {["recycle-bin", "boss", "work-app", "camera", "minesweeper", "diary", "stocks", "settings"].map(id => {
            const item = desktopItems.find(i => i.id === id);
            if (!item) return null;
            return (
              <button
                key={item.id}
                id={`desktop-icon-${item.id}`}
                onDoubleClick={(e) => { e.stopPropagation(); toggleWindow(item.type); }}
                onClick={(e) => { e.stopPropagation(); setSelectedIcon(item.id); }}
                className={`w-[100px] h-[82px] shrink-0 flex flex-col items-center justify-center text-center p-1 border-2 transition-all duration-100 group relative font-mono text-white ${
                  selectedIcon === item.id 
                    ? "bg-blue-600/35 border-blue-400/60 rounded shadow-md" 
                    : "border-transparent hover:bg-black/15 hover:border-black/20"
                } ${item.isDistraction ? "animate-pulse" : ""}`}
              >
                <div className="text-3.5xl filter drop-shadow-[0_2.5px_2px_rgba(0,0,0,0.85)] group-hover:scale-105 transition duration-75">
                  {item.id === "recycle-bin" && <span className="text-4xl">🗑️</span>}
                  {item.id === "boss" && <span className="text-4xl">💬</span>}
                  {item.id === "work-app" && <span className="text-4xl animate-bounce">📁</span>}
                  {item.id === "camera" && <span className="text-4xl">📹</span>}
                  {item.id === "minesweeper" && <span className="text-4xl">🎮</span>}
                  {item.id === "diary" && <span className="text-4xl">📝</span>}
                  {item.id === "stocks" && <span className="text-4xl">📈</span>}
                  {item.id === "settings" && <span className="text-4xl">⚙️</span>}
                </div>
                <span className="text-white text-[10px] font-bold drop-shadow-[0_1.5px_1.5px_rgba(0,0,0,0.9)] mt-1 block leading-normal w-full truncate px-0.5">
                  {item.label}
                </span>

                {item.isDistraction && (
                  <span className="absolute top-0.5 right-1 bg-red-600 border border-black text-white text-[8px] font-black px-1 scale-90">
                    HOT
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 5. Floating self-multiplying meme popups */}
      {floatingPopups.map((popup) => (
        <div
          key={popup.id}
          style={{ left: `${popup.x}px`, top: `${popup.y}px`, zIndex: topZIndex + 5 }}
          className="absolute w-72 bg-gradient-to-r from-yellow-300 to-amber-400 border-4 border-amber-600 rounded shadow-2xl overflow-hidden text-amber-950 select-none cursor-pointer"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="bg-[#18399c] text-white px-2 py-1.5 flex items-center justify-between text-xs font-bold font-mono">
            <span>{popup.title}</span>
            <button onClick={() => closeMemePopup(popup.id)} className="text-white hover:text-red-400">
              <X size={14} />
            </button>
          </div>
          <div className="p-3 text-xs leading-relaxed font-bold">
            <p>{popup.text}</p>
            <div className="flex justify-end gap-1.5 mt-3 text-[10px]">
              <button
                onClick={() => closeMemePopup(popup.id)}
                className="bg-amber-600 hover:bg-amber-700 text-white font-bold p-1 px-3 border border-amber-800 rounded uppercase"
              >
                点赞逃避
              </button>
            </div>
          </div>
        </div>
      ))}

      {/* 6. Render Active Desktop Windows */}
      {(Object.values(windows) as WindowInstance[]).map((win) => {
        if (!win.isOpen || win.isMinimized) return null;

        const isActive = win.zIndex === topZIndex;

        return (
          <div
            key={win.id}
            id={`window-frame-${win.id}`}
            style={{
              left: win.isMaximized ? "0px" : `${win.x}px`,
              top: win.isMaximized ? "0px" : `${win.y}px`,
              width: win.isMaximized ? "100%" : `${win.w}px`,
              height: win.isMaximized ? "100%" : `${win.h}px`,
              zIndex: win.zIndex,
            }}
            onClick={(e) => { e.stopPropagation(); focusWindow(win.id); }}
            className={`absolute bg-[#efebde] border-4 border-black pixel-box-shadow flex flex-col justify-between overflow-hidden transition-all duration-75 ${
              win.isMaximized ? "inset-0 w-full h-full !top-0 !left-0 rounded-none border-none" : ""
            } ${isActive ? "shadow-2xl brightness-100" : "shadow-md brightness-[0.93]"} ${themeBorderStyles[theme]}`}
          >
            {/* Window bar header */}
            <div 
              id={`window-header-${win.id}`}
              onDoubleClick={(e) => {
                e.stopPropagation();
                setWindows(prev => ({
                  ...prev,
                  [win.id]: {
                    ...win,
                    isMaximized: !win.isMaximized
                  }
                }));
              }}
              onMouseDown={(e) => {
                if (win.isMaximized) return;
                const target = e.target as HTMLElement;
                if (target.closest("button")) return;

                setDraggedWindow(win.id);
                setDragOffset({
                  x: e.clientX - win.x,
                  y: e.clientY - win.y,
                });
                focusWindow(win.id);
              }}
              className={`px-3 py-1.5 flex items-center justify-between select-none shrink-0 font-mono tracking-wider text-[10px] uppercase cursor-move transition-all ${
                isActive 
                  ? themeHeaderStyles[theme]
                  : "bg-neutral-400 text-neutral-200 border-b border-neutral-500"
              }`}
            >
              <div className="flex items-center gap-1.5 font-black">
                <span className="truncate max-w-[400px]">👾 {win.label}</span>
              </div>
              
              <div className="flex items-center gap-1.5">
                <button
                  onClick={(e) => minimizeWindow(win.id, e)}
                  className="p-0.5 bg-[#21439c] hover:bg-blue-600 border border-blue-400 rounded shadow active:scale-95 cursor-pointer"
                >
                  <Minus size={11} className="text-white" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); setWindows(prev => ({ ...prev, [win.id]: { ...win, isMaximized: !win.isMaximized } })); }}
                  className="p-0.5 bg-[#21439c] hover:bg-blue-600 border border-blue-400 rounded shadow active:scale-95 cursor-pointer"
                >
                  <Square size={9} className="text-white" />
                </button>
                <button
                  id={`btn-window-close-${win.id}`}
                  onClick={(e) => closeWindow(win.id, e)}
                  className="p-0.5 bg-gradient-to-b from-red-500 to-rose-700 hover:from-red-600 hover:to-rose-800 border border-red-400 rounded shadow active:scale-95 cursor-pointer"
                >
                  <X size={11} className="text-white" />
                </button>
              </div>
            </div>

            {/* Window Interior Content */}
            <div className="flex-grow w-full overflow-hidden relative bg-white">
              
              {win.id === "qiandu" && (
                <QianduBrowser
                  user={user}
                  onLoggedClick={logStatsClick}
                  onClueDiscovered={handleClueDiscovered}
                />
              )}

              {win.id === "boss" && (
                <BossChat
                  user={user}
                  procrastinationLevel={stats.level}
                  onLoggedClick={logStatsClick}
                  onUrgeLogged={() => setStats(s => ({ ...s, bossUrges: s.bossUrges + 1 }))}
                />
              )}

              {win.id === "camera" && (
                <WebcamParody
                  onLoggedClick={logStatsClick}
                  userName={user.name}
                />
              )}

              {["tiktok", "tieba", "shopping"].includes(win.id) && (
                <DistractionWindows
                  user={user}
                  appType={win.id}
                  onLoggedClick={logStatsClick}
                />
              )}

              {win.id === "calculator" && (
                <Calculator onLoggedClick={logStatsClick} />
              )}
              
              {/* Specialized Work App / Breakout point */}
              {win.id === "work-app" && (
                <div className="p-6 h-full flex flex-col justify-between overflow-y-auto bg-slate-100 text-gray-800">
                  <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
                    <h2 className="font-extrabold text-sm text-[#18399c] flex items-center gap-1.5 border-b border-gray-100 pb-2 mb-2">
                      <FileText size={16} />
                      <span>沙盒安全恢复中心 - 工作文件已解绑</span>
                    </h2>
                    <p className="text-xs text-gray-500 leading-relaxed mb-4">
                      由于此电脑先前由于极高摸鱼动作（网络安全系统判定）而被锁定沙盒保护，
                      <strong>所有未保存的工作文件数据当前已被锁定。</strong> <br/>
                      您必须要输入来自“千度”高层恢复网络的系统安全校验序列密钥（位于<strong>千度搜索引擎第 2 页</strong>）方能恢复解除。
                    </p>

                    <form onSubmit={handleDecryptSubmit} className="flex gap-2 max-w-sm">
                      <input
                        id="form-input-decrypt"
                        type="text"
                        required
                        placeholder="请输入六位解密凭证密钥..."
                        value={decryptInput}
                        onChange={(e) => setDecryptInput(e.target.value)}
                        className="flex-grow px-3 py-1.5 border border-gray-300 rounded focus:border-[#18399c] focus:outline-none placeholder-gray-400 font-mono text-xs text-center uppercase font-bold"
                      />
                      <button
                        id="btn-decrypt-submit"
                        type="submit"
                        className="bg-[#18399c] text-white font-bold text-xs px-4 py-1.5 rounded hover:bg-blue-800 transition uppercase cursor-pointer select-none shrink-0"
                      >
                        安全校验
                      </button>
                    </form>

                    {decryptError && (
                      <p className="text-[10px] text-red-600 mt-2 font-medium bg-red-50 p-2 rounded border border-red-200">
                        {decryptError}
                      </p>
                    )}

                    {decryptProgress !== null && (
                      <div className="mt-4 bg-[#e5e7eb] h-3 rounded overflow-hidden border border-gray-300 relative">
                        <div
                          className="bg-emerald-500 h-full transition-all duration-300 animate-pulse"
                          style={{ width: `${decryptProgress}%` }}
                        ></div>
                        <span className="absolute inset-0 text-[9px] text-[#ffd166] text-center uppercase tracking-widest font-black flex items-center justify-center mix-blend-difference">
                          正在反编译还原核心办公模块 ({decryptProgress}%)...
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-lg text-[10px] text-gray-500 leading-normal">
                    <span className="font-bold block text-yellow-800 mb-1">💡 突围逻辑速通提示：</span>
                    您现在处于桌面的“失控反噬期”，请速双击打开【千度AI搜索引擎】，搜索任意您想搜的偷懒词条。
                    然后在搜索结果页面下方，<strong>点击翻到『 2 』页（通常没人看的那页）</strong>便可获取到该六位校验序列！
                  </div>
                </div>
              )}

              {/* Folders My Computer simulation */}
              {win.id === "my-computer" && (
                <div className="p-4 h-full bg-[#efebde] overflow-y-auto flex flex-col gap-4 text-xs font-sans text-neutral-800">
                  {folderView === "root" ? (
                    <div className="grid grid-cols-3 gap-4 select-none">
                      <button
                        onClick={() => setFolderView("secret")}
                        className="flex flex-col items-center p-2 rounded hover:bg-blue-100 border border-transparent hover:border-blue-200 select-none text-center"
                      >
                        <Folder size={32} className="text-yellow-400" />
                        <span className="font-bold text-[10px] text-gray-700 mt-1">
                          加密工作备份区
                        </span>
                      </button>
                      <button
                        onClick={() => setFolderView("photos")}
                        className="flex flex-col items-center p-2 rounded hover:bg-blue-100 border border-transparent hover:border-blue-200 select-none text-center"
                      >
                        <Folder size={32} className="text-yellow-400" />
                        <span className="font-bold text-[10px] text-gray-700 mt-1">
                          秘密小猫合集
                        </span>
                      </button>
                      <div className="flex flex-col items-center p-2 opacity-50 select-none text-center">
                        <Folder size={32} className="text-gray-400 animate-pulse" />
                        <span className="font-bold text-[10px] text-gray-500 mt-1">
                          系统故障 C 盘
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-center justify-between border-b border-gray-300 pb-1.5 mb-2.5">
                        <span className="font-bold text-gray-500 font-mono text-[10px] uppercase">
                          目录：{folderView === "secret" ? "工作备份" : "秘密小猫"}
                        </span>
                        <button onClick={() => setFolderView("root")} className="text-blue-600 font-bold hover:underline">
                          返回根目录
                        </button>
                      </div>

                      {folderView === "secret" ? (
                        <p className="text-gray-500 bg-white p-3 rounded border border-gray-300 italic text-[11px] leading-relaxed">
                          云盘里空空如也。您的PPT甚至一行也没写下，真正的进度还在等您去主桌面打开【核心IDE编辑器/汇报PPT】。
                        </p>
                      ) : (
                        <div className="flex flex-col items-center justify-center p-4 text-center">
                          <span className="text-4xl mb-1 animate-bounce">🐈 🐾</span>
                          <span className="font-black text-xs text-gray-600">小猫也说：“别偷懒了，快写！”</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Trash bin folder simulation */}
              {win.id === "recycle-bin" && (
                <div className="p-4 h-full bg-[#efebde] overflow-y-auto flex flex-col justify-between text-xs text-gray-600 font-sans">
                  <div className="space-y-2">
                    <p className="font-bold text-gray-400 font-mono text-[10px] uppercase">回收站文件列表：</p>
                    <div className="flex items-center gap-2 p-2 bg-white rounded border border-gray-300 shadow-sm">
                      <FileText size={16} className="text-gray-400" />
                      <div>
                        <span className="font-bold block text-[10px] text-gray-700">放弃的项目策划书_v1_abandoned.key</span>
                        <span className="text-[9px] text-gray-400">已于两周前丢弃 (2.4 MB)</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-white rounded border border-gray-300 shadow-sm">
                      <FileText size={16} className="text-gray-400" />
                      <div>
                        <span className="font-bold block text-[10px] text-gray-700">今日工作提纲_v2_not_feasible.docx</span>
                        <span className="text-[9px] text-gray-400">已于天亮丢弃 (412 KB)</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 p-2.5 rounded text-[10px] leading-relaxed text-yellow-800">
                    <span className="font-bold block">回收判定说教：</span>
                    您之前无数次半途而废的草案都在这里。每一次对文档的放弃投降，都在壮大‘拖延症’的堡垒。
                    我们这次不放水，通过千度拿到密钥解密主文件吧。
                  </div>
                </div>
              )}

              {/* Retro Minesweeper simulation */}
              {win.id === "minesweeper" && (
                <div className="p-3 h-full bg-[#c0c0c0] flex flex-col justify-between text-xs font-mono select-none text-black">
                  <div className="bg-neutral-800 text-green-400 p-1.5 font-mono text-[9px] uppercase text-center border border-black mb-1.5 animate-pulse">
                    🎮 摸鱼专区: 扫雷安全屋 🎮
                  </div>

                  <div className="flex justify-between items-center bg-[#808080] p-1.5 border border-white text-white font-bold text-[10px] mb-2">
                    <div>💣 炸弹数: 6</div>
                    <button 
                      onClick={() => { logStatsClick(); resetMinesweeper(); }}
                      className="bg-[#c0c0c0] text-black px-2 py-0.5 border-2 border-black hover:bg-neutral-300 active:translate-y-0.5 text-[9px] font-bold cursor-pointer"
                    >
                      {minesStatus === "lost" ? "😵 重来" : minesStatus === "won" ? "😎 胜利" : "🙂 重开"}
                    </button>
                    <div>⏰ 拖延中</div>
                  </div>

                  {/* 6x6 Grid */}
                  <div className="grid grid-cols-6 gap-1 w-fit mx-auto bg-neutral-600 p-1 border-2 border-black">
                    {minesBoard.map((tile) => {
                      let btnBg = "bg-[#c0c0c0] hover:bg-neutral-300";
                      let btnContent = "";
                      if (tile.isRevealed) {
                        btnBg = "bg-neutral-300";
                        if (tile.isMine) {
                          btnContent = "💣";
                          btnBg = "bg-red-500 animate-bounce";
                        } else if (tile.count > 0) {
                          btnContent = String(tile.count);
                        }
                      } else if (tile.isFlagged) {
                        btnContent = "🚩";
                        btnBg = "bg-amber-100";
                      }

                      return (
                        <button
                          key={tile.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            logStatsClick();
                            if (minesStatus !== "playing") return;
                            if (tile.isRevealed || tile.isFlagged) return;

                            setMinesBoard(prev => prev.map(t => t.id === tile.id ? { ...t, isRevealed: true } : t));

                            if (tile.isMine) {
                              setMinesStatus("lost");
                            } else {
                              const willBeRevealed = minesBoard.map(t => t.id === tile.id ? { ...t, isRevealed: true } : t);
                              const unrevealedSafe = willBeRevealed.filter(t => !t.isMine && !t.isRevealed);
                              if (unrevealedSafe.length === 0) {
                                setMinesStatus("won");
                              }
                            }
                          }}
                          onContextMenu={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            logStatsClick();
                            if (minesStatus !== "playing") return;
                            if (tile.isRevealed) return;

                            setMinesBoard(prev => prev.map(t => t.id === tile.id ? { ...t, isFlagged: !t.isFlagged } : t));
                          }}
                          className={`${btnBg} w-9 h-9 border border-neutral-400 font-bold text-center flex items-center justify-center text-[10px] active:shadow-inner cursor-pointer`}
                        >
                          <span className={tile.count === 1 ? "text-blue-750 font-bold" : tile.count === 2 ? "text-green-750 font-bold" : "text-red-750 font-black"}>
                            {btnContent}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-2 text-[8px] text-[#404040] leading-tight text-center">
                    {minesStatus === "lost" && (
                      <span className="text-red-700 font-bold block bg-red-50 p-1 border border-red-200">
                        💥 踩雷了！您被抓去开周会说辞了5分钟。
                      </span>
                    )}
                    {minesStatus === "won" && (
                      <span className="text-green-700 font-bold block bg-green-50 p-1 border border-green-200">
                        🎉 通关成功！但你明明是要去干活的啊...
                      </span>
                    )}
                    {minesStatus === "playing" && (
                      <span>鼠标左键翻开，右键插旗标雷。</span>
                    )}
                  </div>
                </div>
              )}

              {/* Music Player Simulation */}
              {win.id === "music" && (
                <div className="p-3 h-full bg-[#14151f] text-white flex flex-col justify-between font-mono select-none">
                  <div className="bg-[#1f202e] border border-neutral-700 p-2.5 rounded-lg flex items-center justify-between gap-3 mt-1.5">
                    <div 
                      className={`w-12 h-12 rounded-full border-2 border-dashed border-cyan-400 flex items-center justify-center bg-black ${isMusicPlaying ? "animate-spin" : ""}`}
                      style={{ animationDuration: "5s" }}
                    >
                      <span className="text-xl">💿</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-[7px] uppercase tracking-widest text-[#ffd166] font-bold block">♪ 正在摸鱼播放 ♪</span>
                      <p className="font-bold text-[10px] truncate text-white mt-0.5">{playList[currentTrackIdx].title}</p>
                      <p className="text-[8px] text-gray-400 truncate">{playList[currentTrackIdx].author}</p>
                    </div>
                  </div>

                  <div className="h-8 flex items-end justify-center gap-1 my-1 px-2.5">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((bar) => {
                      const h = isMusicPlaying ? Math.floor(Math.random() * 20) + 4 : 2;
                      return (
                        <div 
                          key={bar} 
                          className="w-1 bg-[#ffd166] transition-all duration-300"
                          style={{ height: `${h}px` }}
                        ></div>
                      );
                    })}
                  </div>

                  <div className="flex justify-center items-center gap-4 bg-[#1f202e] py-1 px-3 border border-neutral-700 rounded-md">
                    <button 
                      onClick={() => { logStatsClick(); setCurrentTrackIdx(p => (p - 1 + playList.length) % playList.length); }}
                      className="hover:text-cyan-400 text-sm cursor-pointer active:scale-95"
                    >
                      ⏮️
                    </button>
                    <button 
                      onClick={() => { logStatsClick(); setIsMusicPlaying(!isMusicPlaying); }}
                      className="bg-[#ffd166] text-black w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold hover:bg-yellow-400 cursor-pointer active:scale-90"
                    >
                      {isMusicPlaying ? "⏸️" : "▶️"}
                    </button>
                    <button 
                      onClick={() => { logStatsClick(); setCurrentTrackIdx(p => (p + 1) % playList.length); }}
                      className="hover:text-cyan-400 text-sm cursor-pointer active:scale-95"
                    >
                      ⏭️
                    </button>
                  </div>

                  <p className="text-[8px] text-gray-400 text-center leading-normal">
                    听着心怡的小曲，工作的事情全抛脑后。但真正的文件似乎还在您的桌面上等待解密密钥。
                  </p>
                </div>
              )}

              {/* Notepad Diary.txt - EDITABLE & SAVABLE */}
              {win.id === "diary" && (
                <div className="h-full bg-white flex flex-col justify-between text-xs font-mono select-none text-black">
                  <div className="bg-[#f0f0f0] border-b border-gray-300 px-2 py-0.5 flex gap-2 text-[9px] text-gray-700 items-center justify-between">
                    <div className="flex gap-2">
                      <button onClick={saveNotepadFile} className="hover:bg-blue-100 px-1 py-0.5 cursor-pointer font-bold text-blue-800">保存文件 (S)</button>
                      <span className="hover:bg-blue-100 px-1 py-0.5 cursor-pointer">编辑(E)</span>
                      <span className="hover:bg-blue-100 px-1 py-0.5 cursor-pointer">格式(O)</span>
                      <span className="hover:bg-[#ffdfdf] text-red-600 px-1.5 py-0.5 rounded ml-2 select-none text-[8px] border border-red-200">
                        * 现在该文档已支持真实编辑！
                      </span>
                    </div>
                    {notepadSaveMessage && (
                      <span className="text-[8px] text-emerald-600 font-bold bg-emerald-50 px-1 rounded animate-pulse">{notepadSaveMessage}</span>
                    )}
                  </div>

                  <textarea 
                    onClick={logStatsClick}
                    onChange={(e) => setDiaryContent(e.target.value)}
                    className="flex-grow w-full p-2.5 font-mono text-[10px] focus:outline-none resize-none overflow-y-auto leading-relaxed bg-[#fcfcf9] text-amber-950"
                    value={diaryContent}
                  />

                  <div className="bg-[#f0f0f0] border-t border-gray-300 px-2 py-0.5 flex justify-between text-[8px] text-gray-500">
                    <span>文档行数: {diaryContent.split("\n").length} 行</span>
                    <span>UTF-8文字格式</span>
                  </div>
                </div>
              )}

              {/* Tetris slacker Game */}
              {win.id === "tetris" && (
                <div className="h-full bg-slate-900 overflow-hidden flex flex-col justify-between text-xs font-mono select-none">
                  <TetrisGame onLoggedClick={logStatsClick} />
                </div>
              )}

              {/* Snake slacker Game */}
              {win.id === "snake" && (
                <div className="h-full bg-[#1e272e] overflow-hidden flex flex-col justify-between text-xs font-mono select-none">
                  <SnakeGame onLoggedClick={logStatsClick} />
                </div>
              )}

              {/* Stocks App */}
              {win.id === "stocks" && (
                <div className="h-full bg-[#050505] overflow-hidden flex flex-col justify-between text-xs font-sans select-none">
                  <StocksApp onLoggedClick={logStatsClick} />
                </div>
              )}

              {/* System Control Panel Settings UI */}
              {win.id === "settings" && (
                <div className="p-3.5 h-full bg-[#efebde] overflow-y-auto text-xs font-sans text-neutral-800 flex flex-col justify-between">
                  <div className="space-y-3.5">
                    
                    {/* Preferences title */}
                    <div className="flex items-center gap-2 border-b border-neutral-300 pb-1.5">
                      <Sliders className="text-blue-800 w-4 h-4" />
                      <h4 className="font-extrabold text-blue-900 text-[11px]">系统桌面个性化设置中心</h4>
                    </div>

                    {/* Presets grids */}
                    <div className="grid grid-cols-2 gap-3.5">
                      {/* Wallpaper preferences block */}
                      <div className="bg-[#fbf9f4] p-2.5 rounded border border-neutral-300 shadow-sm flex flex-col gap-2">
                        <span className="font-black text-[9px] text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                          <Layout size={12} />
                          <span>选择桌面壁纸:</span>
                        </span>
                        
                        <div className="flex flex-col gap-1 text-[10px] font-bold">
                          <button 
                            onClick={() => { logStatsClick(); setWallpaper("bliss"); }} 
                            className={`w-full text-left py-1 px-2 rounded flex justify-between items-center ${wallpaper === "bliss" ? "bg-blue-100 text-blue-900" : "hover:bg-neutral-200"}`}
                          >
                            <span>🏞️ Bliss (默认XP山丘)</span>
                            {wallpaper === "bliss" && <Check size={11} className="text-blue-700" />}
                          </button>
                          <button 
                            onClick={() => { logStatsClick(); setWallpaper("modern"); }} 
                            className={`w-full text-left py-1 px-2 rounded flex justify-between items-center ${wallpaper === "modern" ? "bg-blue-100 text-blue-900" : "hover:bg-neutral-200"}`}
                          >
                            <span>🌌 Win11 Bloom 蓝花</span>
                            {wallpaper === "modern" && <Check size={11} className="text-blue-700" />}
                          </button>
                          <button 
                            onClick={() => { logStatsClick(); setWallpaper("macos"); }} 
                            className={`w-full text-left py-1 px-2 rounded flex justify-between items-center ${wallpaper === "macos" ? "bg-blue-100 text-blue-900" : "hover:bg-neutral-200"}`}
                          >
                            <span>🏖️ macOS Mojave 沙滩</span>
                            {wallpaper === "macos" && <Check size={11} className="text-blue-700" />}
                          </button>
                          <button 
                            onClick={() => { logStatsClick(); setWallpaper("cyberpunk"); }} 
                            className={`w-full text-left py-1 px-2 rounded flex justify-between items-center ${wallpaper === "cyberpunk" ? "bg-blue-100 text-blue-900" : "hover:bg-neutral-200"}`}
                          >
                            <span>🎮 Cyberpunk 数码暗室</span>
                            {wallpaper === "cyberpunk" && <Check size={11} className="text-blue-700" />}
                          </button>
                          <button 
                            onClick={() => { logStatsClick(); setWallpaper("classic"); }} 
                            className={`w-full text-left py-1 px-2 rounded flex justify-between items-center ${wallpaper === "classic" ? "bg-blue-100 text-blue-900" : "hover:bg-neutral-200"}`}
                          >
                            <span>🟢 Win95 极简松石绿</span>
                            {wallpaper === "classic" && <Check size={11} className="text-blue-700" />}
                          </button>
                        </div>
                      </div>

                      {/* Display Preferences */}
                      <div className="bg-[#fbf9f4] p-2.5 rounded border border-neutral-300 shadow-sm flex flex-col gap-2">
                        <span className="font-black text-[9px] text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                          <Sliders size={12} />
                          <span>界面高级微调:</span>
                        </span>
                        
                        <div className="space-y-1.5 font-bold text-[10px]">
                          {/* Theme selection */}
                          <div>
                            <span className="text-neutral-500 block mb-1 text-[8px] uppercase">选择窗口皮肤主题:</span>
                            <div className="flex gap-1.5">
                              <button onClick={() => { logStatsClick(); setTheme("xp"); }} className={`px-2 py-0.5 rounded text-[9px] border ${theme === "xp" ? "bg-blue-100 text-blue-800 border-blue-400 font-extrabold" : "bg-white hover:bg-neutral-100 border-neutral-300"}`}>经典XP蓝</button>
                              <button onClick={() => { logStatsClick(); setTheme("dark"); }} className={`px-2 py-0.5 rounded text-[9px] border ${theme === "dark" ? "bg-neutral-800 text-white border-neutral-900 font-extrabold" : "bg-white hover:bg-neutral-100 border-neutral-300"}`}>深色灰</button>
                              <button onClick={() => { logStatsClick(); setTheme("rose"); }} className={`px-2 py-0.5 rounded text-[9px] border ${theme === "rose" ? "bg-rose-100 text-rose-800 border-rose-300 font-extrabold" : "bg-white hover:bg-neutral-100 border-neutral-300"}`}>马卡粉</button>
                            </div>
                          </div>

                          <div className="h-px bg-neutral-200 my-1" />

                          {/* Taskbar placement */}
                          <div>
                            <span className="text-neutral-500 block mb-1 text-[8px] uppercase">底部任务栏位置:</span>
                            <div className="flex gap-2">
                              <label className="flex items-center gap-1 cursor-pointer">
                                <input type="radio" checked={taskbarPosition === "bottom"} onChange={() => { logStatsClick(); setTaskbarPosition("bottom"); }} />
                                <span>屏幕底部</span>
                              </label>
                              <label className="flex items-center gap-1 cursor-pointer">
                                <input type="radio" checked={taskbarPosition === "top"} onChange={() => { logStatsClick(); setTaskbarPosition("top"); }} />
                                <span>屏幕顶部</span>
                              </label>
                            </div>
                          </div>

                          <div className="h-px bg-neutral-200 my-1" />

                          {/* Visual details */}
                          <div className="space-y-1">
                            <label className="flex items-center gap-1 cursor-pointer">
                              <input type="checkbox" checked={crtFilter} onChange={() => { logStatsClick(); setCrtFilter(!crtFilter); }} />
                              <span>启用 CRT 显示器扫描线</span>
                            </label>
                            <label className="flex items-center gap-1 cursor-pointer">
                              <input type="checkbox" checked={soundEnabled} onChange={() => { logStatsClick(); setSoundEnabled(!soundEnabled); }} />
                              <span>允许系统触发复古合成器音效</span>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* CPU/Memory sweep telemetry */}
                    <div className="bg-[#fbf9f4] p-3 rounded border border-neutral-300 shadow-sm flex flex-col gap-2">
                      <span className="font-black text-[9px] text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                        <Monitor size={12} />
                        <span>主机硬件性能诊断面板 (AISTUDIO TELEMETRY):</span>
                      </span>

                      <div className="grid grid-cols-3 gap-2.5 text-center">
                        <div className="bg-neutral-800 p-2 text-white font-mono rounded border border-black shadow">
                          <span className="text-[8px] text-neutral-400 uppercase">CPU 负载</span>
                          <p className="text-base font-bold text-green-400 animate-pulse">{cpuUsage}%</p>
                          <div className="w-full bg-neutral-700 h-1 rounded overflow-hidden mt-1">
                            <div className="bg-green-400 h-full transition-all duration-500" style={{ width: `${cpuUsage}%` }}></div>
                          </div>
                        </div>
                        <div className="bg-neutral-800 p-2 text-white font-mono rounded border border-black shadow">
                          <span className="text-[8px] text-neutral-400 uppercase">内存耗用</span>
                          <p className="text-base font-bold text-sky-400 animate-pulse">{ramUsage} GB</p>
                          <div className="w-full bg-neutral-700 h-1 rounded overflow-hidden mt-1">
                            <div className="bg-sky-400 h-full transition-all duration-500" style={{ width: `${(ramUsage / 64) * 100}%` }}></div>
                          </div>
                        </div>
                        <div className="bg-neutral-800 p-2 text-white font-mono rounded border border-black shadow">
                          <span className="text-[8px] text-neutral-400 uppercase">注意力完整度</span>
                          <p className={`text-base font-bold animate-pulse ${attentionIndex < 50 ? "text-red-500" : "text-amber-400"}`}>{attentionIndex}%</p>
                          <div className="w-full bg-neutral-700 h-1 rounded overflow-hidden mt-1">
                            <div className={`h-full transition-all duration-500 ${attentionIndex < 50 ? "bg-red-500" : "bg-amber-400"}`} style={{ width: `${attentionIndex}%` }}></div>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>

                  <div className="text-[8px] text-neutral-400 border-t border-neutral-300 pt-2 flex items-center justify-between">
                    <span>系统已正常开机: {Math.floor((Date.now() - stats.startTime) / 1000)} 秒</span>
                    <span>设备ID: AISTUDIO-DESKTOP-89A0</span>
                  </div>
                </div>
              )}

            </div>
          </div>
        );
      })}

      {/* 7. Bottom Taskbar (Responsive position depend on taskbarPosition) */}
      <div 
        id="desktop-taskbar" 
        className={`absolute left-0 w-full h-[38px] bg-gradient-to-r from-[#1e4ebc] via-[#2d6fec] to-[#143ea2] border-blue-400 p-0.5 flex items-center justify-between z-40 select-none shadow-2xl ${
          taskbarPosition === "bottom" ? "bottom-0 border-t" : "top-0 border-b"
        }`}
        onClick={(e) => { e.stopPropagation(); }}
      >
        <div className="flex items-center gap-2 h-full">
          {/* Green Start button */}
          <button
            id="taskbar-btn-start"
            onClick={() => setStartMenuOpen(!startMenuOpen)}
            className="h-full px-5 bg-gradient-to-r from-[#3e933f] via-[#52be53] to-[#398a3b] text-white rounded-r border-r border-[#2d5c2d] hover:brightness-110 flex items-center gap-1.5 focus:outline-none cursor-pointer active:brightness-95"
          >
            <span className="font-serif italic text-sm font-bold tracking-widest drop-shadow text-glow uppercase">开始</span>
          </button>

          {/* Active slots */}
          <div className="flex items-center h-full gap-1 overflow-x-auto max-w-sm md:max-w-xl">
            {(Object.values(windows) as WindowInstance[]).map((win) => {
              if (!win.isOpen) return null;

              return (
                <button
                  key={win.id}
                  id={`taskbar-slot-${win.id}`}
                  onClick={() => setWindows(p => ({ ...p, [win.id]: { ...win, isMinimized: !win.isMinimized && win.zIndex === topZIndex ? true : false, zIndex: win.isMinimized ? topZIndex + 1 : win.zIndex } }))}
                  className={`h-7 px-3 rounded-md border text-[10px] font-bold text-white tracking-wide shrink-0 transition flex items-center gap-1 ${
                    win.isMinimized 
                      ? "bg-blue-900/40 border-blue-900/50 hover:bg-blue-800/50 text-[#ccc]" 
                      : "bg-[#356ee7] border-blue-400 hover:bg-blue-500 shadow-inner !text-[#ffd166]"
                  }`}
                >
                  <span className="truncate max-w-[80px] md:max-w-[120px]">{win.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Start Menu Popup */}
        {startMenuOpen && (
          <div 
            id="start-menu-p" 
            className={`absolute w-64 bg-white border-2 border-[#1c47be] rounded shadow-2xl overflow-hidden flex flex-col font-sans z-50 ${
              taskbarPosition === "bottom" ? "bottom-[38px] left-0 rounded-t" : "top-[38px] left-0 rounded-b"
            }`}
          >
            {/* Header profile info */}
            <div className="bg-gradient-to-r from-[#173fa7] to-[#3068de] text-white p-3 flex items-center gap-2 border-b border-blue-400 select-none">
              <div className="w-8 h-8 rounded-full bg-orange-400 border border-white flex items-center justify-center text-xs font-bold leading-none uppercase shadow">
                {user.name[0]}
              </div>
              <div>
                <h5 className="font-black text-xs">{user.name}</h5>
                <p className="text-[9px] text-[#ffd166] uppercase tracking-wider font-mono">在线员工 • {user.gender === "male" ? "先生" : "女士"}</p>
              </div>
            </div>

            {/* Main panels */}
            <div className="flex h-64 text-xs select-none bg-white">
              <div className="w-1/2 p-1 text-gray-700 border-r border-gray-100 flex flex-col gap-0.5 overflow-y-auto bg-white">
                <button onClick={() => toggleWindow("qiandu")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>🔍 千度引擎</span>
                </button>
                <button onClick={() => toggleWindow("boss")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>💬 企业微信</span>
                </button>
                <button onClick={() => toggleWindow("camera")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>📹 安全监视</span>
                </button>
                <button onClick={() => toggleWindow("minesweeper")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>🎮 经典扫雷</span>
                </button>
                <button onClick={() => toggleWindow("music")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>🎵 像素八音盒</span>
                </button>
                <button onClick={() => toggleWindow("diary")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>📝 摸鱼日记.txt</span>
                </button>
                <button onClick={() => toggleWindow("tetris")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>🧱 俄罗斯方块</span>
                </button>
                <button onClick={() => toggleWindow("snake")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>🐍 像素贪吃蛇</span>
                </button>
                <button onClick={() => toggleWindow("stocks")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>📈 同花顺股票软件</span>
                </button>
                <button onClick={() => toggleWindow("calculator")} className="flex items-center gap-1.5 p-1 hover:bg-[#3156cf] hover:text-white rounded text-left transition text-[9px] font-bold shrink-0">
                  <span>📟 科学计算器</span>
                </button>
                <button onClick={() => toggleWindow("settings")} className="flex items-center gap-1.5 p-1.5 hover:bg-[#3156cf] hover:text-white rounded text-[#18399c] text-left transition text-[9px] font-black shrink-0">
                  <span>⚙️ 控制面板设置</span>
                </button>
                <div className="h-px bg-neutral-200 my-0.5" />
                <button onClick={() => toggleWindow("work-app")} className="flex items-center gap-1.5 p-1.5 hover:bg-[#3156cf] hover:text-white rounded text-green-700 text-left transition text-[9px] font-black shrink-0">
                  <span>💼 核心工作任务</span>
                </button>
              </div>

              {/* Start Menu Sidebar */}
              <div className="w-1/2 p-1.5 bg-[#dfdfdf] border-l border-gray-200 flex flex-col justify-between text-[10px] font-bold text-gray-700">
                <div className="space-y-1">
                  <button onClick={() => toggleWindow("my-computer")} className="flex items-center gap-1 hover:underline text-left w-full">
                    <span>我的电脑</span>
                  </button>
                  <button onClick={() => toggleWindow("recycle-bin")} className="flex items-center gap-1 hover:underline text-left w-full">
                    <span>回收站</span>
                  </button>
                  <div className="h-px bg-gray-300 w-full my-1"></div>
                  <div className="text-[8px] text-gray-400 font-mono tracking-wide">
                    拖延诱惑等级: <br/>
                    <span className="text-red-600 font-extrabold">{
                      stats.level === 0 ? "○ 清醒" :
                      stats.level === 1 ? "● 试探" :
                      stats.level === 2 ? "● 沉迷" :
                      stats.level === 3 ? "●● 危机" : "●●● 末日"
                    }</span>
                  </div>
                </div>

                <button
                  onClick={() => { playAudioClick(200, "sawtooth"); onFinishGame(stats); }}
                  className="w-full flex items-center justify-center gap-1 py-1.5 bg-gradient-to-r from-red-600 to-rose-700 text-white font-extrabold rounded select-none cursor-pointer tracking-wider text-[9px] hover:brightness-115 transition"
                >
                  <Power size={10} />
                  <span>关机并去工作结算</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Right Taskbar clock & info (Tray) */}
        <div id="taskbar-tray" className="h-full px-3.5 bg-gradient-to-r from-[#1846c4] via-[#0c31a7] to-[#1236a2] border-l border-blue-400 flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-1 text-white">
            <ShieldAlert size={13} className="text-yellow-400 shrink-0" />
            <span className="text-[9px] font-black uppercase tracking-widest text-[#ffd166]">
              拖延: {
                stats.level === 0 ? "清醒" :
                stats.level === 1 ? "试探" :
                stats.level === 2 ? "沉迷" :
                stats.level === 3 ? "危机" : "末日"
              }
            </span>
          </div>

          <button onClick={() => setSoundEnabled(!soundEnabled)} className="text-white hover:text-[#ffd166] cursor-pointer">
            {soundEnabled ? <Volume2 size={13} /> : <VolumeX size={13} className="text-neutral-400" />}
          </button>

          <div className="h-px bg-blue-400 w-3 rotate-90 shrink-0"></div>

          <span className="text-[#ffd166] text-xs font-mono font-bold font-glow shrink-0 tracking-wider">
            {systemTime || "14:16"}
          </span>
        </div>

      </div>

    </div>
  );
}
