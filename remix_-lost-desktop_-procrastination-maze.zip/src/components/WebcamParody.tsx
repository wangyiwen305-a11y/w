import React, { useState, useEffect, useRef } from "react";
import { Camera, RefreshCw, XCircle, AlertTriangle, Video } from "lucide-react";

interface WebcamParodyProps {
  onLoggedClick: () => void;
  userName: string;
}

export default function WebcamParody({ onLoggedClick, userName }: WebcamParodyProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [permissionState, setPermissionState] = useState<"loading" | "granted" | "denied">("loading");
  const [feedbackText, setFeedbackText] = useState("正在扫描面部发呆特征...");
  const [capturedImg, setCapturedImg] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const funnySarcasticPhrases = [
    "你看上去很认真，但你的工作文件已经哭了长达两个半小时。",
    "你盯着屏幕的样子，像极了在等待灵感，实际上由于脑壳放空正在等外卖。",
    "【检测报告】：双眼无神，手握鼠标却无丝毫律动，初步判定此职员处于发呆自欺欺人状态。",
    "检测到强烈的摸鱼电波，您的面部诚实地暴露出对于写PPT的抗拒。",
    "不要假装在思考，程序员的灵感并非来自对虚无桌面的持久凝视！"
  ];

  const startWebcam = async () => {
    setPermissionState("loading");
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { width: 320, height: 240 }
      });
      setStream(mediaStream);
      setPermissionState("granted");
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      console.warn("Camera access denied or unequipped:", err);
      setPermissionState("denied");
    }
  };

  const handleCapture = () => {
    onLoggedClick();
    if (videoRef.current && permissionState === "granted") {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = 300;
        canvas.height = 220;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(videoRef.current, 0, 0, 300, 220);
          
          // Draw a silly overlay
          ctx.font = "bold 13px system-ui, sans-serif";
          ctx.fillStyle = "red";
          ctx.fillText("👀 摸鱼嫌疑人", 10, 30);
          
          setCapturedImg(canvas.toDataURL("image/png"));
          setFeedbackText("拍摄完毕！已作为‘拖延症患者面部留证’安全留存归档。");
        }
      } catch (e) {
        console.error("Capture failure:", e);
      }
    } else {
      // Fake photograph capture
      setCapturedImg("https://images.unsplash.com/photo-1531256456869-7f44cf609c55?auto=format&fit=crop&w=300&h=220");
      setFeedbackText("已自动为您匹配‘灵魂代理假面相’：正在进行高阶冥想（摸鱼）。");
    }
  };

  const handleRefreshFeedback = () => {
    onLoggedClick();
    const rand = funnySarcasticPhrases[Math.floor(Math.random() * funnySarcasticPhrases.length)];
    setFeedbackText(rand);
  };

  useEffect(() => {
    startWebcam();
    const textInterval = setInterval(() => {
      const rand = funnySarcasticPhrases[Math.floor(Math.random() * funnySarcasticPhrases.length)];
      setFeedbackText(rand);
    }, 6000);

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      clearInterval(textInterval);
    };
  }, []);

  return (
    <div id="capture-pictures-root" className="w-full h-full bg-[#efebde] text-gray-800 p-3 font-sans flex flex-col justify-between select-none">
      
      {/* Upper informational bar */}
      <div id="capture-top-notif" className="bg-[#18399c] text-white px-3 py-1.5 rounded text-[11px] font-bold shrink-0 shadow flex items-center gap-2">
        <Video size={14} className="text-yellow-400 rotate-12 shrink-0 animate-pulse" />
        <span>注意：由于您长时间游离在办公网络之外，意志监视器已自动锁焦面部。</span>
      </div>

      {/* Retro styled Windows Companion interface */}
      <div className="flex-grow flex flex-col items-center justify-center py-2 px-1 text-center">
        <h3 className="font-extrabold text-sm text-[#18399c] tracking-wide mt-1">您想要拷贝哪张照片？ / Which picture do you want to copy?</h3>
        <p className="text-[10px] text-gray-500 max-w-sm leading-relaxed mt-0.5 mb-2">
          Click the capture button to create a picture from video. Then select the picture you want to retrieve and click Get Picture.
        </p>

        {/* Dual Panels layout mirroring the Windows XP picture manager */}
        <div className="w-full grid grid-cols-2 gap-3 max-w-md bg-white p-2 rounded-md border border-gray-400 shadow-inner">
          
          {/* Left panel: Active feed stream */}
          <div className="flex flex-col items-center justify-center p-1 bg-gray-50 rounded border border-gray-200 aspect-video relative overflow-hidden group">
            {permissionState === "granted" ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover scale-x-[-1] rounded"
              />
            ) : permissionState === "loading" ? (
              <div className="flex flex-col items-center text-gray-500 gap-1.5 text-center p-2">
                <RefreshCw size={24} className="animate-spin text-blue-600" />
                <span className="text-[10px] font-bold">正在检测摄像头...</span>
              </div>
            ) : (
              <div className="flex flex-col items-center text-red-700 gap-1.5 text-center p-2">
                <AlertTriangle size={24} className="text-yellow-500 animate-bounce" />
                <span className="text-[10px] font-extrabold leading-tight">摄像头被胶带贴住了？</span>
                <p className="text-[9px] text-gray-400 leading-normal">不过放心，意志力红框依然能通过键盘抖动频率锁定你！</p>
                <button onClick={startWebcam} className="text-[9px] bg-blue-600 text-white rounded px-2 py-0.5 font-bold shadow">重新检测</button>
              </div>
            )}

            {/* Simulated target overlay */}
            {permissionState === "granted" && (
              <div className="absolute inset-0 border-2 border-dashed border-red-500/40 pointer-events-none rounded flex items-center justify-center">
                <div className="w-6 h-6 border-b-2 border-r-2 border-red-500/50 absolute bottom-1 right-1"></div>
                <div className="w-6 h-6 border-t-2 border-l-2 border-red-500/50 absolute top-1 left-1"></div>
                <div className="w-3 h-3 bg-red-400 rounded-full animate-ping"></div>
              </div>
            )}
          </div>

          {/* Right panel: Captured Snapshot Picture */}
          <div className="flex flex-col items-center justify-center bg-gray-100 rounded border border-gray-300 relative overflow-hidden select-none">
            {capturedImg ? (
              <img
                src={capturedImg}
                alt="Captured Snapshot"
                className="w-full h-full object-cover rounded"
              />
            ) : (
              <div className="flex flex-col items-center text-gray-400 p-2 text-center text-[10px] font-bold">
                <Camera size={26} className="text-gray-300 mb-1" />
                <span>留档图片空缺</span>
                <span className="text-[8px] text-opacity-50">点击下方拍摄捕捉</span>
              </div>
            )}
          </div>

        </div>

        {/* Dynamic hand-written / ironic overlay subtitling */}
        <div className="mt-2.5 max-w-sm bg-yellow-50 border border-yellow-200 p-2 rounded text-left shadow-sm">
          <p className="text-[10px] font-extrabold text-red-600 uppercase tracking-widest flex items-center gap-1">
            <span>● 心理催促字幕（催促催促）：</span>
          </p>
          <p className="text-[11px] text-gray-700 leading-relaxed font-semibold italic mt-1 select-text">
            “{feedbackText}”
          </p>
        </div>
      </div>

      {/* Control Actions buttons row */}
      <div id="capture-bottom-buttons" className="flex items-center justify-between border-t border-gray-300 pt-2 shrink-0 select-none">
        <button
          onClick={handleRefreshFeedback}
          className="px-3 py-1.5 border border-gray-400 hover:bg-gray-200 rounded text-xs text-gray-600 font-bold transition flex items-center gap-1 cursor-pointer"
        >
          <RefreshCw size={12} />
          <span>换一嘴讽刺</span>
        </button>
        <button
          onClick={handleCapture}
          className="px-5 py-2 bg-gradient-to-r from-blue-700 to-indigo-800 hover:from-blue-800 hover:to-indigo-900 border-2 border-[#18399c] text-white rounded font-black text-xs shadow-md active:translate-y-px transition flex items-center gap-1 cursor-pointer"
        >
          <Camera size={14} />
          <span>拍摄 Snapshot</span>
        </button>
      </div>

    </div>
  );
}
