import React, { useState } from "react";
import { UserState, JobType, DistractionType, TimeStyle } from "../types";
import { User, ShieldAlert, Laptop, ArrowRight, Key, HelpCircle } from "lucide-react";

interface BootScreenProps {
  onLogin: (user: UserState) => void;
}

export default function BootScreen({ onLogin }: BootScreenProps) {
  const [selectedProfile, setSelectedProfile] = useState<string | null>(null);
  const [passwordInput, setPasswordInput] = useState("");
  const [showConfig, setShowConfig] = useState(false);
  const [name, setName] = useState("");
  const [gender, setGender] = useState<"male" | "female" | "other">("male");
  const [jobType, setJobType] = useState<JobType>("report");
  const [distraction, setDistraction] = useState<DistractionType>("video");
  const [timeStyle, setTimeStyle] = useState<TimeStyle>("random");
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loadingStep, setLoadingStep] = useState("");

  // Synthesizes a nostalgic, high-fidelity startup chord
  const playStartupSound = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const playTone = (freq: number, start: number, duration: number, type: OscillatorType = "sine") => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, start);
        
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.12, start + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + duration);
      };
      
      const now = ctx.currentTime;
      // Synthesize 5-note melodic progression resembling classic XP login chime
      playTone(261.63, now, 1.4, "triangle"); // C4
      playTone(329.63, now + 0.15, 1.4, "sine"); // E4
      playTone(392.00, now + 0.3, 1.6, "sine"); // G4
      playTone(523.25, now + 0.45, 2.0, "triangle"); // C5
      playTone(659.25, now + 0.6, 2.4, "sine"); // E5
    } catch (e) {
      console.warn("Web Audio API is blocked or failed", e);
    }
  };

  const handlePredefinedUserSelect = (preName: string) => {
    setSelectedProfile(preName);
    setPasswordInput("");
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProfile) return;
    
    // Play the awesome synthesized sound immediately!
    playStartupSound();

    setName(selectedProfile);
    setShowConfig(true);
  };

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsLoggingIn(true);
    const steps = [
      "正在连接注意力核心局域网...",
      "正在载入您专属的拖延画像数据...",
      "正在组装安全桌面沙盒容器...",
      "正在初始化键盘动作监测探针...",
      "验证通过！正在进入拖延迷宫..."
    ];

    let current = 0;
    setLoadingStep(steps[0]);

    const interval = setInterval(() => {
      current += 1;
      if (current < steps.length) {
        setLoadingStep(steps[current]);
      } else {
        clearInterval(interval);
        onLogin({
          name: name.trim(),
          gender,
          jobType,
          distraction,
          timeStyle
        });
      }
    }, 900);
  };

  return (
    <div id="xp-boot-screen" className="relative w-full h-screen bg-[#5a7edc] flex items-center justify-center font-sans overflow-hidden select-none crt-scanlines">
      {/* Top OS boundary ribbon */}
      <div id="xp-top-band" className="absolute top-0 left-0 w-full h-[6px] bg-[#18399c] z-10"></div>
      
      {/* Bottom Status tray bar */}
      <div id="xp-bottom-band" className="absolute bottom-0 left-0 w-full h-[64px] bg-[#18399c] flex items-center justify-between px-8 text-white text-xs text-opacity-80 border-t border-[#294fb8] z-10">
        <div className="flex items-center gap-1.5 font-medium">
          <span className="font-extrabold text-white bg-red-600 px-1 rounded scale-90">XP</span>
          <span>AISTUDIO ATTENTION CONTROL SYSTEM v1.2</span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span className="flex items-center gap-1.5"><Laptop size={13} /> 拖拽、双击均可与窗口完美交互</span>
          <div className="h-4 w-px bg-white/20" />
          <span className="text-[#ffd166]">按关机(开始菜单)可中途投降并结算</span>
        </div>
      </div>

      {/* Main Lock screen Layout */}
      {!showConfig && !isLoggingIn ? (
        <div id="xp-login-layout" className="w-full max-w-5xl flex items-stretch min-h-[460px] z-10 bg-[#5a7edc]">
          
          {/* Left panel: Windows branding logo and slogan */}
          <div id="xp-brand-section" className="flex flex-col items-end justify-center text-white text-right w-1/2 border-r-[2.5px] border-amber-400/70 pr-12 py-10 relative">
            <div className="flex flex-col items-end mb-1">
              <span className="font-serif italic font-bold text-3xl text-neutral-200 leading-none">Microsoft</span>
              <div className="bg-gradient-to-r from-orange-400 via-rose-500 to-yellow-500 text-transparent bg-clip-text text-5xl font-black italic flex items-center gap-1 drop-shadow-md tracking-wider">
                Windows<span className="text-white text-2xl font-bold not-italic bg-orange-500 px-1.5 py-0.5 rounded ml-1 shadow-lg border border-orange-400">XP</span>
              </div>
            </div>
            
            <div className="h-px bg-white/20 w-48 my-4" />
            
            <div className="text-orange-200 font-extrabold text-xs uppercase tracking-widest leading-relaxed">
              请选择您的用户卡片登录电脑
            </div>
            <p className="text-white/70 text-xs mt-3 leading-relaxed max-w-xs text-right font-medium">
              本超级工作站能自动捕获并分析您的一切分心动作。若想要安全提取昨日的工作成果，请努力寻找并解密密匙！
            </p>
          </div>

          {/* Right panel: User list & active password slider */}
          <div id="xp-users-list" className="flex flex-col justify-center gap-5 w-1/2 pl-12 text-white">
            
            {/* PROFILE 1: David */}
            <div className="flex flex-col">
              <button 
                onClick={() => handlePredefinedUserSelect("小张 (David)")} 
                className={`flex items-center gap-4 p-2 rounded-lg border-2 text-left transition duration-150 ${
                  selectedProfile === "小张 (David)" 
                    ? "border-orange-400 bg-blue-600/50 shadow-inner" 
                    : "border-transparent hover:border-blue-400 hover:bg-blue-600/30"
                }`}
              >
                <div className="w-12 h-12 rounded-lg border-2 border-orange-400 overflow-hidden bg-slate-300 shadow">
                  <img referrerPolicy="no-referrer" src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&h=120" alt="David" className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="font-extrabold text-sm text-white hover:text-yellow-300">David</div>
                  <div className="text-[10px] text-blue-200 font-mono">系统研发工程师 / 代码狂热牛马</div>
                </div>
              </button>

              {/* Password expansion field */}
              {selectedProfile === "小张 (David)" && (
                <form onSubmit={handlePasswordSubmit} className="pl-16 pr-4 py-2 flex items-center gap-2 animate-fadeIn">
                  <Key size={12} className="text-amber-300" />
                  <input
                    type="password"
                    autoFocus
                    placeholder="可输入任意密码并回车..."
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="flex-grow px-2 py-1 text-xs bg-white text-black border border-blue-900 rounded shadow focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium placeholder-gray-400"
                  />
                  <button type="submit" className="w-6 h-6 bg-[#39c43c] hover:bg-green-500 rounded-full flex items-center justify-center text-white cursor-pointer hover:scale-105 active:scale-95 transition">
                    <ArrowRight size={14} className="stroke-[3]" />
                  </button>
                </form>
              )}
            </div>

            {/* PROFILE 2: Pam */}
            <div className="flex flex-col">
              <button 
                onClick={() => handlePredefinedUserSelect("小帕 (Pam)")} 
                className={`flex items-center gap-4 p-2 rounded-lg border-2 text-left transition duration-150 ${
                  selectedProfile === "小帕 (Pam)" 
                    ? "border-yellow-400 bg-blue-600/50 shadow-inner" 
                    : "border-transparent hover:border-blue-400 hover:bg-blue-600/30"
                }`}
              >
                <div className="w-12 h-12 rounded-lg border-2 border-yellow-400 overflow-hidden bg-slate-300 shadow">
                  <img referrerPolicy="no-referrer" src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&h=120" alt="Pam" className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="font-extrabold text-sm text-white hover:text-yellow-300">Pam</div>
                  <div className="text-[10px] text-blue-200 font-mono">产品设计经理 / 职业幻灯片(PPT)大师</div>
                </div>
              </button>

              {/* Password expansion */}
              {selectedProfile === "小帕 (Pam)" && (
                <form onSubmit={handlePasswordSubmit} className="pl-16 pr-4 py-2 flex items-center gap-2 animate-fadeIn">
                  <Key size={12} className="text-amber-300" />
                  <input
                    type="password"
                    autoFocus
                    placeholder="可输入任意密码并回车..."
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="flex-grow px-2 py-1 text-xs bg-white text-black border border-blue-900 rounded shadow focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium placeholder-gray-400"
                  />
                  <button type="submit" className="w-6 h-6 bg-[#39c43c] hover:bg-green-500 rounded-full flex items-center justify-center text-white cursor-pointer hover:scale-105 active:scale-95 transition">
                    <ArrowRight size={14} className="stroke-[3]" />
                  </button>
                </form>
              )}
            </div>

            {/* PROFILE 3: Margot */}
            <div className="flex flex-col">
              <button 
                onClick={() => handlePredefinedUserSelect("玛戈 (Margot)")} 
                className={`flex items-center gap-4 p-2 rounded-lg border-2 text-left transition duration-150 ${
                  selectedProfile === "玛戈 (Margot)" 
                    ? "border-green-400 bg-blue-600/50 shadow-inner" 
                    : "border-transparent hover:border-blue-400 hover:bg-blue-600/30"
                }`}
              >
                <div className="w-12 h-12 rounded-lg border-2 border-green-400 overflow-hidden bg-slate-300 shadow">
                  <img referrerPolicy="no-referrer" src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=120&h=120" alt="Margot" className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="font-extrabold text-sm text-white hover:text-yellow-300">Margot</div>
                  <div className="text-[10px] text-blue-200 font-mono">高校在读研究生 / 文献综述困难户</div>
                </div>
              </button>

              {/* Password expansion */}
              {selectedProfile === "玛戈 (Margot)" && (
                <form onSubmit={handlePasswordSubmit} className="pl-16 pr-4 py-2 flex items-center gap-2 animate-fadeIn">
                  <Key size={12} className="text-amber-300" />
                  <input
                    type="password"
                    autoFocus
                    placeholder="可输入任意密码并回车..."
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="flex-grow px-2 py-1 text-xs bg-white text-black border border-blue-900 rounded shadow focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium placeholder-gray-400"
                  />
                  <button type="submit" className="w-6 h-6 bg-[#39c43c] hover:bg-green-500 rounded-full flex items-center justify-center text-white cursor-pointer hover:scale-105 active:scale-95 transition">
                    <ArrowRight size={14} className="stroke-[3]" />
                  </button>
                </form>
              )}
            </div>

            {/* Splitter Line */}
            <div className="h-px bg-white/10 my-0.5 w-[90%]"></div>

            {/* Custom employee card register button */}
            <button 
              onClick={() => {
                setSelectedProfile(null);
                setName("");
                setShowConfig(true);
              }}
              className="flex items-center gap-4 p-2 rounded-lg border-2 border-dashed border-blue-300/40 hover:border-yellow-300 hover:bg-blue-600/30 transition text-left group"
            >
              <div className="w-12 h-12 rounded-lg border border-neutral-300/30 flex items-center justify-center bg-blue-900/40 group-hover:bg-blue-800/60 shadow">
                <User size={22} className="text-blue-200 group-hover:text-white" />
              </div>
              <div>
                <div className="font-extrabold text-xs text-blue-200 group-hover:text-white transition">创建自定义职员账户...</div>
                <div className="text-[10px] text-blue-300/70">自定义您的称呼、本职任务和专注方向</div>
              </div>
            </button>

          </div>
        </div>
      ) : showConfig && !isLoggingIn ? (
        /* Configuration wizard card */
        <div id="xp-config-wizard" className="w-full max-w-xl bg-neutral-100 rounded-xl shadow-2xl border-4 border-[#18399c] overflow-hidden p-6 z-10 animate-scaleUp">
          <div id="wizard-header" className="flex items-center gap-3 border-b-2 border-neutral-200 pb-3 mb-4">
            <div className="bg-[#18399c] text-white p-2 rounded-lg shadow-md">
              <Laptop size={20} />
            </div>
            <div>
              <h2 className="text-[#18399c] font-black text-sm">AISTUDIO 员工注意力画像卡</h2>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Configure Attention parameters</p>
            </div>
          </div>

          <form id="wizard-form" onSubmit={handleStart} className="flex flex-col gap-4 text-xs text-gray-700">
            {/* Input Name */}
            <div>
              <label className="block font-black text-[10px] text-gray-500 uppercase tracking-wider mb-1">您的职员称呼 (姓名):</label>
              <input
                id="form-input-name"
                type="text"
                required
                placeholder="比如：小张、王经理、摸鱼老司机"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-gray-300 rounded focus:border-[#18399c] focus:outline-none placeholder-gray-400 font-bold"
              />
            </div>

            {/* Gender Choice */}
            <div>
              <label className="block font-black text-[10px] text-gray-500 tracking-wider uppercase mb-1">系统人称称呼后缀:</label>
              <div className="flex gap-4 font-bold text-gray-600">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="radio" checked={gender === "male"} onChange={() => setGender("male")} className="text-[#18399c]" />
                  <span>先生 / 男士</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="radio" checked={gender === "female"} onChange={() => setGender("female")} className="text-[#18399c]" />
                  <span>女士 / 闺蜜</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="radio" checked={gender === "other"} onChange={() => setGender("other")} className="text-[#18399c]" />
                  <span>其他 / 保密</span>
                </label>
              </div>
            </div>

            {/* Workspace Task Selection (JobType) */}
            <div>
              <label className="block font-black text-[10px] text-gray-500 tracking-wider uppercase mb-1">您本该在2小时前做完的“真正工作”是:</label>
              <select
                id="form-select-job"
                value={jobType}
                onChange={(e) => setJobType(e.target.value as JobType)}
                className="w-full px-3 py-1.5 bg-white border border-gray-300 rounded focus:border-[#18399c] focus:outline-none font-bold text-gray-700 cursor-pointer"
              >
                <option value="report">📊 制作季度汇报PPT (产品设计、销售Q2汇报)</option>
                <option value="code">💻 编写系统核心模块代码 (Java/TypeScript开发调试)</option>
                <option value="design">🎨 绘制高保真移动原型交互稿 (Figma/Sketch)</option>
                <option value="literature">📚 查阅科学研究论文 (毕业文献/研究综述)</option>
                <option value="meeting">📝 整理上百人全员周会会议纪要 (Align拉通汇报)</option>
              </select>
            </div>

            {/* Favorite Procrastination Distraction (DistractionType) */}
            <div>
              <label className="block font-black text-[10px] text-gray-500 tracking-wider uppercase mb-1">开始工作时，你最喜欢双击哪个诱惑图标:</label>
              <div className="grid grid-cols-2 gap-2 mt-1">
                <button
                  id="btn-dist-video"
                  type="button"
                  onClick={() => setDistraction("video")}
                  className={`px-3 py-1.5 border rounded-lg text-left transition text-[11px] ${
                    distraction === "video" ? "border-[#18399c] bg-indigo-50/80 font-bold text-[#18399c]" : "border-gray-200 bg-white"
                  }`}
                >
                  🎬 抖音滑滑 (刷短视频/段子)
                </button>
                <button
                  id="btn-dist-cats"
                  type="button"
                  onClick={() => setDistraction("cats")}
                  className={`px-3 py-1.5 border rounded-lg text-left transition text-[11px] ${
                    distraction === "cats" ? "border-[#18399c] bg-indigo-50/80 font-bold text-[#18399c]" : "border-gray-200 bg-white"
                  }`}
                >
                  🐱 秘密小猫 (吸猫解闷沙雕图)
                </button>
                <button
                  id="btn-dist-social"
                  type="button"
                  onClick={() => setDistraction("social")}
                  className={`px-3 py-1.5 border rounded-lg text-left transition text-[11px] ${
                    distraction === "social" ? "border-[#18399c] bg-indigo-50/80 font-bold text-[#18399c]" : "border-gray-200 bg-white"
                  }`}
                >
                  🌶️ 贴吧吃瓜 (看八卦/大厂热度)
                </button>
                <button
                  id="btn-dist-shopping"
                  type="button"
                  onClick={() => setDistraction("shopping")}
                  className={`px-3 py-1.5 border rounded-lg text-left transition text-[11px] ${
                    distraction === "shopping" ? "border-[#18399c] bg-indigo-50/80 font-bold text-[#18399c]" : "border-gray-200 bg-white"
                  }`}
                >
                  🛍️ 羊毛秒杀 (薅羊毛限时专区)
                </button>
              </div>
            </div>

            {/* Typical Peak Hours (TimeStyle) */}
            <div>
              <label className="block font-black text-[10px] text-gray-500 tracking-wider uppercase mb-1">你通常欺骗自己说几点钟开始高强度专注:</label>
              <div className="flex gap-4 font-bold text-gray-600">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="radio" checked={timeStyle === "morning"} onChange={() => setTimeStyle("morning")} className="text-[#18399c]" />
                  <span>清晨 07:00 (元气满满)</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="radio" checked={timeStyle === "midnight"} onChange={() => setTimeStyle("midnight")} className="text-[#18399c]" />
                  <span>深夜 24:00 (网抑云附体)</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="radio" checked={timeStyle === "random"} onChange={() => setTimeStyle("random")} className="text-[#18399c]" />
                  <span>随缘 (DDL到眼前)</span>
                </label>
              </div>
            </div>

            {/* Form actions */}
            <div className="flex items-center justify-between border-t border-neutral-200 pt-3 mt-1.5">
              <button
                id="wizard-cancel"
                type="button"
                onClick={() => {
                  setShowConfig(false);
                  setSelectedProfile(null);
                }}
                className="px-4 py-2 hover:bg-neutral-200 text-gray-500 rounded font-bold transition text-[10px]"
              >
                返回账户选择
              </button>
              <button
                id="wizard-submit"
                type="submit"
                className="flex items-center gap-1.5 px-5 py-2 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-extrabold rounded-lg shadow-md cursor-pointer transition text-[11px]"
              >
                <span>解压系统并登录</span>
                <ArrowRight size={13} className="stroke-[3]" />
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* Real-looking Loading animation bar */
        <div id="xp-loader-box" className="text-center text-white z-10 flex flex-col items-center gap-4">
          <div className="relative flex items-center justify-center">
            <div className="w-16 h-16 rounded-full border-4 border-white/20 border-t-white animate-spin"></div>
            <Laptop size={20} className="absolute text-white animate-pulse" />
          </div>
          <div>
            <p className="text-base font-black tracking-wider text-white mb-1 animate-pulse">{loadingStep}</p>
            <p className="text-[10px] text-[#ffd166] font-mono uppercase tracking-widest">
              Securing Workstation Sandbox Container...
            </p>
          </div>
        </div>
      )}

      {/* Decorative Warning disclaimer box */}
      <div id="aesthetic-disclaimer" className="absolute bottom-20 right-8 max-w-xs bg-black/30 backdrop-blur text-white p-3.5 rounded-xl border border-white/10 text-[10px] leading-relaxed flex items-start gap-2.5 max-md:hidden">
        <ShieldAlert size={16} className="text-yellow-400 shrink-0" />
        <div>
          <span className="font-extrabold block text-yellow-300">Attention Sandbox Alert:</span>
          系统已经成功拦截昨日的所有工作，并自动注入了抖音滑滑、经典扫雷、点点八音盒和同花顺股票软件。您必须设法在千度搜索引擎中检索解密密钥，解除文件锁定！
        </div>
      </div>
    </div>
  );
}
