import React, { useState, useEffect } from "react";
import { TrendingUp, TrendingDown, RefreshCw, DollarSign, BookOpen, Clock, AlertTriangle } from "lucide-react";

interface StocksAppProps {
  onLoggedClick: () => void;
}

interface Stock {
  code: string;
  name: string;
  price: number;
  open: number;
  high: number;
  low: number;
  changePercent: number;
  history: number[]; // for miniature charts
  vol: string;
}

const INITIAL_STOCKS: Stock[] = [
  { code: "600123.SH", name: "茅台摸鱼", price: 1888.50, open: 1850.00, high: 1910.00, low: 1845.00, changePercent: 2.08, history: [1850, 1860, 1875, 1845, 1890, 1880, 1888.5], vol: "14.5万手" },
  { code: "600234.SH", name: "拼老板命", price: 23.45, open: 26.50, high: 26.80, low: 22.10, changePercent: -11.51, history: [26.5, 26.0, 25.1, 24.3, 22.1, 23.0, 23.45], vol: "89.2万手" },
  { code: "600999.SH", name: "猝死防范制药", price: 68.80, open: 62.10, high: 68.80, low: 62.10, changePercent: 10.00, history: [62.1, 63.5, 64.8, 65.2, 66.0, 67.5, 68.8], vol: "22.4万手" },
  { code: "300456.SZ", name: "下班回家控投", price: 99.60, open: 100.50, high: 102.00, low: 98.40, changePercent: -0.90, history: [100.5, 101.2, 99.0, 102.0, 98.4, 99.1, 99.6], vol: "8.1万手" },
  { code: "000789.SZ", name: "企业八卦股份", price: 12.88, open: 12.10, high: 13.50, low: 12.00, changePercent: 6.45, history: [12.1, 12.3, 12.0, 12.4, 13.2, 12.7, 12.88], vol: "112.9万手" },
  { code: "002233.SZ", name: "工资守护证券", price: 8.55, open: 8.55, high: 8.65, low: 8.42, changePercent: 0.00, history: [8.55, 8.58, 8.45, 8.50, 8.42, 8.61, 8.55], vol: "41.6万手" },
];

const NEWS_FEED = [
  "重磅：因拼老板命(600234)员工集体请假，股价触发惊天暴跌，大笔资金仓皇撤离。",
  "传言：下班回家控股拟于近期发布「17:00提前撤退」机制，刺激下班概念全板块震荡领涨！",
  "猝死防范制药(600999)发布护肝胶囊三期临床大捷，防猝死概念开盘封死涨停板！",
  "今日社评：在严酷的工作环境里，理性的员工通过高难度摸鱼实现了资本利得的高效反向套利。",
  "资金流向：主力资金大量流入[茅台摸鱼]，疑似职场资深老油条正在抱团避险性建仓。",
  "重磅传闻：部分公司宣布引入AI无人值守抓捕摸鱼器，多支加班概念股应声下暴。"
];

export default function StocksApp({ onLoggedClick }: StocksAppProps) {
  const [stocks, setStocks] = useState<Stock[]>(INITIAL_STOCKS);
  const [selectedStock, setSelectedStock] = useState<Stock>(INITIAL_STOCKS[0]);
  const [cash, setCash] = useState(() => {
    try {
      return Number(localStorage.getItem("procrastinate_stocks_cash") || "100000");
    } catch {
      return 100000;
    }
  });
  // tracking portfolio: stock_code -> number of shares owned
  const [portfolio, setPortfolio] = useState<{ [key: string]: number }>(() => {
    try {
      const saved = localStorage.getItem("procrastinate_stocks_portfolio");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [currentNewsIdx, setCurrentNewsIdx] = useState(0);
  const [tradeAmount, setTradeAmount] = useState<number>(100);

  // Auto tick mock stock movements
  useEffect(() => {
    const tickInterval = setInterval(() => {
      setStocks(prevStocks => {
        const nextStocks = prevStocks.map(stock => {
          // Calculate realistic small fluctuation
          const variance = (Math.random() - 0.49) * 0.03; // slightly bias upwards for fun
          let newPrice = Number((stock.price * (1 + variance)).toFixed(2));
          
          // Limits for Chinese stock market (漲跌停 10%)
          const maxPrice = Number((stock.open * 1.10).toFixed(2));
          const minPrice = Number((stock.open * 0.90).toFixed(2));
          
          if (newPrice > maxPrice) newPrice = maxPrice;
          if (newPrice < minPrice) newPrice = minPrice;

          const changePercent = Number((((newPrice - stock.open) / stock.open) * 100).toFixed(2));
          const high = Number(Math.max(stock.high, newPrice).toFixed(2));
          const low = Number(Math.min(stock.low, newPrice).toFixed(2));

          const history = [...stock.history.slice(1), newPrice];

          return { ...stock, price: newPrice, changePercent, high, low, history };
        });

        // Sync local selected stock reference
        const matched = nextStocks.find(s => s.code === selectedStock.code);
        if (matched) {
          setSelectedStock(matched);
        }

        return nextStocks;
      });
    }, 4000);

    return () => clearInterval(tickInterval);
  }, [selectedStock]);

  // Rotates news ticks
  useEffect(() => {
    const newsTimer = setInterval(() => {
      setCurrentNewsIdx(prev => (prev + 1) % NEWS_FEED.length);
    }, 8000);
    return () => clearInterval(newsTimer);
  }, []);

  // Buy action
  const handleBuy = () => {
    onLoggedClick();
    if (tradeAmount <= 0) return;
    const totalCost = selectedStock.price * tradeAmount;
    if (totalCost > cash) {
      alert("⚠️ 抱歉！您的摸鱼账户剩余 RMB 不足，无法买入！快去写 PPT 赚点微薄基本工资。");
      return;
    }

    const updatedPortfolio = {
      ...portfolio,
      [selectedStock.code]: (portfolio[selectedStock.code] || 0) + tradeAmount,
    };
    const nextCash = Number((cash - totalCost).toFixed(2));

    setCash(nextCash);
    setPortfolio(updatedPortfolio);
    try {
      localStorage.setItem("procrastinate_stocks_cash", String(nextCash));
      localStorage.setItem("procrastinate_stocks_portfolio", JSON.stringify(updatedPortfolio));
    } catch {}
  };

  // Sell action
  const handleSell = () => {
    onLoggedClick();
    const owned = portfolio[selectedStock.code] || 0;
    if (tradeAmount <= 0) return;
    if (tradeAmount > owned) {
      alert("⚠️ 错漏！您保有的股数不足，无法抛售该分量！");
      return;
    }

    const totalIncome = selectedStock.price * tradeAmount;
    const nextOwned = owned - tradeAmount;
    
    const updatedPortfolio = { ...portfolio };
    if (nextOwned <= 0) {
      delete updatedPortfolio[selectedStock.code];
    } else {
      updatedPortfolio[selectedStock.code] = nextOwned;
    }
    
    const nextCash = Number((cash + totalIncome).toFixed(2));

    setCash(nextCash);
    setPortfolio(updatedPortfolio);
    try {
      localStorage.setItem("procrastinate_stocks_cash", String(nextCash));
      localStorage.setItem("procrastinate_stocks_portfolio", JSON.stringify(updatedPortfolio));
    } catch {}
  };

  // Portfolio total calculation
  const getPortfolioValue = () => {
    let sum = 0;
    stocks.forEach(s => {
      const owned = portfolio[s.code] || 0;
      sum += owned * s.price;
    });
    return Number(sum.toFixed(2));
  };

  const portfolioValue = getPortfolioValue();
  const totalAssets = Number((cash + portfolioValue).toFixed(2));

  return (
    <div className="flex flex-col h-full bg-[#050505] text-[#cccccc] font-sans text-[11px] leading-tight select-none select-none justify-between border border-[#333]">
      {/* Tonghuashun Brand Frame Header */}
      <div className="bg-[#1e1e1e] border-b border-[#2d2d2d] py-1 px-2 flex items-center justify-between text-white shrink-0">
        <div className="flex items-center gap-1.5">
          <span className="bg-[#cc0000] text-white px-1 text-[9px] rounded font-extrabold tracking-wider scale-95">THS</span>
          <span className="font-bold text-[10px] text-red-500">同花顺证券(摸鱼专属红利版) v12.1</span>
          <span className="text-neutral-500 text-[8px] border border-neutral-700 px-0.5 ml-1 select-text">
            行情：在线A
          </span>
        </div>
        <div className="flex items-center gap-3 text-neutral-400 text-[9px]">
          <span className="flex items-center gap-1"><Clock size={10} /> 实时动态盘口</span>
          <button 
            onClick={() => { onLoggedClick(); }} 
            className="text-neutral-300 hover:text-white px-1 bg-neutral-800 border border-neutral-700 rounded active:scale-95"
          >
            一键全刷新
          </button>
        </div>
      </div>

      {/* Main Stock Monitor workspace */}
      <div className="flex-grow flex h-0 overflow-hidden">
        
        {/* Left Side: Stock List Ticker */}
        <div className="w-[170px] border-r border-[#262626] overflow-y-auto flex flex-col bg-[#0b0c0d] shrink-0">
          <div className="grid grid-cols-3 bg-[#141517] text-neutral-500 py-1 text-[9px] border-b border-[#222] font-semibold text-center select-text sticky top-0">
            <span>代码/名称</span>
            <span>最新价</span>
            <span>涨幅%</span>
          </div>
          {stocks.map(s => {
            const isUp = s.changePercent >= 0;
            const colorClass = isUp ? "text-[#f85149]" : "text-[#56b6c2]";
            const isSelected = selectedStock.code === s.code;

            return (
              <button
                key={s.code}
                onClick={() => { onLoggedClick(); setSelectedStock(s); }}
                className={`grid grid-cols-3 py-1.5 border-b border-[#18181a] items-center text-center transition cursor-pointer hover:bg-neutral-900 ${
                  isSelected ? "bg-neutral-800 text-white" : ""
                }`}
              >
                <div className="flex flex-col text-left pl-1.5 truncate">
                  <span className="font-bold text-white text-[10px] truncate">{s.name}</span>
                  <span className="text-[8px] text-neutral-500 scale-90 -translate-x-1">{s.code}</span>
                </div>
                <span className={`font-mono font-bold text-[10px] ${colorClass}`}>{s.price.toFixed(2)}</span>
                <span className={`font-mono text-[9px] ${colorClass}`}>
                  {isUp ? "+" : ""}{s.changePercent.toFixed(2)}%
                </span>
              </button>
            );
          })}
        </div>

        {/* Right Content Column: Chart & Trading Panel */}
        <div className="flex-grow flex flex-col bg-[#050505] overflow-y-auto">
          
          {/* Active Stock General Infobar */}
          <div className="bg-[#101012] border-b border-[#222] p-2 flex items-center justify-between select-text shrink-0">
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-white font-extrabold text-base tracking-tight">{selectedStock.name}</span>
                <span className="text-neutral-500 font-mono text-[9px]">({selectedStock.code})</span>
                <span className="bg-neutral-800 text-[8px] text-white px-1 py-0.5 rounded scale-90">沪深A股</span>
              </div>
              <div className="flex gap-3 text-neutral-400 text-[9px] mt-0.5">
                <span>开盘: <span className="font-mono text-white">{selectedStock.open.toFixed(2)}</span></span>
                <span>最高: <span className="font-mono text-white">{selectedStock.high.toFixed(2)}</span></span>
                <span>最低: <span className="font-mono text-white">{selectedStock.low.toFixed(2)}</span></span>
              </div>
            </div>

            <div className="text-right">
              <div className={`text-xl font-mono font-black ${selectedStock.changePercent >= 0 ? "text-[#f85149]" : "text-[#56b6c2]"}`}>
                {selectedStock.price.toFixed(2)}
              </div>
              <div className={`text-[10px] font-mono ${selectedStock.changePercent >= 0 ? "text-[#f85149]" : "text-[#56b6c2]"}`}>
                {selectedStock.changePercent >= 0 ? "▲" : "▼"}{selectedStock.changePercent.toFixed(2)}%
              </div>
            </div>
          </div>

          {/* Mini Interactive Candlestick / Line Chart */}
          <div className="p-2 border-b border-[#202022] bg-[#0c0d0f] flex flex-col justify-between shrink-0 h-[105px]">
            <div className="text-neutral-500 text-[8px] font-mono flex items-center justify-between">
              <span>⏱️ 分时走势 (过去12小时实时微趋势)</span>
              <span>量能:{selectedStock.vol}</span>
            </div>

            {/* Custom line graph drawer */}
            <div className="h-16 flex items-end justify-between px-3 pt-3 relative bg-black/40 border border-[#222] rounded mt-1">
              {/* Zero line reference */}
              <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 border-t border-[#333]/40 border-dashed pointer-events-none" />

              {selectedStock.history.map((hVal, hIdx) => {
                const minH = Math.min(...selectedStock.history);
                const maxH = Math.max(...selectedStock.history);
                const diff = (maxH - minH) || 1;
                // Calculate height percentage
                const heightPercent = ((hVal - minH) / diff) * 75 + 10; // offset slightly
                const isPriceUp = hIdx === 0 ? true : hVal >= selectedStock.history[hIdx - 1];

                return (
                  <div key={hIdx} className="flex-grow flex flex-col justify-end items-center h-full group relative">
                    {/* Tooltip on hover */}
                    <span className="absolute bottom-full left-1/2 -translate-x-1/2 bg-black text-white text-[8px] px-1 rounded opacity-0 group-hover:opacity-100 transition duration-700 pointer-events-none border border-neutral-700 font-mono scale-90 z-20">
                      {hVal.toFixed(2)}
                    </span>
                    {/* Candle bar */}
                    <div 
                      style={{ height: `${heightPercent}%` }}
                      className={`w-3.5 border-t border-x rounded-t-[1px] ${
                        isPriceUp ? "bg-[#f85149]/30 border-[#f85149]" : "bg-[#56b6c2]/30 border-[#56b6c2]"
                      }`}
                    />
                    <div className="text-[7px] text-neutral-600 font-mono mt-0.5 scale-90 scale-x-90">{hIdx * 2}h</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Simulated Trading Desk */}
          <div className="p-2.5 flex-grow flex flex-col justify-between bg-[#08090a]">
            
            {/* Asset balances check */}
            <div className="p-2 bg-[#141618] border border-neutral-800 rounded grid grid-cols-3 gap-0.5 text-[9px] font-mono leading-tight">
              <div>
                <span className="text-neutral-500 block">💳 闲置资金 (RMB)</span>
                <span className="text-white font-extrabold text-[11px]">{cash.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-neutral-500 block">📈 持仓市值</span>
                <span className="text-[#f85149] font-extrabold text-[11px]">{portfolioValue.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-neutral-500 block">🏦 总资产净值</span>
                <span className="text-amber-400 font-extrabold text-[11.5px]">{totalAssets.toFixed(2)}</span>
              </div>
            </div>

            {/* Owned share details summary */}
            <div className="my-1.5 flex justify-between items-center bg-black/40 p-1.5 border border-dashed border-[#333] rounded text-[10px]">
              <span className="text-neutral-400">
                当前保有 <strong className="text-white">{selectedStock.name}</strong> 持仓股数:
              </span>
              <span className="font-extrabold text-amber-300 font-mono">
                {portfolio[selectedStock.code] || 0} 股
              </span>
            </div>

            {/* Order execution block */}
            <div className="flex gap-2 items-center">
              <div className="flex-grow">
                <label className="text-[9px] text-[#888] block">交易股数 (整百起配)</label>
                <div className="flex items-center gap-1 mt-0.5">
                  <button 
                    onClick={() => { onLoggedClick(); setTradeAmount(prev => Math.max(100, prev - 100)); }}
                    className="bg-neutral-800 text-white font-mono font-bold px-2 py-1 rounded hover:bg-neutral-700 active:scale-95 text-[10px]"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    value={tradeAmount}
                    onChange={(e) => setTradeAmount(Math.max(100, Math.floor(Number(e.target.value) / 100) * 100))}
                    className="bg-black text-white text-center font-mono font-black border border-neutral-700 py-0.5 w-[70px] rounded text-[11px] h-6"
                  />
                  <button 
                    onClick={() => { onLoggedClick(); setTradeAmount(prev => prev + 100); }}
                    className="bg-neutral-800 text-white font-mono font-bold px-2 py-1 rounded hover:bg-neutral-700 active:scale-95 text-[10px]"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Transactions actions dispatch */}
              <div className="flex gap-1.5 pt-3 shrink-0">
                <button
                  onClick={handleBuy}
                  className="bg-[#cc0000] hover:bg-[#aa0000] text-white font-black px-4 py-1.5 rounded active:translate-y-0.5 cursor-pointer text-[10px] shadow border border-red-900"
                >
                  红色买入(+)
                </button>
                <button
                  onClick={handleSell}
                  className="bg-[#20bf6b] hover:bg-[#1da85e] text-black font-black px-4 py-1.5 rounded active:translate-y-0.5 cursor-pointer text-[10px] shadow border border-emerald-900"
                >
                  绿色卖出(-)
                </button>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* Corporate slacker scroll news ticker */}
      <div className="bg-[#141517] border-t border-[#2d2d2d] py-1 px-2 flex items-center gap-1 shrink-0 text-[10px]">
        <span className="text-[#ff9f43] font-bold flex items-center gap-0.5 shrink-0 select-text bg-amber-500/10 px-1 border border-amber-500/20 rounded">
          <AlertTriangle size={11} /> 联播快讯：
        </span>
        <div className="flex-grow select-text truncate text-white animate-fade-in font-medium">
          {NEWS_FEED[currentNewsIdx]}
        </div>
      </div>
    </div>
  );
}
