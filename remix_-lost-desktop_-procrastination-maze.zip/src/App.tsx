import React, { useState } from "react";
import { UserState, GameStats } from "./types";
import IntroScreen from "./components/IntroScreen";
import BootScreen from "./components/BootScreen";
import DesktopLayout from "./components/DesktopLayout";
import ReportCard from "./components/ReportCard";

type GameStage = "intro" | "boot" | "desktop" | "report";

export default function App() {
  const [stage, setStage] = useState<GameStage>("intro");
  const [user, setUser] = useState<UserState | null>(null);
  const [stats, setStats] = useState<GameStats | null>(null);
  const [timeSpentSec, setTimeSpentSec] = useState(0);

  const handleLogin = (selectedUser: UserState) => {
    setUser(selectedUser);
    setStage("desktop");
  };

  const handleFinishGame = (finalStats: GameStats) => {
    const elapsedSecMap = Math.floor((Date.now() - finalStats.startTime) / 1000);
    setTimeSpentSec(elapsedSecMap);
    setStats(finalStats);
    setStage("report");
  };

  return (
    <div id="app-viewport-wrapper" className="w-full h-screen overflow-hidden bg-neutral-900 select-none">
      {stage === "intro" && <IntroScreen onComplete={() => setStage("boot")} />}

      {stage === "boot" && <BootScreen onLogin={handleLogin} />}
      
      {stage === "desktop" && user && (
        <DesktopLayout 
          user={user} 
          onFinishGame={handleFinishGame} 
        />
      )}

      {stage === "report" && user && stats && (
        <ReportCard 
          user={user} 
          stats={stats} 
          timeSpentSec={timeSpentSec} 
        />
      )}
    </div>
  );
}
