export type JobType = "code" | "report" | "design" | "literature" | "meeting";
export type DistractionType = "video" | "social" | "shopping" | "cats";
export type TimeStyle = "morning" | "midnight" | "random";

export interface UserState {
  name: string;
  gender: "male" | "female" | "other";
  jobType: JobType;
  distraction: DistractionType;
  timeStyle: TimeStyle;
}

export type AppWindowType = 
  | "qiandu" 
  | "boss" 
  | "tiktok" 
  | "tieba" 
  | "shopping" 
  | "camera" 
  | "work-app" 
  | "my-computer" 
  | "recycle-bin"
  | "minesweeper"
  | "music"
  | "diary"
  | "tetris"
  | "snake"
  | "stocks"
  | "calculator"
  | "settings";

export interface DesktopItem {
  id: string;
  label: string;
  icon: string; // lucide icon name
  type: AppWindowType;
  isDistraction: boolean;
  isOpen: boolean;
}

export interface WindowInstance {
  id: AppWindowType;
  label: string;
  icon: string;
  x: number;
  y: number;
  w: number;
  h: number;
  isMinimized: boolean;
  isMaximized: boolean;
  isOpen: boolean;
  zIndex: number;
}

export interface BossMessage {
  id: string;
  sender: "boss" | "player";
  text: string;
  timestamp: string;
}

export interface QianduSearchResult {
  title: string;
  snippet: string;
  url: string;
  isAd?: boolean;
}

export interface QianduResponse {
  results: QianduSearchResult[];
  relatedSearches: string[];
  pageTwoClue?: string;
}

export interface GameStats {
  startTime: number;
  totalClicks: number;
  distractionsCount: number;
  bossUrges: number;
  searchesCount: number;
  level: number; // 0 to 4
}
