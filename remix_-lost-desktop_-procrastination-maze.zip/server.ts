import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini API Client safely (Lazy / Guarded initialization)
let ai: GoogleGenAI | null = null;
const API_KEY = process.env.GEMINI_API_KEY;

if (API_KEY && API_KEY !== "MY_GEMINI_API_KEY" && API_KEY.trim() !== "") {
  try {
    ai = new GoogleGenAI({
      apiKey: API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': "aistudio-build",
        },
      },
    });
    console.log("Gemini API client initialized successfully.");
  } catch (err) {
    console.error("Failed to initialize Gemini API client:", err);
  }
} else {
  console.log("No valid GEMINI_API_KEY found. Running in resilient mock fallback mode.");
}

// Custom Qiandu (恶搞搜索引擎) Search AI endpoint
app.post("/api/qiandu", async (req, res) => {
  const { query, jobType, distraction, page = 1, userName = "小王" } = req.body;
  const targetPage = Number(page);

  const jobLabels: Record<string, string> = {
    code: "写系统代码",
    report: "制作Q2汇报PPT",
    design: "设计Figma移动界面",
    literature: "查找论文研究文献",
    meeting: "整理周会会议紀要",
  };

  const distractionLabels: Record<string, string> = {
    video: "刷短视频/逗猫视频",
    social: "逛吃瓜贴吧/查看朋友动态",
    shopping: "薅羊毛限时秒杀特惠",
    cats: "看可爱小猫咪动图",
  };

  const jobDesc = jobLabels[jobType] || jobType;
  const distDesc = distractionLabels[distraction] || distraction;

  if (ai) {
    try {
      const prompt = `You are the sarcastic, humorous search engine "千度" (Qiandu) configured specifically to mock procrastination.
User is '${userName}' whose assigned workday task is '${jobDesc}' but they keep getting distracted by '${distDesc}'.
They just entered the search query: '${query}' on Page ${targetPage} of Qiandu Search.

Generate 3 funny, satirical, and highly sarcastic mock search results criticizing their procrastination or relating funny stories. Each search result has a title, snippet, and a humorous URL. Mark some as "isAd": true if it looks like an ad trying to sell them distraction toys.
Also output 3 clever 'relatedSearches' (related searches) showing how people drift further into procrastination (e.g., "how long can a human survive on instant noodles while coding", "why is procrastination called artistic incubation").

If the user is on page 2 (targetPage === 2), you MUST explicitly include a clear solving clue inside the snippets or related searches and set "pageTwoClue".
The actual escape password/clue of the game is 'XP0607' (a nod to Windows XP and typical file decryption). Include this password cleanly in one of the Page 2 search snippets as a "System Security Alert / File Backup Decrypt Key for ${jobDesc}". 

Return the output in exact JSON format mapping to this schema:
{
  "results": [
    {
      "title": "string",
      "snippet": "string",
      "url": "string",
      "isAd": boolean
    }
  ],
  "relatedSearches": ["string", "string", "string"],
  "pageTwoClue": "string (only on Page 2, explaining the password XP0607)"
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.85,
        },
      });

      const responseText = response.text || "{}";
      const cleanJson = JSON.parse(responseText.trim());
      return res.json(cleanJson);
    } catch (err: any) {
      console.log("Gemini Qiandu search service temporarily unavailable. Safely falling back to local simulation:", err?.message || err);
    }
  }

  // Resilient Mock Fallback in case of no key or API error
  const mockResults = [];
  let pageTwoClue = "";
  if (targetPage === 1) {
    mockResults.push(
      {
        title: `探讨：为什么${userName}明明在${jobDesc}，却非要搜索“${query}”？`,
        snippet: `有神经科学研究表明，人类在面临重度工作（比如写什么${jobDesc}）时，脑电波会不自觉发出求救信号，进而驱使他们双击鼠标打开${distDesc}。你此时的搜索行为已被意志力警报记录。`,
        url: "https://www.procrastine-scientist.org/avoid-work",
        isAd: false,
      },
      {
        title: `【广告】摸鱼键盘防窥神膜 - 静音无声，老板走过自动转回PPT`,
        snippet: `专为${userName}这样的自由职业者/白领打造！双击Esc立即遮罩。配合小零食口感极佳，助你把${distDesc}进行到底！`,
        url: "https://item.moyu-taobao.com/anti-boss-shield",
        isAd: true,
      },
      {
        title: `震惊！某员工因拖延${jobDesc}，在“千度”上漫无目的地搜索“${query}”消磨了一整天`,
        snippet: `据悉，这位自负的小伙伴不仅没有做任何实质工作，还以为自己在暗中搜寻某种神秘的代码和文献。目前他的主管已经快到他身后了。`,
        url: "https://news.moyu-daily.com/shocking-truth",
        isAd: false,
      }
    );
  } else {
    // Page 2 - Resiliently inject critical game code XP0607
    pageTwoClue = "系统安全警告：检测到关键解密凭证【XP0607】！请速将该序列号输入您桌面未命中的工作文档解密框。";
    mockResults.push(
      {
        title: `【工作备份与安全中心】紧急解密指南`,
        snippet: `由于您过度沉迷${distDesc}，您的核心工作文件已被系统安全沙盒锁定。解除沙盒的核心序列密钥：XP0607。请立即返回桌面双击工作文档输入解锁。`,
        url: "https://security.windows-xp-backup.sys/recovery-key",
        isAd: false,
      },
      {
        title: "大自然的神奇规律：第 2 页的秘密",
        snippet: "几乎没有人类会翻到搜索引擎的第 2 页，除非他们已经被主管催促到退无可退。既然你费尽心思点击到这里，你应该已经拿到了那个六位数的密码：XP0607。",
        url: "https://nature-secrets.org/page-two",
        isAd: false,
      }
    );
  }

  return res.json({
    results: mockResults,
    relatedSearches: [
      `为什么${jobDesc}会引发嗜睡`,
      `${distDesc}真的能缓解情绪压力吗`,
      "适合被主管查岗时假装在思考的高级姿势",
      "如何关掉千度并认命去写代码"
    ],
    pageTwoClue: targetPage === 2 ? pageTwoClue : undefined
  });
});

// Passive-aggressive Supervisor text generator
app.post("/api/boss-message", async (req, res) => {
  const { userName, jobType, level = 1, currentMessages = [] } = req.body;

  const jobLabels: Record<string, string> = {
    code: "代码文件及部署脚本",
    report: "季度销售增长汇报PPT",
    design: "APP核心UI交互设计稿",
    literature: "毕业论文文献综述",
    meeting: "全员周会会议紀要",
  };

  const currentTask = jobLabels[jobType] || jobType;

  if (ai) {
    try {
      const prompt = `You are the ultimate passive-aggressive, corporate-speak team supervisor '主管王经理' (Manager Wang) in a Chinese remote working environment.
Your underling '${userName}' was tasked with completing '${currentTask}', but they are clearly slacking and procrastinating on their desktop.
Generate ONE highly characteristic, realistic, and humorous message reminding them of the deadline.
The pressure escalates severely depending on the procrastination level (from 1 to 4):
- Level 1 (Polite & Subtle): Ask simple check-ins like "在吗？我看文档没更新，有遇到什么难点吗？"
- Level 2 (The Gentle Nudge): Hint that clients or higher-ups are watching, maybe say "隔壁组都在催了，能先上传一个框架吗？"
- Level 3 (Corporate Jargon / Passive Aggressive): High corporate bs. "我们需要对这个 deliverables 进行 alignment。我们需要赋能业务，但你的共创文件还是 0 字节？抓紧拉齐一下进度。"
- Level 4 (Outright Panic & Impending Doom): Total hyperventilating panic, typing errors, sending meeting links, telling them the Zoom is active right now and they are expected. E.g. "？？怎么还没进会议？甲方在发飙了！快快快！"

Keep the response strictly to a single paragraph representing just the Manager's text message. Be extremely funny, satirical, and representative of modern Chinese corporate lingo.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          temperature: 0.9,
        },
      });

      return res.json({ text: response.text?.trim() || "在线等，挺急的。" });
    } catch (err: any) {
      console.log("Gemini Boss Urging service temporarily unavailable. Safely falling back to local simulation:", err?.message || err);
    }
  }

  // Resilient Mock Fallback for Boss
  const defaultBossPhrases: Record<number, string[]> = {
    1: [
      `在吗？那个'${currentTask}'目前进度如何呀？我看云文档里还没有内容更新。不急哈，就是顺便问一嘴。`,
      `Hi, '${userName}'，昨天的会议纪要看你理解挺周全的，今天那个'${currentTask}'有遇到什么困难吗？随时沟通。`
    ],
    2: [
      `‘${userName}’，刚刚总监在群里问起你的‘${currentTask}’了。我帮你挡了一下说你正在做最后收尾。五分钟内发我一份初稿同步哦，谢啦！`,
      `那个啥，隔壁对接团队已经在催数据了，你这边的‘${currentTask}’下午三点前能不能先给个粗略版本？谢谢配合哈~`
    ],
    3: [
      `我们需要对你这个‘${currentTask}’的交付物进行深度拉齐（Alignment）。我们需要聚焦核心链路，实现业务赋能。但目前来看你的产出还是零反馈状态。我们的协同效率需要更具闭环性，抓紧拉通一下。`,
      `小${userName}啊，有些时候态度决定高度。大家都在为项目冷启动冲刺，如果因为你的‘${currentTask}’卡了脖子，这个盘子的势能就很难做起来了。请务必把你的颗粒度也跟团队对齐一下，收到请回复。`
    ],
    4: [
      `【紧急】？？会议室人都到齐了！！！甲方爸爸已经在语音里质问为什么‘${currentTask}’还没展示了！！！怎么呼你没有反应？？？快点进会议，链接我直接贴你桌面了，十万火急！！！`,
      `！！！王/沈！！！为什么你状态一直是‘Away 离开’啊？？总监直接在公司大群里点名要看你的‘${currentTask}’了，快快快！直接开麦投屏！天塌下来了都得先顶住啊！！！`
    ]
  };

  const phrases = defaultBossPhrases[level as 1|2|3|4] || defaultBossPhrases[1];
  const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
  return res.json({ text: randomPhrase });
});

// Generate dynamic AI tailored advice for the end-of-game procrastination report card
app.post("/api/report-advice", async (req, res) => {
  const { userName, jobType, distraction, timeStyle, clicks, timeSpentSec } = req.body;

  const jobLabels: Record<string, string> = {
    code: "核心代码部署",
    report: "Q2业务汇报PPT",
    design: "APP高保真设计",
    literature: "科研学术论文",
    meeting: "会议总结纪要",
  };

  const distractionLabels: Record<string, string> = {
    video: "摸鱼短视频",
    social: "逛论坛贴吧吃瓜",
    shopping: "薅羊毛秒杀商品",
    cats: "沉迷可爱猫咪动图",
  };

  const currentTask = jobLabels[jobType] || jobType;
  const currentDist = distractionLabels[distraction] || distraction;

  if (ai) {
    try {
      const prompt = `You are a warm, witty, and highly insightful psychology coach analyzing a user's procrastination habits.
User is '${userName}'. They spent ${timeSpentSec} seconds on a mock desktop doing '${currentDist}' instead of their actual assigned target task '${currentTask}'. They also clicked around ${clicks} times.
Give them 2 to 3 sentences of personalized, humorous, and deeply resonant psychotherapist-style advice about procrastination. 
Explain that "procrastination is not laziness, but a fight-or-flight fight inside your brain between immediate pleasure and long-term anxiety."
Make them feel understood, laugh at themselves, and ultimately inspired to close this tab and open their ACTUAL, REAL files! Keep it in warm, supportive Chinese language.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          temperature: 0.8,
        },
      });

      return res.json({ advice: response.text?.trim() || "去写吧，真正的那个文件它并不会主动跳出来咬你。" });
    } catch (err: any) {
      console.log("Gemini report-advice service temporarily unavailable. Safely falling back to local simulation:", err?.message || err);
    }
  }

  // Resilient Mock Fallback
  return res.json({
    advice: `亲爱的 ${userName}，你在虚构的桌面上挣扎了 ${timeSpentSec} 秒，点击了 ${clicks} 次鼠标，再次成功地向${currentDist}投降。其实你很清楚，拖延从来就不是因为懒惰，而是面对复杂的【${currentTask}】时，你大脑杏仁核面对持久焦虑与即时安逸所做出的防御战斗。你越是害怕开头，诱惑就显得越甜美。不过现在，是时候终结这场虚拟迷宫了。深呼吸，关掉这个网页，去双击你真实桌面上的那份文件吧。它一直在那安静地等你，它真的没那么可怕。`
  });
});

// Serve static assets in production or coordinate Vite server in development
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Lost Desktop game server running on http://localhost:${PORT}`);
  });
}

startServer();
